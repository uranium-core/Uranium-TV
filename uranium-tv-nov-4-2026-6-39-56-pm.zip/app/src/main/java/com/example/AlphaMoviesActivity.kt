package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream
import kotlin.math.ceil
import kotlin.math.min

class AlphaMoviesActivity : ComponentActivity() {

    private lateinit var rootLayout: FrameLayout
    private lateinit var mainWebView: WebView
    private var phantomWebView: WebView? = null

    // Visible ad step: the ad opens full screen inside the app, closes itself after the watch time
    private val AD_WATCH_MS = 22000L   // the site asks for 20+ seconds
    private var adPanel: FrameLayout? = null
    private var adWebView: WebView? = null
    private var adTimeText: TextView? = null
    private var adBar: ProgressBar? = null
    private var adInfoText: TextView? = null
    private var adTimer: android.os.CountDownTimer? = null
    private var adTimerStarted = false
    private var justWatchedAd = false
    private var postAdReloads = 0
    private val adHandler = Handler(Looper.getMainLooper())
    private lateinit var nativeOverlay: FrameLayout
    private lateinit var statusText: TextView
    private lateinit var subStatusText: TextView
    private lateinit var interactiveView: ChainReactionView
    private lateinit var overlayContent: LinearLayout
    private lateinit var overlayHeader: LinearLayout
    private lateinit var countdownRing: CountdownRingView
    private var introToken = 0
    private var introRunnable: Runnable? = null
    private val INTRO_HOLD_MS = 1800L

    private val handler = Handler(Looper.getMainLooper())
    private var standardChromeUA = ""
    private var documentStartInstalled = false

    // ====================== VERIFICATION STATE ======================
    private var isVerifying = false
    private var verificationStartTime = 0L
    private var pollRunnable: Runnable? = null
    private var reloadedForCookies = false
    private var baselineCookieNames: Set<String> = emptySet()

    private val VERIFY_COUNTDOWN_MS = 45000L
    private val POLL_INTERVAL = 1300L

    // Player
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var playerOpen = false
    private var playerModeOn = false
    private var lastPlayerCloseAt = 0L
    private lateinit var customViewContainer: FrameLayout

    // Uranium TV atom logo (replaces the old blue "A" everywhere), served from inside the app
    private val logoSvg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000">
  <defs>
    <!-- Clip Path so the Curved Filmstrip Smoothly Touches the Inner Edge of the Red Ring -->
    <clipPath id="portalClip">
      <circle cx="500" cy="500" r="388" />
    </clipPath>

    <!-- Clip Path for the Curved Movie Reel Body -->
    <clipPath id="reelCurveClip">
      <path d="M 390,715 C 530,610 695,525 895,465 L 915,635 C 715,695 550,780 410,885 Z" />
    </clipPath>

    <!-- Dark Crimson-Black Portal Background -->
    <radialGradient id="bgRadial" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#330812" />
      <stop offset="58%" stop-color="#14060a" />
      <stop offset="100%" stop-color="#070305" />
    </radialGradient>

    <!-- Metallic Bezel Base Gradient -->
    <linearGradient id="bezelGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#364052" />
      <stop offset="50%" stop-color="#1e2430" />
      <stop offset="100%" stop-color="#12161f" />
    </linearGradient>

    <!-- Metallic Bezel Raised Armor Plates -->
    <linearGradient id="armorGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#6c7c96" />
      <stop offset="50%" stop-color="#4b576b" />
      <stop offset="100%" stop-color="#353e4f" />
    </linearGradient>

    <!-- 3D Red Nucleus Sphere Gradient -->
    <radialGradient id="nucleusSphere" cx="35%" cy="32%" r="65%">
      <stop offset="0%" stop-color="#ffd6de" />
      <stop offset="15%" stop-color="#ff3347" />
      <stop offset="50%" stop-color="#e60012" />
      <stop offset="84%" stop-color="#7d0008" />
      <stop offset="100%" stop-color="#330003" />
    </radialGradient>

    <!-- Embedded Electron Core Gradient -->
    <radialGradient id="electronSphere" cx="38%" cy="38%" r="62%">
      <stop offset="0%" stop-color="#ffffff" />
      <stop offset="35%" stop-color="#ff8fa0" />
      <stop offset="70%" stop-color="#e6001b" />
      <stop offset="100%" stop-color="#3b0006" />
    </radialGradient>

    <!-- Translucent Curved Filmstrip Gradient -->
    <linearGradient id="filmGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#755662" stop-opacity="0.78" />
      <stop offset="50%" stop-color="#543a45" stop-opacity="0.84" />
      <stop offset="100%" stop-color="#3b252e" stop-opacity="0.88" />
    </linearGradient>
  </defs>

  <!-- ==================== 1. OUTER SEGMENTED METALLIC BEZEL ==================== -->
  <g id="outer-bezel">
    <circle cx="500" cy="500" r="478" fill="#0b0e14" />
    <circle cx="500" cy="500" r="442" fill="none" stroke="url(#bezelGrad)" stroke-width="58" />
    <!-- 8 Raised Grey-Blue Armor Segments -->
    <circle cx="500" cy="500" r="442" fill="none" stroke="url(#armorGrad)" stroke-width="56"
            stroke-dasharray="74 273.15" stroke-dashoffset="37" />
    <circle cx="500" cy="500" r="470" fill="none" stroke="#4d586b" stroke-width="2.5" opacity="0.7" />
    <circle cx="500" cy="500" r="413" fill="none" stroke="#080a0e" stroke-width="6" />
  </g>

  <!-- ==================== 2. INNER PORTAL (ATOM + CURVED REEL) ==================== -->
  <g id="inner-portal" clip-path="url(#portalClip)">
    <!-- Dark Portal Background -->
    <circle cx="500" cy="500" r="395" fill="url(#bgRadial)" />
    <!-- Soft Center Red Ambient Glow -->
    <circle cx="500" cy="500" r="240" fill="#ff0019" opacity="0.10" />
    <circle cx="500" cy="500" r="150" fill="#ff0019" opacity="0.15" />

    <!-- ==================== 3. DIRECTLY DRAWN ATOM ORBIT ELLIPSES & EMBEDDED ELECTRONS ==================== -->
    <g id="atom-system" transform="translate(500, 500)">

      <!-- ===== ORBIT ELLIPSE 1: Tilted at -26 Degrees (Bottom-Left to Top-Right) ===== -->
      <g transform="rotate(-26)">
        <!-- Multi-layered Neon Glow Ellipse (Guaranteed to render in all viewers) -->
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff0019" stroke-width="34" opacity="0.12" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff0019" stroke-width="22" opacity="0.24" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff1e38" stroke-width="13" opacity="0.55" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff667d" stroke-width="7.5" opacity="0.9" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#fff0f3" stroke-width="3.2" />

        <!-- Electron 1 Embedded Directly on Orbit 1 Line (at angle t = -18 deg -> x=290.1, y=-35.5) -->
        <g transform="translate(290.1, -35.5)">
          <circle cx="0" cy="0" r="32" fill="#ff0019" opacity="0.25" />
          <circle cx="0" cy="0" r="24" fill="#ff0a22" opacity="0.45" />
          <circle cx="0" cy="0" r="20" fill="#210308" stroke="#ff2a44" stroke-width="4" />
          <circle cx="0" cy="0" r="20" fill="none" stroke="#ffc2cc" stroke-width="1.5" />
          <circle cx="0" cy="0" r="11" fill="url(#electronSphere)" />
          <circle cx="-3.5" cy="-3.5" r="2.8" fill="#ffffff" />
        </g>
      </g>

      <!-- ===== ORBIT ELLIPSE 2: Tilted at +34 Degrees (Top-Left to Bottom-Right) ===== -->
      <g transform="rotate(34)">
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff0019" stroke-width="34" opacity="0.12" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff0019" stroke-width="22" opacity="0.24" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff1e38" stroke-width="13" opacity="0.55" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff667d" stroke-width="7.5" opacity="0.9" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#fff0f3" stroke-width="3.2" />

        <!-- Electron 2 Embedded Directly on Orbit 2 Line (at angle t = 198 deg -> x=-290.1, y=-35.5) -->
        <g transform="translate(-290.1, -35.5)">
          <circle cx="0" cy="0" r="32" fill="#ff0019" opacity="0.25" />
          <circle cx="0" cy="0" r="24" fill="#ff0a22" opacity="0.45" />
          <circle cx="0" cy="0" r="20" fill="#210308" stroke="#ff2a44" stroke-width="4" />
          <circle cx="0" cy="0" r="20" fill="none" stroke="#ffc2cc" stroke-width="1.5" />
          <circle cx="0" cy="0" r="11" fill="url(#electronSphere)" />
          <circle cx="-3.5" cy="-3.5" r="2.8" fill="#ffffff" />
        </g>
      </g>

      <!-- ===== ORBIT ELLIPSE 3: Tilted at +94 Degrees (Steep Vertical-Diagonal) ===== -->
      <g transform="rotate(94)">
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff0019" stroke-width="34" opacity="0.12" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff0019" stroke-width="22" opacity="0.24" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff1e38" stroke-width="13" opacity="0.55" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#ff667d" stroke-width="7.5" opacity="0.9" />
        <ellipse cx="0" cy="0" rx="305" ry="115" fill="none" stroke="#fff0f3" stroke-width="3.2" />

        <!-- Electron 3 Embedded Directly on Orbit 3 Line (at angle t = 24 deg -> x=278.6, y=46.8) -->
        <g transform="translate(278.6, 46.8)">
          <circle cx="0" cy="0" r="32" fill="#ff0019" opacity="0.25" />
          <circle cx="0" cy="0" r="24" fill="#ff0a22" opacity="0.45" />
          <circle cx="0" cy="0" r="20" fill="#210308" stroke="#ff2a44" stroke-width="4" />
          <circle cx="0" cy="0" r="20" fill="none" stroke="#ffc2cc" stroke-width="1.5" />
          <circle cx="0" cy="0" r="11" fill="url(#electronSphere)" />
          <circle cx="-3.5" cy="-3.5" r="2.8" fill="#ffffff" />
        </g>
      </g>

      <!-- ===== CENTRAL 3D RED NUCLEUS SPHERE ===== -->
      <g id="nucleus">
        <!-- Layered Outer Red Glow -->
        <circle cx="0" cy="0" r="102" fill="#ff0015" opacity="0.15" />
        <circle cx="0" cy="0" r="88" fill="#ff0015" opacity="0.32" />
        <!-- Main 3D Nucleus Sphere -->
        <circle cx="0" cy="0" r="78" fill="url(#nucleusSphere)" />
        <!-- Specular 3D Highlight -->
        <ellipse cx="-25" cy="-25" rx="22" ry="14" transform="rotate(-35 -25 -25)" fill="#ffffff" opacity="0.45" />
        <ellipse cx="-26" cy="-26" rx="13" ry="7.5" transform="rotate(-35 -26 -26)" fill="#ffffff" opacity="0.85" />
      </g>
    </g>

    <!-- ==================== 4. SMOOTHLY CURVED MOVIE REEL (TOUCHING RED OUTER CIRCLE) ==================== -->
    <g id="curved-movie-reel">
      <!-- Soft Drop Shadow Underneath the Curved Reel -->
      <path d="M 382,722 C 522,617 687,532 887,472 L 907,642 C 707,702 542,787 402,892 Z"
            fill="#000000" opacity="0.6" />

      <!-- Main Curved Reel Group Clipped to the Arch Shape -->
      <g clip-path="url(#reelCurveClip)">
        <!-- Translucent Glassy Mauve Film Body -->
        <path d="M 390,715 C 530,610 695,525 895,465 L 915,635 C 715,695 550,780 410,885 Z"
              fill="url(#filmGrad)" />

        <!-- Subtle Center Highlight Band Following the Curve -->
        <path d="M 396,765 C 536,660 701,575 901,515 L 909,585 C 709,645 544,730 404,835 Z"
              fill="#ffffff" opacity="0.05" />

        <!-- Curved Film Frame Divider Bars (Angled radially to match the arch) -->
        <g stroke="#151118" stroke-width="15" opacity="0.94">
          <line x1="400" y1="705" x2="420" y2="890" />
          <line x1="518" y1="622" x2="538" y2="805" />
          <line x1="698" y1="532" x2="718" y2="715" />
          <line x1="868" y1="472" x2="888" y2="655" />
        </g>

        <!-- Top Curved Dark Sprocket Track -->
        <path d="M 390,715 C 530,610 695,525 895,465 L 899,497 C 699,557 534,642 394,747 Z"
              fill="#141118" />

        <!-- Bottom Curved Dark Sprocket Track -->
        <path d="M 406,853 C 546,748 711,663 911,603 L 915,635 C 715,695 550,780 410,885 Z"
              fill="#141118" />

        <!-- Top Sprocket Holes Following the Upper Arch (Dashed Curved Track) -->
        <path d="M 392,731 C 532,626 697,541 897,481"
              fill="none" stroke="#5c4752" stroke-width="13" stroke-dasharray="18 18" stroke-dashoffset="6" />

        <!-- Bottom Sprocket Holes Following the Lower Arch (Dashed Curved Track) -->
        <path d="M 408,869 C 548,764 713,679 913,619"
              fill="none" stroke="#5c4752" stroke-width="13" stroke-dasharray="18 18" stroke-dashoffset="6" />

        <!-- Crisp Inner Border Lines Along the Sprocket Tracks -->
        <path d="M 394,747 C 534,642 699,557 899,497" fill="none" stroke="#2e2229" stroke-width="2" />
        <path d="M 406,853 C 546,748 711,663 911,603" fill="none" stroke="#2e2229" stroke-width="2" />

        <!-- Glowing Red Dust / Sparkle Particles Inside the Curved Reel -->
        <g fill="#ff3b4e">
          <circle cx="475" cy="765" r="3.5" opacity="0.85" />
          <circle cx="565" cy="715" r="4" opacity="0.9" />
          <circle cx="605" cy="665" r="3" opacity="0.75" />
          <circle cx="645" cy="705" r="8" fill="#ff0a22" opacity="0.35" />
          <circle cx="645" cy="705" r="3.5" fill="#ffb3be" />
          <circle cx="745" cy="595" r="3.5" opacity="0.9" />
          <circle cx="775" cy="625" r="3" opacity="0.85" />
          <circle cx="805" cy="575" r="4" opacity="0.95" />
          <circle cx="835" cy="605" r="3.5" opacity="0.9" />
          <circle cx="855" cy="555" r="3" opacity="0.8" />
        </g>
      </g>

      <!-- Left Cut-Edge Border of the Reel (Tucked cleanly inside the bottom-left of the red circle) -->
      <line x1="390" y1="715" x2="410" y2="885" stroke="#141118" stroke-width="8" />
    </g>

    <!-- Inner Portal Vignette Shadow for Smooth Depth Against the Red Ring -->
    <circle cx="500" cy="500" r="388" fill="none" stroke="#000000" stroke-width="18" opacity="0.55" />
  </g>

  <!-- ==================== 5. GLOWING RED OUTER CIRCLE & CARDINAL TICKS ==================== -->
  <g id="outer-red-ring">
    <!-- Multi-Layered Neon Red Ring (Smoothly covers the outer edge of the movie reel) -->
    <circle cx="500" cy="500" r="392" fill="none" stroke="#ff0019" stroke-width="36" opacity="0.18" />
    <circle cx="500" cy="500" r="392" fill="none" stroke="#ff0019" stroke-width="24" opacity="0.38" />
    <circle cx="500" cy="500" r="392" fill="none" stroke="#ff1e38" stroke-width="14" opacity="0.85" />
    <circle cx="500" cy="500" r="392" fill="none" stroke="#ff99a8" stroke-width="5.5" />
    <circle cx="500" cy="500" r="392" fill="none" stroke="#fff0f3" stroke-width="2" />

    <!-- 4 Inner Cardinal Calibration Ticks -->
    <g fill="#ff2a40" stroke="#ff99a8" stroke-width="1.5">
      <rect x="472" y="136" width="56" height="14" rx="3" />
      <rect x="472" y="850" width="56" height="14" rx="3" />
      <rect x="136" y="472" width="14" height="56" rx="3" />
      <rect x="850" y="472" width="14" height="56" rx="3" />
    </g>

    <!-- 4 Outer Bezel Cardinal Red Accents -->
    <g fill="#e6192e">
      <rect x="466" y="86" width="68" height="9" rx="2" />
      <rect x="466" y="905" width="68" height="9" rx="2" />
      <rect x="86" y="466" width="9" height="68" rx="2" />
      <rect x="905" y="466" width="9" height="68" rx="2" />
    </g>
  </g>
</svg>"""

    // Exact image files of the site that carry the old "N" logo (taken from the saved page):
    //  - hs-mainlogo.png   : header logo (img.brand-logo)
    //  - nf2/icon_x192.png : bottom-nav centre button (.iconClass.disneyplus), player loader,
    //                        login logo, favicon
    //  - nf2/C192.png, nf2/maskable_icon_xx192.png : touch / shortcut icons
    // They are replaced at network level, so the A appears instantly with no flash.
    // NOTE: no "/mobile" prefix on purpose. Most pages use /mobile/img/..., but the Prime Video
    // page uses /img/nf2/icon_x192.png (bottom-nav N). endsWith() matches both forms.
    private val logoPathSuffixes = listOf(
        "/img/hs-mainlogo.png",
        "/img/nf2/icon_x192.png",
        "/img/nf2/c192.png",
        "/img/nf2/maskable_icon_xx192.png"
    )

    private val imageExtensions = listOf(".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg")

    // >>> PUT YOUR INSTAGRAM PROFILE LINK HERE (used by the promo page and the home-page box)
    private val instagramUrl = "https://www.instagram.com/uranium.tv?xtok=NmI1aGhhMDJrMXNt"
    // =====================================================================================

    private lateinit var promoOverlay: FrameLayout
    private var promoWebView: WebView? = null
    private var promoOpen = false

    // Loading placeholder that used to say "NETFLIX MIRROR" (site file /img/p11111.png).
    private val placeholderSvg = """<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 450'>
<defs>
<linearGradient id='bg' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#262626'/><stop offset='1' stop-color='#4b4b4b'/></linearGradient>
<filter id='bl'><feGaussianBlur stdDeviation='0.7'/></filter>
</defs>
<rect width='300' height='450' fill='url(#bg)'/>
<g filter='url(#bl)' font-family='Roboto,Arial,Helvetica,sans-serif' font-weight='700' font-size='24' letter-spacing='0.6' text-anchor='middle' fill='#8c8c8c' fill-opacity='0.6'>
<text x='150' y='218'>URANIUM</text>
<text x='150' y='249'>TV</text>
</g>
</svg>"""

    // Instagram banner "@uranium.tv" that replaces the old Telegram picture
    private val instagramSvg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 450">
  <defs>
    <!-- Background Gradients -->
    <radialGradient id="bg-glow" cx="45%" cy="40%" r="75%">
      <stop offset="0%" stop-color="#CA111A"/>
      <stop offset="45%" stop-color="#80060C"/>
      <stop offset="85%" stop-color="#2B0104"/>
      <stop offset="100%" stop-color="#140001"/>
    </radialGradient>

    <!-- Metallic Gold Gradient for Logo and Text -->
    <linearGradient id="gold-metallic" x1="0%" y1="10%" x2="100%" y2="90%">
      <stop offset="0%" stop-color="#FDF0C6"/>
      <stop offset="22%" stop-color="#C28D42"/>
      <stop offset="45%" stop-color="#F8E5A8"/>
      <stop offset="70%" stop-color="#A97534"/>
      <stop offset="100%" stop-color="#FDE8B1"/>
    </linearGradient>

    <!-- Edge Light Gradients -->
    <linearGradient id="edge-light-top" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#3A0505"/>
      <stop offset="25%" stop-color="#CA7834"/>
      <stop offset="50%" stop-color="#FCE1A3"/>
      <stop offset="75%" stop-color="#9C5219"/>
      <stop offset="100%" stop-color="#3A0505"/>
    </linearGradient>

    <linearGradient id="edge-light-bottom" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#1A0001"/>
      <stop offset="40%" stop-color="#1A0001"/>
      <stop offset="70%" stop-color="#DDA867"/>
      <stop offset="100%" stop-color="#1A0001"/>
    </linearGradient>

    <!-- Drop Shadow for Logo and Text -->
    <filter id="drop-shadow" x="-10%" y="-10%" width="130%" height="130%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000" flood-opacity="0.8"/>
    </filter>

    <!-- Glow for Sparkles and Abstract light bleeds -->
    <filter id="blur-heavy" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="40"/>
    </filter>
    <filter id="blur-light" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="3"/>
    </filter>
  </defs>

  <!-- Base Dark Background -->
  <rect width="1000" height="450" rx="45" fill="#140001"/>

  <!-- Radial Red Glow -->
  <rect width="1000" height="450" rx="45" fill="url(#bg-glow)"/>

  <!-- Ambient Light Bleeds (Corners) -->
  <ellipse cx="100" cy="50" rx="200" ry="150" fill="#E8A95A" opacity="0.15" filter="url(#blur-heavy)"/>
  <ellipse cx="900" cy="400" rx="250" ry="150" fill="#E8A95A" opacity="0.12" filter="url(#blur-heavy)"/>

  <!-- Abstract Wave Lines (Left) -->
  <g fill="none" stroke="#E8C588" stroke-width="1.2" opacity="0.15">
    <path d="M -20,100 C 150,120 200,280 50,470" />
    <path d="M -20,140 C 180,180 180,320 0,470" />
    <path d="M -20,180 C 120,200 130,350 30,470" />
    <path d="M -20,220 C 80,240 100,400 10,470" />
    
    <path d="M 50,-20 C 100,80 80,200 -20,250" />
    <path d="M 100,-20 C 150,100 120,220 -20,300" />
  </g>

  <!-- Abstract Wave Lines (Right) -->
  <g fill="none" stroke="#E8C588" stroke-width="1.2" opacity="0.15">
    <path d="M 1020,50 C 850,80 800,220 950,470" />
    <path d="M 1020,100 C 820,150 780,280 980,470" />
    <path d="M 1020,150 C 880,180 820,320 900,470" />
    <path d="M 1020,200 C 920,220 860,360 930,470" />
    
    <path d="M 850,-20 C 850,80 900,180 1020,220" />
    <path d="M 780,-20 C 800,100 880,220 1020,280" />
  </g>

  <!-- Sparkles & Dust -->
  <g fill="#FDEBAF">
    <!-- Left side sparkles -->
    <circle cx="120" cy="280" r="1.5" />
    <circle cx="120" cy="280" r="4" opacity="0.4" filter="url(#blur-light)"/>
    <circle cx="135" cy="315" r="1" opacity="0.6"/>
    <circle cx="95"  cy="250" r="1" opacity="0.8"/>
    <circle cx="160" cy="360" r="1.5" opacity="0.7"/>
    <circle cx="80"  cy="340" r="2.5" opacity="0.3" filter="url(#blur-light)"/>
    <circle cx="230" cy="335" r="1.2" opacity="0.5"/>
    <circle cx="190" cy="205" r="1"/>

    <!-- Right side sparkles -->
    <circle cx="830" cy="140" r="2" />
    <circle cx="830" cy="140" r="5" opacity="0.4" filter="url(#blur-light)"/>
    <circle cx="850" cy="190" r="1.2" opacity="0.8"/>
    <circle cx="875" cy="130" r="1" opacity="0.6"/>
    <circle cx="770" cy="135" r="1.5" opacity="0.5"/>
    <circle cx="890" cy="220" r="2" opacity="0.3" filter="url(#blur-light)"/>
    <circle cx="800" cy="90"  r="1.2"/>
  </g>

  <!-- Edge Lighting Overlays (to create the glossy 3D rim effect) -->
  <rect x="2" y="2" width="996" height="446" rx="43" fill="none" stroke="url(#edge-light-top)" stroke-width="2.5" opacity="0.9"/>
  <rect x="2" y="2" width="996" height="446" rx="43" fill="none" stroke="url(#edge-light-bottom)" stroke-width="2.5" opacity="0.6" transform="rotate(180 500 225)"/>

  <!-- Center Content: Logo and Text grouped for consistent shadowing -->
  <g filter="url(#drop-shadow)">
    
    <!-- Instagram Logo -->
    <g transform="translate(175, 155)">
      <!-- Outer Rounded Square -->
      <rect x="0" y="0" width="130" height="130" rx="32" ry="32" fill="none" stroke="url(#gold-metallic)" stroke-width="15"/>
      <!-- Inner Circle -->
      <circle cx="65" cy="65" r="32" fill="none" stroke="url(#gold-metallic)" stroke-width="14"/>
      <!-- Top Right Dot -->
      <circle cx="102" cy="28" r="8.5" fill="url(#gold-metallic)"/>
    </g>

    <!-- Typography: @uranium.tv -->
    <text x="330" y="248" 
          font-family="'Montserrat', 'Century Gothic', 'Twentieth Century', 'Segoe UI', sans-serif" 
          font-size="88" 
          font-weight="600" 
          letter-spacing="-1.5" 
          fill="url(#gold-metallic)">@uranium.tv</text>

  </g>
</svg>"""

    // Default Uranium TV promo page. To customise: create the file
    // android/app/src/main/assets/promo.html - if it exists it is used instead of this.
    private val promoHtmlDefault = """<!DOCTYPE html><html><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1'>
<title>Uranium TV</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{background:#06080D;color:#fff;font-family:Roboto,Arial,sans-serif}
body{min-height:100vh;padding:0 18px 44px;overflow-x:hidden}
body::before,body::after{content:'';position:fixed;z-index:-1;width:80vw;height:80vw;border-radius:50%;filter:blur(55px);opacity:.6;animation:float 14s ease-in-out infinite alternate;pointer-events:none}
body::before{top:-22vw;left:-24vw;background:radial-gradient(circle,#00E5FF66,transparent 65%)}
body::after{bottom:-28vw;right:-26vw;background:radial-gradient(circle,#7C4DFF77,transparent 65%);animation-delay:-7s}
@keyframes float{0%{transform:translate3d(0,0,0) scale(1)}100%{transform:translate3d(9vw,7vw,0) scale(1.2)}}
.bar{display:flex;justify-content:flex-end;padding:16px 0}
.close{width:40px;height:40px;border-radius:50%;border:1px solid #ffffff30;background:#ffffff14;color:#fff;font-size:18px}
.hero{text-align:center;padding:6px 0 20px}
.logo{width:96px;height:96px;animation:pulse 3.4s ease-in-out infinite}
@keyframes pulse{0%,100%{filter:drop-shadow(0 0 14px #ff1e3877)}50%{filter:drop-shadow(0 0 30px #ff0019aa)}}
h1{font-size:32px;margin-top:16px;letter-spacing:1px;background:linear-gradient(90deg,#fff,#8ff0ff,#d6b8ff,#fff);background-size:200% auto;-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;animation:shine 6s linear infinite}
@keyframes shine{to{background-position:200% center}}
.tag{color:#9fb3c8;margin-top:8px;font-size:15px;line-height:1.5}
.card{position:relative;overflow:hidden;background:#ffffff0c;border:1px solid #ffffff1c;border-radius:16px;padding:16px;margin-top:14px;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
.card::after{content:'';position:absolute;top:0;bottom:0;left:-60%;width:40%;background:linear-gradient(100deg,transparent,#ffffff14,transparent);transform:skewX(-18deg);animation:sheen 6s ease-in-out infinite}
.card:nth-of-type(2)::after{animation-delay:1.2s}.card:nth-of-type(3)::after{animation-delay:2.4s}
@keyframes sheen{0%,60%{left:-60%}100%{left:130%}}
.card h3{font-size:16px;color:#00E5FF;margin-bottom:6px}
.card p{font-size:14px;color:#c5d0dc;line-height:1.55}
.cta{display:block;width:100%;margin-top:24px;padding:15px;border:0;border-radius:14px;color:#fff;font-size:16px;font-weight:700;background:linear-gradient(90deg,#FF3B30,#C2185B,#7C4DFF,#FF3B30);background-size:300% 100%;animation:flow 6s linear infinite;box-shadow:0 0 24px #c2185b55}
@keyframes flow{to{background-position:300% 0}}
.foot{text-align:center;color:#6c7a89;font-size:12px;margin-top:26px}
</style></head><body>
<div class='bar'><button class='close' onclick='UraniumNative.closePromo()'>&#10005;</button></div>
<div class='hero'>
<img class='logo' src='/uranium-logo.svg' alt='Uranium TV'>
<h1>Uranium TV</h1>
<p class='tag'>Your entertainment, all in one app.</p>
</div>
<!-- EDIT THE CARDS BELOW WITH YOUR OWN TEXT -->
<div class='card'><h3>All your OTT apps</h3><p>Move between your favourite OTT apps from one place. More apps are coming soon.</p></div>
<div class='card'><h3>Watch with friends</h3><p>Create a room, invite your friends and join them to watch together - same movie, same moment, wherever you are.</p></div>
<div class='card'><h3>Requests &amp; updates</h3><p>Ask for movies and series, and get the latest news and updates from us.</p></div>
<button class='cta' onclick='UraniumNative.openInstagram()'>Follow us on Instagram</button>
<p class='foot'>Uranium TV</p>
</body></html>"""

    private val TARGET_URL = "https://net52.cc/mobile/home?app=1"
    private val COOKIE_URL = "https://net52.cc"
    private lateinit var prefs: SharedPreferences

    // ====================== ON CREATE ======================
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        prefs = getSharedPreferences("alpha_tv_session", Context.MODE_PRIVATE)

        rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)
        }

        mainWebView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        setupNativeOverlay()
        rootLayout.addView(mainWebView)
        rootLayout.addView(nativeOverlay)
        setupPromoContainer()
        setupFullscreenContainer()
        setContentView(rootLayout)
        playOverlayIntro()

        setupBackHandler()
        setupCookies()
        setupMainWebView()

        // Restore previous session cookies if available
        restoreSavedCookies()

        mainWebView.loadUrl(TARGET_URL)
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    adPanel != null -> closeAdPanel(reload = false)
                    customView != null -> hideCustomView()
                    promoOpen -> hidePromo()
                    playerOpen -> closePlayerPanel()
                    mainWebView.canGoBack() -> mainWebView.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    // ====================== OVERLAY ======================
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    // Native overlay: lives outside the web page, so the site can never see or detect it.
    // It is visible from the very first frame and covers the WebView completely.
    private inner class OverlayLayout(context: Context) : FrameLayout(context) {
        var onShown: (() -> Unit)? = null

        override fun onVisibilityChanged(changedView: View, visibility: Int) {
            super.onVisibilityChanged(changedView, visibility)
            if (changedView === this && visibility == View.VISIBLE) onShown?.invoke()
        }
    }

    private fun setupNativeOverlay() {
        val overlay = OverlayLayout(this)
        overlay.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        overlay.setBackgroundColor(Color.parseColor("#FF050B10"))
        overlay.isClickable = true
        overlay.onShown = { playOverlayIntro() }
        nativeOverlay = overlay

        overlayContent = LinearLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            orientation = LinearLayout.VERTICAL
            clipChildren = false
        }

        overlayHeader = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(12), dp(24), dp(8))
        }

        countdownRing = CountdownRingView(this, VERIFY_COUNTDOWN_MS).apply {
            remainingProvider = {
                if (isVerifying) {
                    (VERIFY_COUNTDOWN_MS - (SystemClock.uptimeMillis() - verificationStartTime))
                        .coerceIn(0L, VERIFY_COUNTDOWN_MS)
                } else VERIFY_COUNTDOWN_MS
            }
        }
        overlayHeader.addView(countdownRing, LinearLayout.LayoutParams(dp(96), dp(96)))

        // Heading shows only the first line (the poll sets "title\nUnlocking in Ns",
        // the number itself is shown inside the ring).
        statusText = TextView(this).apply {
            text = "Loading Uranium TV..."
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(0, dp(12), 0, dp(4))
        }

        subStatusText = TextView(this).apply {
            text = "Please wait a moment"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 13f
            gravity = Gravity.CENTER
        }

        overlayHeader.addView(statusText)
        overlayHeader.addView(subStatusText)

        interactiveView = ChainReactionView(this)
        interactiveView.visibility = View.INVISIBLE

        overlayContent.addView(overlayHeader)
        overlayContent.addView(
            interactiveView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        nativeOverlay.addView(overlayContent)
    }

    private fun runWhenLaidOut(v: View, block: () -> Unit) {
        if (v.isLaidOut && v.width > 0 && v.height > 0) {
            block()
            return
        }
        v.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(
                view: View?, l: Int, t: Int, r: Int, b: Int,
                oldL: Int, oldT: Int, oldR: Int, oldB: Int
            ) {
                if (v.width > 0 && v.height > 0) {
                    v.removeOnLayoutChangeListener(this)
                    block()
                }
            }
        })
    }

    // Step 1: verification text + countdown ring sit in the centre of the screen.
    // Step 2: after ~1.8s they glide to the top as a heading.
    // Step 3: the chain reaction game fades in below and starts.
    private fun playOverlayIntro() {
        val token = ++introToken
        introRunnable?.let { handler.removeCallbacks(it) }
        introRunnable = null
        overlayHeader.animate().cancel()
        interactiveView.prepareIntro()
        runWhenLaidOut(overlayContent) {
            if (token == introToken) {
                val offset = (overlayContent.height - overlayHeader.height) / 2f - overlayHeader.top
                overlayHeader.translationY = offset
                val r = Runnable { moveHeaderToTop(token) }
                introRunnable = r
                handler.postDelayed(r, INTRO_HOLD_MS)
            }
        }
    }

    private fun moveHeaderToTop(token: Int) {
        if (token != introToken || nativeOverlay.visibility != View.VISIBLE) return
        overlayHeader.animate()
            .translationY(0f)
            .setDuration(650L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                if (token == introToken && nativeOverlay.visibility == View.VISIBLE) {
                    interactiveView.releaseGame()
                }
            }
            .start()
    }

    private fun setupCookies() {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(mainWebView, true)
    }

    // ====================== MAIN WEBVIEW ======================
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupMainWebView() {
        val s = mainWebView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        @Suppress("DEPRECATION")
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true

        standardChromeUA = s.userAgentString
        s.userAgentString = "$standardChromeUA /OS.Gatu v3.0"

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(mainWebView, brandingScript, setOf("*"))
            documentStartInstalled = true
        }

        mainWebView.addJavascriptInterface(UraniumBridge(), "UraniumNative")
        mainWebView.addJavascriptInterface(VideoEventsBridge(), "AndroidVideoEvents")

        mainWebView.webViewClient = object : WebViewClient() {
            // Branded files (logo, placeholder, Instagram banner) are served from inside the app.
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val path = request?.url?.path?.lowercase() ?: ""
                captureTitleFromRequest(request?.url)
                brandedResponse(path)?.let { return it }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.contains("userver.")) {
                    showAdPanel(url, null)
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (playerOpen || customView != null || playerModeOn) forceExitPlayerMode()
                injectCustomBranding()
                handler.postDelayed({ injectCustomBranding() }, 150)
                handler.postDelayed({ injectCustomBranding() }, 500)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                CookieManager.getInstance().flush()
                injectCustomBranding()
                if (isVerifying) setPageAnimationsPaused(true)

                if (isVerifying) {
                    // Continue current verification after reload
                    handler.postDelayed({ startSmartPolling() }, 600)
                } else {
                    checkAndAutomateGate()
                }
            }
        }

        mainWebView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                showAdPanel(null, resultMsg)
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                if (window != null && window === phantomWebView) destroyPhantomWebView()
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) {
                    callback?.onCustomViewHidden()
                    return
                }
                if (!playerOpen && SystemClock.uptimeMillis() - lastPlayerCloseAt < 1200) {
                    callback?.onCustomViewHidden()
                    return
                }
                if (customView != null) hideCustomView()
                customView = view
                customViewCallback = callback
                customViewContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                )
                customViewContainer.visibility = View.VISIBLE
                updatePlayerMode()
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }
    }

    // ====================== SMART VERIFICATION ======================
    private fun checkAndAutomateGate() {
        if (isVerifying) return

        val js = """
            (function() {
                var btn = document.querySelector('.open-support.checker');
                var hash = document.body ? document.body.getAttribute('data-addhash') : null;
                return (btn && hash) ? "GATE_ACTIVE" : "UNLOCKED";
            })();
        """.trimIndent()

        mainWebView.evaluateJavascript(js) { result ->
            val gate = result != null && result.contains("GATE_ACTIVE")
            if (!gate) {
                saveCurrentCookies()
                justWatchedAd = false
                postAdReloads = 0
            } else if (justWatchedAd) {
                if (postAdReloads < 1) {
                    // The site may need a moment to register the view: try once more.
                    postAdReloads++
                    adHandler.postDelayed({ mainWebView.reload() }, 3000)
                } else {
                    justWatchedAd = false
                    postAdReloads = 0
                    // Show the site's own status line so we can see why it refused.
                    mainWebView.evaluateJavascript(
                        "(function(){var e=document.querySelector('.r5');return e?e.innerText:'';})();"
                    ) { raw ->
                        val why = (raw ?: "").trim('"').take(80)
                        Toast.makeText(
                            this,
                            "Not verified yet. Tap Click Here and watch the full ad." +
                                if (why.isNotEmpty() && why != "null") "\nSite says: $why" else "",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
            // Hide the loading overlay so the page (and the Click Here button) is usable.
            finishVerificationSuccess()
        }
    }

    private fun startSmartVerification() {
        if (isVerifying) return
        isVerifying = true
        reloadedForCookies = false
        baselineCookieNames = currentCookieNames()
        verificationStartTime = SystemClock.uptimeMillis()

        nativeOverlay.visibility = View.VISIBLE
        setPageAnimationsPaused(true)
        interactiveView.startAnimation()
        statusText.text = "Auto-Verifying Session..."
        subStatusText.text = "This can take up to 45 seconds"

        startSmartPolling()
    }

    private fun startSmartPolling() {
        stopPolling()
        if (!isVerifying) return

        pollRunnable = object : Runnable {
            override fun run() {
                if (!isVerifying) return

                val elapsed = SystemClock.uptimeMillis() - verificationStartTime
                val left = ((VERIFY_COUNTDOWN_MS - elapsed + 999) / 1000).coerceIn(0, 45)

                statusText.text = "Auto-Verifying Session...\nUnlocking in ${left}s"
                subStatusText.text = "Waiting for session..."

                // Check 1: is the gate gone?
                checkGateStatus { hasGate ->
                    if (!isVerifying) return@checkGateStatus

                    if (!hasGate) {
                        saveCurrentCookies()
                        finishVerificationSuccess()
                        return@checkGateStatus
                    }

                    // Check 2: did the site hand us new cookies? Reload once to pick them up.
                    if (!reloadedForCookies && hasNewCookies()) {
                        reloadedForCookies = true
                        statusText.text = "Session detected!\nUnlocking..."
                        handler.postDelayed({
                            CookieManager.getInstance().flush()
                            mainWebView.reload()
                        }, 300)
                        // Fallback in case the reload never finishes
                        handler.postDelayed(this, POLL_INTERVAL * 3)
                        return@checkGateStatus
                    }

                    // Timeout handling
                    if (elapsed >= VERIFY_COUNTDOWN_MS) {
                        // Countdown reached 0: stop verifying and let the page load as-is
                        statusText.text = "Finalizing..."
                        CookieManager.getInstance().flush()
                        saveCurrentCookies()
                        finishVerificationSuccess()
                        mainWebView.reload()
                    } else {
                        handler.postDelayed(this, POLL_INTERVAL)
                    }
                }
            }
        }
        handler.post(pollRunnable!!)
    }

    private fun checkGateStatus(callback: (Boolean) -> Unit) {
        val js = """
            (function() {
                var btn = document.querySelector('.open-support.checker');
                var hash = document.body ? document.body.getAttribute('data-addhash') : null;
                return (btn && hash) ? "YES" : "NO";
            })();
        """.trimIndent()
        mainWebView.evaluateJavascript(js) { result ->
            callback(result != null && result.contains("YES"))
        }
    }

    private fun currentCookieNames(): Set<String> {
        val raw = CookieManager.getInstance().getCookie(COOKIE_URL) ?: return emptySet()
        return raw.split(";")
            .map { it.substringBefore("=").trim() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    // A cookie counts as "useful" only if it appeared after verification started,
    // instead of guessing at generic names like "user" or "session".
    private fun hasNewCookies(): Boolean {
        return (currentCookieNames() - baselineCookieNames).isNotEmpty()
    }

    // While the native overlay (game) covers the page, the page's animated background is invisible
    // but would still be rendered; the 'u-playing' class switches those animations off.
    private fun setPageAnimationsPaused(paused: Boolean) {
        mainWebView.evaluateJavascript(
            "(function(){var h=document.documentElement;if(h)h.classList.toggle('u-playing'," + paused + ");})();",
            null
        )
    }

    private fun finishVerificationSuccess() {
        setPageAnimationsPaused(false)
        isVerifying = false
        stopPolling()
        handler.removeCallbacksAndMessages(null)
        interactiveView.stopAnimation()
        nativeOverlay.visibility = View.GONE
        destroyPhantomWebView()
        CookieManager.getInstance().flush()
        injectCustomBranding()
    }

    private fun stopPolling() {
        pollRunnable?.let { handler.removeCallbacks(it) }
        pollRunnable = null
    }

    // ====================== COOKIE PERSISTENCE ======================
    private fun saveCurrentCookies() {
        try {
            val cookies = CookieManager.getInstance().getCookie(COOKIE_URL) ?: return
            prefs.edit()
                .putString("saved_cookies", cookies)
                .putLong("saved_at", System.currentTimeMillis())
                .apply()
        } catch (_: Exception) {
        }
    }

    private fun restoreSavedCookies() {
        try {
            val saved = prefs.getString("saved_cookies", null) ?: return
            val savedAt = prefs.getLong("saved_at", 0L)
            // Only restore if less than 14 hours old
            if (System.currentTimeMillis() - savedAt > 14 * 60 * 60 * 1000L) return

            val cm = CookieManager.getInstance()
            saved.split(";").forEach { part ->
                val cookie = part.trim()
                if (cookie.isNotEmpty()) {
                    cm.setCookie(COOKIE_URL, "$cookie; Path=/")
                }
            }
            cm.flush()
        } catch (_: Exception) {
        }
    }

    // ====================== AD PANEL (visible ad step) ======================
    /**
     * Shows the ad page full screen inside the app. The countdown starts once the ad has loaded,
     * the panel closes by itself after AD_WATCH_MS, then the OTT page is reloaded so the site
     * can unlock. Pass [url] for a normal navigation, or [transportMsg] for window.open().
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun showAdPanel(url: String?, transportMsg: Message?) {
        closeAdPanel(reload = false)
        justWatchedAd = false
        postAdReloads = 0

        val web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            // Same user agent as the main page (the ad page only accepts the app's agent)
            userAgentString = mainWebView.settings.userAgentString
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            // Stay inside the app: block market://, intent:// and other external schemes.
            override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                val scheme = r?.url?.scheme?.lowercase() ?: return true
                return scheme != "http" && scheme != "https"
            }

            override fun onPageFinished(v: WebView?, u: String?) {
                if (u != null && u != "about:blank") {
                    adInfoText?.text = "Ad page: " + (Uri.parse(u).host ?: u)
                    startAdCountdown()
                }
            }

            override fun onReceivedError(
                v: WebView?, r: WebResourceRequest?, e: android.webkit.WebResourceError?
            ) {
                if (r?.isForMainFrame == true) {
                    adInfoText?.text = "Ad failed to load: ${e?.description ?: "network error"}"
                }
            }

            override fun onReceivedHttpError(
                v: WebView?, r: WebResourceRequest?, e: WebResourceResponse?
            ) {
                if (r?.isForMainFrame == true) {
                    adInfoText?.text = "Ad page returned HTTP ${e?.statusCode}"
                }
            }
        }

        val title = TextView(this).apply {
            text = "Watching the ad to unlock Uranium TV"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        }
        val timeText = TextView(this).apply {
            text = "Loading ad..."
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 13f
        }
        val infoText = TextView(this).apply {
            text = "Opening ad..."
            setTextColor(Color.parseColor("#8899AA"))
            textSize = 11f
        }
        val cancel = TextView(this).apply {
            text = "Cancel"
            setTextColor(Color.parseColor("#FF6B6B"))
            textSize = 14f
            setPadding(dp(12), dp(8), dp(4), dp(8))
            setOnClickListener { closeAdPanel(reload = false) }
        }
        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(timeText)
            addView(infoText)
        }
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#FF050B10"))
            setPadding(dp(16), dp(10), dp(12), dp(10))
            addView(labels, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(cancel)
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 0
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            fitsSystemWindows = true
            addView(topRow)
            addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)))
            addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        val panel = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isClickable = true
            addView(
                column,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        adPanel = panel
        adWebView = web
        adTimeText = timeText
        adBar = bar
        adInfoText = infoText
        rootLayout.addView(
            panel,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        if (transportMsg != null) {
            val transport = transportMsg.obj as? WebView.WebViewTransport
            transport?.webView = web
            transportMsg.sendToTarget()
        } else if (url != null) {
            web.loadUrl(url)
        }

        // If the ad page never reports "finished", start counting anyway after 10 seconds.
        adHandler.postDelayed({ startAdCountdown() }, 10000L)
    }

    private fun startAdCountdown() {
        if (adTimerStarted || adPanel == null) return
        adTimerStarted = true
        adTimer = object : android.os.CountDownTimer(AD_WATCH_MS, 200L) {
            override fun onTick(left: Long) {
                val secs = ((left + 999) / 1000).toInt()
                adTimeText?.text = "Please keep the ad open: ${secs}s left"
                adBar?.progress = (((AD_WATCH_MS - left) * 1000L) / AD_WATCH_MS).toInt()
            }

            override fun onFinish() {
                adBar?.progress = 1000
                closeAdPanel(reload = true)
            }
        }.start()
    }

    private fun closeAdPanel(reload: Boolean) {
        adTimer?.cancel()
        adTimer = null
        adHandler.removeCallbacksAndMessages(null)
        adTimerStarted = false
        adPanel?.let { rootLayout.removeView(it) }
        adPanel = null
        adTimeText = null
        adBar = null
        adInfoText = null
        adWebView?.let {
            it.stopLoading()
            it.loadUrl("about:blank")
            it.destroy()
        }
        adWebView = null
        if (reload) {
            justWatchedAd = true
            postAdReloads = 0
            CookieManager.getInstance().flush()
            mainWebView.reload()
        }
    }

    // ====================== PHANTOM WEBVIEW ======================
    @SuppressLint("SetJavaScriptEnabled")
    private fun createPhantomWebView(): WebView {
        val phantom = WebView(this)
        val s = phantom.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.userAgentString = standardChromeUA
        // Keep navigation inside the phantom view so it never opens an external browser
        phantom.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(phantom, true)
        return phantom
    }

    private fun launchPhantomVerifier(url: String) {
        destroyPhantomWebView()
        val phantom = createPhantomWebView()
        phantomWebView = phantom
        rootLayout.addView(phantom, FrameLayout.LayoutParams(1, 1))
        phantom.loadUrl(url)
    }

    private fun destroyPhantomWebView() {
        phantomWebView?.let {
            rootLayout.removeView(it)
            it.stopLoading()
            it.loadUrl("about:blank")
            it.destroy()
        }
        phantomWebView = null
    }

    // ====================== BRANDING ======================
    // The script guards itself with window.__uraniumBrand, so running it again after the
    // document-start copy is harmless. Always injecting makes branding work even on WebViews
    // where the document-start script is "supported" but silently does not run.
    private fun injectCustomBranding() {
        mainWebView.evaluateJavascript(brandingScript, null)
    }

    /**
     * Injected before the page is parsed (document-start), so everything happens instantly:
     * 1. "NetMirror" -> "Uranium TV" in text, title, alt/title attributes and meta tags
     *    (external netmirror links and domain names are left alone).
     * 2. "Join Our TeleGram Channel Now" -> "Follow my Instagram account now" and the Telegram
     *    picture -> red gradient box; tapping the box opens Instagram.
     * 3. Tapping the top-left logo or the top-right profile icon opens the Uranium TV promo page.
     * 4. Reports the video panel (#player) opening/closing to the app so it can switch to
     *    landscape + full screen and back to portrait.
     * 5. Hides the "NetMirror is First Mirror Copy..." promo box (.note-msg).
     * 6. Draws the animated Uranium background behind every OTT page (#uranium-bg).
     */
    private val brandingScript = """
        (function () {
            if (window.top !== window.self) return;   // top page only, never inside ad/embed iframes
            if (window.__uraniumBrand) return;
            window.__uraniumBrand = true;

            var NEW_NAME = 'Uranium TV';
            var RE = /net\s?mirror(?!\.(?:gg|app|cc|com|net|org|in|xyz|co|io|me|apk))/gi;
            var TG_RE = /join\s+our\s+tele\s?gram\s+channel\s+now/gi;
            var TG_TEXT = 'Follow my Instagram account now';
            var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEXTAREA: 1 };
            var ATTRS = ['alt', 'title', 'placeholder', 'aria-label'];

            function swap(m) {
                return m === m.toUpperCase() ? NEW_NAME.toUpperCase() : NEW_NAME;
            }

            function rewrite(s) {
                return s.replace(RE, swap).replace(TG_RE, TG_TEXT);
            }

            function inExternalLink(node) {
                var el = node.nodeType === 1 ? node : node.parentElement;
                var a = (el && el.closest) ? el.closest('a[href]') : null;
                return !!(a && /netmirror/i.test(a.getAttribute('href') || ''));
            }

            function fixText(t) {
                var p = t.parentNode;
                if (!p || SKIP[p.nodeName]) return;
                var s = t.nodeValue;
                if (!s || s.length < 9) return;
                var out = rewrite(s);
                if (out !== s && !inExternalLink(t)) t.nodeValue = out;
            }

            function fixValue(el, name) {
                var v = el.getAttribute(name);
                if (!v || v.length < 9 || /^(https?:)?\/\//i.test(v)) return;
                var out = rewrite(v);
                if (out !== v) el.setAttribute(name, out);
            }

            function fixAttrs(el) {
                if (el.nodeType !== 1) return;
                for (var i = 0; i < ATTRS.length; i++) fixValue(el, ATTRS[i]);
                if (el.nodeName === 'META') fixValue(el, 'content');
            }

            function walk(root) {
                if (!root) return;
                if (root.nodeType === 3) { fixText(root); return; }
                if (root.nodeType === 1) {
                    if (SKIP[root.nodeName]) return;
                    fixAttrs(root);
                } else if (root.nodeType !== 9 && root.nodeType !== 11) {
                    return;
                }
                var tw = document.createTreeWalker(root, 5, null);
                var n;
                while ((n = tw.nextNode())) {
                    if (n.nodeType === 3) fixText(n);
                    else if (!SKIP[n.nodeName]) fixAttrs(n);
                }
            }

            // ---------- CSS (applied the moment <head>/<html> exists) ----------
            var cssDone = false;
            function ensureCss() {
                if (cssDone) return;
                var host = document.head || document.documentElement;
                if (!host) return;
                var st = document.createElement('style');
                st.id = 'uranium-brand-css';
                st.textContent =
                    '.note-msg{display:none!important}' +
                    // ---- buffering: red Uranium radiation symbol rotating 360 degrees ----
                    '#uranium-buffer{position:absolute;left:50%;top:50%;width:88px;height:88px;margin:-44px 0 0 -44px;' +
                    'z-index:2147483000;pointer-events:none;display:none}' +
                    '#uranium-buffer.on{display:block}' +
                    '#uranium-buffer img{display:block;width:100%;height:100%;will-change:transform;' +
                    'animation:uranium-radiate 1.1s linear infinite;filter:drop-shadow(0 0 12px rgba(255,20,40,.65))}' +
                    '@keyframes uranium-radiate{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}' +
                    '#player .jw-svg-icon-buffer{display:none!important}' +
                    '.player:not(.hide) .jw{background:none!important;transform:none!important;transition:none!important}' +
                    'html.u-playing #uranium-bg{display:none!important}' +
                    'html.u-playing .uranium-ig-box,html.u-playing .uranium-ig-box::before,' +
                    'html.u-playing .uranium-ig-box::after,html.u-playing .telegram-btn h4{animation:none!important}' +
                    // ---- page must let the animated layer show through ----
                    'html{background:#000!important}body{background:transparent!important}' +
                    '.ott-list .ott-apps{background:transparent!important}' +
                    // ---- Uranium animated background (all OTTs) ----
                    '#uranium-bg{position:fixed;top:0;left:0;right:0;bottom:0;z-index:-1;pointer-events:none;overflow:hidden;' +
                    'background:radial-gradient(120% 85% at 50% -10%,#0a1f12 0%,#04100a 38%,#010503 72%,#000 100%)}' +
                    '#uranium-bg::after{content:"";position:absolute;top:0;left:0;right:0;bottom:0;' +
                    'background:radial-gradient(130% 95% at 50% 42%,rgba(0,0,0,0) 48%,rgba(0,0,0,.6) 100%)}' +
                    '.u-orb{position:absolute;border-radius:50%;will-change:transform}' +
                    '.u-o1{width:120vmax;height:120vmax;left:-52vmax;top:-62vmax;' +
                    'background:radial-gradient(circle,rgba(57,255,136,.34) 0%,rgba(57,255,136,0) 62%);' +
                    'animation:u-f1 24s ease-in-out infinite alternate}' +
                    '.u-o2{width:100vmax;height:100vmax;right:-58vmax;top:8vmax;' +
                    'background:radial-gradient(circle,rgba(198,255,61,.20) 0%,rgba(198,255,61,0) 62%);' +
                    'animation:u-f2 30s ease-in-out infinite alternate}' +
                    '.u-o3{width:110vmax;height:110vmax;left:-30vmax;bottom:-70vmax;' +
                    'background:radial-gradient(circle,rgba(0,229,255,.22) 0%,rgba(0,229,255,0) 62%);' +
                    'animation:u-f3 28s ease-in-out infinite alternate}' +
                    '.u-o4{width:90vmax;height:90vmax;right:-40vmax;bottom:-50vmax;' +
                    'background:radial-gradient(circle,rgba(124,77,255,.22) 0%,rgba(124,77,255,0) 62%);' +
                    'animation:u-f1 34s ease-in-out infinite alternate-reverse}' +
                    '@keyframes u-f1{0%{transform:translate3d(0,0,0) scale(1)}100%{transform:translate3d(18vmax,12vmax,0) scale(1.18)}}' +
                    '@keyframes u-f2{0%{transform:translate3d(0,0,0) scale(1.1)}100%{transform:translate3d(-20vmax,16vmax,0) scale(.92)}}' +
                    '@keyframes u-f3{0%{transform:translate3d(0,0,0) scale(1)}100%{transform:translate3d(16vmax,-14vmax,0) scale(1.2)}}' +
                    '.u-ring{position:absolute;left:50%;top:36%;width:140vmin;height:140vmin;margin:-70vmin 0 0 -70vmin;' +
                    'animation:u-spin 100s linear infinite;opacity:.9}' +
                    '.u-ring i{position:absolute;left:0;top:31%;width:100%;height:38%;border-radius:50%;' +
                    'border:1px solid rgba(120,255,170,.12)}' +
                    '.u-ring i:nth-child(2){transform:rotate(60deg)}.u-ring i:nth-child(3){transform:rotate(120deg)}' +
                    '.u-ring::after{content:"";position:absolute;left:50%;top:31%;width:7px;height:7px;margin-left:-3px;' +
                    'border-radius:50%;background:#b6ffb0;box-shadow:0 0 14px 5px rgba(124,255,120,.55)}' +
                    '@keyframes u-spin{to{transform:rotate(360deg)}}' +
                    '.u-motes{position:absolute;left:0;right:0;top:0;bottom:-360px;will-change:transform}' +
                    '.u-m1{opacity:.75;background-size:360px 360px;animation:u-rise1 38s linear infinite;' +
                    'background-image:radial-gradient(circle at 12% 18%,#9dff9d 0,#9dff9d 1.2px,transparent 2.6px),' +
                    'radial-gradient(circle at 63% 72%,#d7ff6b 0,#d7ff6b 1px,transparent 2.4px),' +
                    'radial-gradient(circle at 85% 30%,#7df3ff 0,#7df3ff 1.2px,transparent 2.6px),' +
                    'radial-gradient(circle at 38% 55%,#9dff9d 0,#9dff9d .9px,transparent 2px),' +
                    'radial-gradient(circle at 72% 8%,#fff 0,#fff .8px,transparent 1.8px)}' +
                    '.u-m2{opacity:.5;background-size:240px 240px;animation:u-rise2 26s linear infinite;' +
                    'background-image:radial-gradient(circle at 20% 70%,#9dff9d 0,#9dff9d .8px,transparent 1.8px),' +
                    'radial-gradient(circle at 78% 40%,#b9ff7a 0,#b9ff7a .7px,transparent 1.6px),' +
                    'radial-gradient(circle at 50% 12%,#7df3ff 0,#7df3ff .7px,transparent 1.6px)}' +
                    '@keyframes u-rise1{to{transform:translate3d(0,-360px,0)}}' +
                    '@keyframes u-rise2{to{transform:translate3d(0,-240px,0)}}' +
                    '.header .brand-logo{object-fit:contain!important;border-radius:8px!important;' +
                    'filter:drop-shadow(0 0 6px rgba(255,30,56,.55))!important}' +
                    '@property --uang{syntax:"<angle>";inherits:false;initial-value:0deg}' +
                    '@keyframes uranium-spin{to{--uang:360deg}}' +
                    '@keyframes uranium-drift{0%{transform:translate3d(-5%,-4%,0) rotate(0deg)}' +
                    '100%{transform:translate3d(5%,4%,0) rotate(20deg)}}' +
                    '@keyframes uranium-sheen{0%,55%{transform:translateX(-150%) skewX(-18deg)}100%{transform:translateX(325%) skewX(-18deg)}}' +
                    '@keyframes uranium-text{to{background-position:200% center}}' +
                    '.uranium-ig-box{--uang:0deg;position:relative!important;isolation:isolate;overflow:hidden!important;' +
                    'border:2px solid transparent!important;border-radius:18px!important;' +
                    'background:linear-gradient(135deg,rgba(5,9,18,.97),rgba(11,6,26,.97)) padding-box,' +
                    'conic-gradient(from var(--uang),#00E5FF,#7C4DFF,#FF2A85,#FFB300,#00E676,#00E5FF) border-box!important;' +
                    'box-shadow:0 0 22px rgba(124,77,255,.28),0 0 46px rgba(0,229,255,.12)!important}' +
                    '.uranium-ig-box::before{content:"";position:absolute;top:-40%;left:-40%;right:-40%;bottom:-40%;' +
                    'z-index:-1;pointer-events:none;will-change:transform;' +
                    'background:radial-gradient(40% 40% at 25% 30%,rgba(0,229,255,.22),transparent 70%),' +
                    'radial-gradient(35% 35% at 75% 65%,rgba(255,42,133,.20),transparent 70%),' +
                    'radial-gradient(30% 30% at 55% 20%,rgba(124,77,255,.24),transparent 70%);' +
                    'animation:uranium-drift 9s ease-in-out infinite alternate}' +
                    '.uranium-ig-box::after{content:"";position:absolute;top:0;bottom:0;left:0;width:40%;will-change:transform;' +
                    'z-index:1;pointer-events:none;' +
                    'background:linear-gradient(100deg,transparent,rgba(255,255,255,.10),transparent);' +
                    'transform:translateX(-150%) skewX(-18deg);animation:uranium-sheen 4.5s ease-in-out infinite}' +
                    '.telegram-btn h4{background:linear-gradient(90deg,#fff 0%,#8ff0ff 35%,#d6b8ff 65%,#fff 100%);' +
                    'background-size:200% auto;-webkit-background-clip:text;background-clip:text;' +
                    '-webkit-text-fill-color:transparent}' +
                    '.telegram-btn img{object-fit:contain!important;border-radius:14px!important}';
                host.appendChild(st);
                cssDone = true;
            }

            // ---------- Uranium animated background layer (added the moment <html> exists) ----------
            var bgEl = null;
            function ensureBg() {
                if (bgEl && bgEl.isConnected) return;
                var root = document.documentElement;
                if (!root) return;
                var d = document.createElement('div');
                d.id = 'uranium-bg';
                d.setAttribute('aria-hidden', 'true');
                d.innerHTML =
                    '<i class="u-orb u-o1"></i><i class="u-orb u-o2"></i>' +
                    '<i class="u-orb u-o3"></i><i class="u-orb u-o4"></i>' +
                    '<i class="u-ring"><i></i><i></i><i></i></i>' +
                    '<i class="u-motes u-m1"></i><i class="u-motes u-m2"></i>';
                root.appendChild(d);
                bgEl = d;
            }

            // ---------- taps: logo / profile icon -> promo page, Telegram box -> Instagram ----------
            // A button whose only text is "Download" (icon + word), or the site's own download buttons
            function isDownloadButton(t) {
                if (t.closest('.app-download, .appdownload')) return false;
                if (t.closest('.downloadStart, .model-btn-download')) return true;
                var el = t;
                for (var i = 0; i < 5 && el && el !== document.body; i++, el = el.parentElement) {
                    var txt = el.textContent || '';
                    if (txt.length > 40) return false;          // already a big container
                    if (txt.replace(/\s+/g, ' ').trim().toLowerCase() === 'download') return true;
                }
                return false;
            }

            function openPromoFrom(e) {
                e.preventDefault();
                e.stopImmediatePropagation();
                window.UraniumNative.openPromo();
            }

            document.addEventListener('click', function (e) {
                var t = e.target;
                if (!t || !t.closest || !window.UraniumNative) return;
                // Instagram box (old Telegram box) -> Instagram page
                if (t.closest('.telegram-btn, .uranium-ig-box, [data-uranium-ig="1"]')) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    window.UraniumNative.openInstagram();
                    return;
                }
                // top-left logo, or the profile icon on any page (opened the email/login box) -> promo
                if (t.closest('.nav-container .nav-logo, .account, .profile-icon')) {
                    openPromoFrom(e);
                    return;
                }
                // Download buttons (used to show "Download is not available") -> promo
                if (isDownloadButton(t)) {
                    openPromoFrom(e);
                }
            }, true);

            // Any other "download ..." pop-up message from the site also opens the promo instead
            function hookAlert() {
                var f = window.alert_msg;
                if (typeof f !== 'function' || f.__uraniumHooked) return;
                var w = function (color, msg) {
                    if (/download/i.test(String(msg || '')) && window.UraniumNative) {
                        window.UraniumNative.openPromo();
                        return;
                    }
                    return f.apply(this, arguments);
                };
                w.__uraniumHooked = true;
                window.alert_msg = w;
            }

            // ---------- animated Instagram box (the old Telegram box) ----------
            var IG_URL = '/__uranium/instagram.svg';
            var igBox = null, igRuns = 0, igLast = 0;

            // Swap every picture inside the box (an <img> or a CSS background) for the red gradient.
            function brandIgVisuals(box) {
                var all = box.querySelectorAll('*');
                for (var i = 0; i < all.length; i++) {
                    var el = all[i];
                    if (el.getAttribute('data-uranium-ig') === '1') continue;
                    if (el.nodeName === 'IMG') {
                        el.setAttribute('data-uranium-ig', '1');
                        el.removeAttribute('srcset');
                        el.removeAttribute('data-src');
                        el.src = IG_URL;
                    } else if (el.nodeName !== 'H4' && el.nodeName !== 'SPAN' && el.nodeName !== 'P') {
                        var bg = window.getComputedStyle(el).backgroundImage;
                        if (bg && bg !== 'none' && bg.indexOf('url(') > -1 && bg.indexOf('__uranium') < 0) {
                            el.setAttribute('data-uranium-ig', '1');
                            el.style.setProperty('background-image', 'url("' + IG_URL + '")', 'important');
                            el.style.setProperty('background-size', '100% 100%', 'important');
                            el.style.setProperty('background-repeat', 'no-repeat', 'important');
                        }
                    }
                }
            }

            function tryMarkIg() {
                var btn = document.querySelector('.telegram-btn');
                if (!btn) return;
                if (!igBox || !igBox.isConnected) {
                    var box = null, el = btn;
                    for (var i = 0; i < 3 && el.parentElement; i++) {
                        el = el.parentElement;
                        if (el.querySelector('.telegram-msg')) { box = el; break; }
                    }
                    if (!box) {
                        if (document.readyState === 'loading') return;
                        box = btn;
                    }
                    if (box.querySelectorAll('*').length > 40) box = btn;   // never grab a huge container
                    box.classList.add('uranium-ig-box');
                    igBox = box;
                    igRuns = 0;
                }
                var now = Date.now();
                if (igRuns < 60 && now - igLast > 250) {
                    igLast = now;
                    igRuns++;
                    brandIgVisuals(igBox);
                }
            }

            // ---------- video panel -> landscape + full screen ----------
            var playing = false, pendingWork = false;
            function setPlaying(open) {
                playing = open;
                document.documentElement.classList.toggle('u-playing', open);
                if (!open && pendingWork) {
                    pendingWork = false;
                    walk(document);
                    tryMarkIg();
                }
            }

            // ---------- Buffering indicator (replaces the normal spinner / loader inside the video panel) ----------
            var bufEl = null;
            var bufTimer = 0;
            function bufShow(on) {
                if (!bufEl) return;
                if (on) bufEl.classList.add('on'); else bufEl.classList.remove('on');
            }
            function bufTick() {
                var p = document.getElementById('player');
                if (!p || p.classList.contains('hide')) { bufShow(false); return; }
                var host = p.querySelector('.jwplayer') || p;
                if (!bufEl) {
                    bufEl = document.createElement('div');
                    bufEl.id = 'uranium-buffer';
                    var im = document.createElement('img');
                    im.src = '/__uranium/radiation.webp';
                    im.alt = '';
                    im.draggable = false;
                    bufEl.appendChild(im);
                }
                if (bufEl.parentNode !== host) {
                    try {
                        if (window.getComputedStyle(host).position === 'static') host.style.position = 'relative';
                    } catch (err) {}
                    host.appendChild(bufEl);
                }
                var stateSel = '.jw-state-buffering,.jw-state-loading,.jw-state-stalled';
                var buffering = false;
                try { buffering = p.matches(stateSel) || !!p.querySelector(stateSel); } catch (err) {}
                // before JW Player finishes setup the site shows its own logo loader on <div class="jw" id="jw">
                if (p.querySelector('.jw')) buffering = true;
                var v = p.querySelector('video');
                var waiting = !!(v && !v.paused && !v.ended && v.readyState < 3);
                bufShow(buffering || waiting);
            }
            function ensureBuffer() {
                if (bufTimer) return;
                bufTimer = setInterval(bufTick, 250);
            }

            var playerHooked = false;
            function hookPlayer() {
                ensureBuffer();
                if (playerHooked) return;
                var el = document.getElementById('player');
                if (!el) return;
                playerHooked = true;
                var last = false;
                function report() {
                    var open = !el.classList.contains('hide');
                    if (open === last) return;
                    last = open;
                    setPlaying(open);
                    if (window.AndroidVideoEvents) {
                        try { if (open) AndroidVideoEvents.onPlayerOpen(); else AndroidVideoEvents.onPlayerClose(); } catch (err) {}
                    }
                }
                new MutationObserver(report).observe(el, { attributes: true, attributeFilter: ['class'] });
                report();
            }

            ensureCss();
            ensureBg();
            hookPlayer();
            tryMarkIg();
            walk(document);

            var mo = new MutationObserver(function (muts) {
                ensureCss();
                ensureBg();
                hookPlayer();
                if (playing) { pendingWork = true; return; }
                tryMarkIg();
                for (var i = 0; i < muts.length; i++) {
                    var m = muts[i];
                    if (m.type === 'childList') {
                        for (var j = 0; j < m.addedNodes.length; j++) walk(m.addedNodes[j]);
                    } else if (m.type === 'characterData') {
                        fixText(m.target);
                    } else if (m.type === 'attributes') {
                        var tg = m.target;
                        if (m.attributeName === 'src' || m.attributeName === 'data-src') {
                            if (tg.getAttribute && tg.getAttribute('data-uranium-ig') === '1' &&
                                tg.getAttribute('src') !== IG_URL) {
                                tg.removeAttribute('data-src');
                                tg.src = IG_URL;
                            }
                        } else {
                            fixAttrs(tg);
                        }
                    }
                }
            });
            mo.observe(document, {
                childList: true,
                subtree: true,
                characterData: true,
                attributes: true,
                attributeFilter: ['alt', 'title', 'placeholder', 'aria-label', 'content', 'src', 'data-src']
            });

            document.addEventListener('DOMContentLoaded', function () {
                ensureCss();
                ensureBg();
                hookPlayer();
                hookAlert();
                tryMarkIg();
                walk(document);
            });
            window.addEventListener('load', function () {
                hookAlert();
                ensureBg();
                tryMarkIg();
                setTimeout(tryMarkIg, 600);
                setTimeout(tryMarkIg, 1800);
                setTimeout(tryMarkIg, 4000);
            });
            // Tell the app when playback starts/ends so it can switch orientation
            if (window.AndroidVideoEvents) {
                document.addEventListener('play', function(e){
                    if (e.target && e.target.tagName === 'VIDEO') {
                        try { AndroidVideoEvents.onPlayerOpen(); } catch(err) {}
                    }
                }, true);
                document.addEventListener('ended', function(e){
                    if (e.target && e.target.tagName === 'VIDEO') {
                        try { AndroidVideoEvents.onPlayerClose(); } catch(err) {}
                    }
                }, true);
            }
        })();
    """.trimIndent()


    // ====================== BRANDED FILES / PROMO ======================
    private fun svgResponse(svg: String): WebResourceResponse =
        WebResourceResponse(
            "image/svg+xml",
            "UTF-8",
            200,
            "OK",
            mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "no-store"
            ),
            ByteArrayInputStream(svg.toByteArray(Charsets.UTF_8))
        )

    private fun brandedResponse(path: String): WebResourceResponse? {
        return when {
            logoPathSuffixes.any { path.endsWith(it) } -> svgResponse(logoSvg)
            path.endsWith("/img/p11111.png") -> svgResponse(placeholderSvg)
            path.endsWith("/__uranium/radiation.webp") -> radiationResponse()
            path.endsWith("/__uranium/instagram.svg") ||
                (path.contains("telegram") && imageExtensions.any { path.endsWith(it) }) ->
                svgResponse(instagramSvg)
            else -> null
        }
    }

    /** The red Uranium radiation symbol (res/drawable/nuclear_radiation.webp) used as the buffering indicator. */
    private fun radiationResponse(): WebResourceResponse? = try {
        WebResourceResponse("image/webp", null, resources.openRawResource(R.drawable.nuclear_radiation)).apply {
            responseHeaders = mapOf("Cache-Control" to "max-age=86400")
        }
    } catch (e: Exception) {
        null
    }

    private inner class UraniumBridge {
        @JavascriptInterface
        fun openPromo() {
            runOnUiThread { showPromo() }
        }

        @JavascriptInterface
        fun closePromo() {
            runOnUiThread { hidePromo() }
        }

        @JavascriptInterface
        fun openInstagram() {
            runOnUiThread { openInstagramProfile() }
        }
    }

    /** Opens the Uranium TV Instagram page in the Instagram app, or the browser if it is not installed. */
    private fun openInstagramProfile() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(instagramUrl))
            intent.setPackage("com.instagram.android")
            startActivity(intent)
        } catch (e: Exception) {
            openExternal(instagramUrl)
        }
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            // no app can open it - ignore
        }
    }

    private fun setupPromoContainer() {
        promoOverlay = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#FF090B10"))
            visibility = View.GONE
            isClickable = true
        }
        rootLayout.addView(promoOverlay)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showPromo() {
        if (promoOpen) return
        if (promoWebView == null) {
            val w = WebView(this)
            w.settings.javaScriptEnabled = true
            w.setBackgroundColor(Color.parseColor("#090B10"))
            w.addJavascriptInterface(UraniumBridge(), "UraniumNative")
            w.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val path = request?.url?.path?.lowercase() ?: ""
                    if (path.endsWith("/uranium-logo.svg")) return svgResponse(logoSvg)
                    return super.shouldInterceptRequest(view, request)
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val u = request?.url?.toString() ?: return true
                    if (u.startsWith("http")) {
                        openExternal(u)
                        return true
                    }
                    return false
                }
            }
            promoOverlay.addView(
                w,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            promoWebView = w
            // Use assets/promo.html if you add one, otherwise the built-in default page.
            val custom = try {
                assets.open("promo.html").bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                null
            }
            w.loadDataWithBaseURL(
                "https://uranium.local/",
                custom ?: promoHtmlDefault,
                "text/html",
                "UTF-8",
                null
            )
        }
        promoOverlay.visibility = View.VISIBLE
        promoOpen = true
    }

    private fun hidePromo() {
        promoOverlay.visibility = View.GONE
        promoOpen = false
    }

    // ====================== FULLSCREEN ======================
    private fun setupFullscreenContainer() {
        customViewContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
        }
        rootLayout.addView(customViewContainer)
    }

    // Android Back while the video panel is open: close the panel (like the on-page back arrow).
    // If there is no panel to close, make sure we do not stay stuck in landscape.
    private val backJs = """
        (function(){
            var p = document.getElementById('player');
            if (p && !p.classList.contains('hide')) {
                var b = document.querySelector('.btn-payer-back');
                if (b) { b.click(); return 'handled'; }
                try { if (window.jwplayer && jwplayer().getState) { jwplayer().stop().remove(); } } catch (e) {}
                p.classList.add('hide');
                var pb = p.querySelector('.player-box');
                if (pb) { pb.innerHTML = ''; }
                return 'handled';
            }
            return 'none';
        })();
    """.trimIndent()

    private fun closePlayerPanel() {
        mainWebView.evaluateJavascript(backJs) { result ->
            if (result == null || !result.contains("handled")) forceExitPlayerMode()
        }
    }

    /** The video panel closed (or the page changed): leave fullscreen and go back to portrait. */
    private fun forceExitPlayerMode() {
        lastPlayerCloseAt = SystemClock.uptimeMillis()
        playerOpen = false
        endWatchTracking()
        if (customView != null) hideCustomView()
        updatePlayerMode()
    }

    private fun hideCustomView() {
        customView?.let { customViewContainer.removeView(it) }
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        customViewContainer.visibility = View.GONE
        lastPlayerCloseAt = SystemClock.uptimeMillis()
        updatePlayerMode()
    }

    private fun updatePlayerMode() {
        val needLandscape = playerOpen || customView != null
        if (needLandscape && !playerModeOn) {
            playerModeOn = true
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            enterImmersive()
        } else if (!needLandscape && playerModeOn) {
            playerModeOn = false
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            exitImmersive()
        }
    }

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun exitImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    // ====================== WATCH ACTIVITY (for Quantum Admin) ======================
    private var watchSession: ActivityTracker.WatchSession? = null
    private var watchToken = 0
    private var watchPending = false

    // Title of what is being played. The site's own player request
    //   .../playlist.php?id=<id>&t=<TITLE>&tm=<time>
    // carries the real title in "t", so it is read from the request URL (no page scraping).
    @Volatile private var playlistTitle: String? = null
    @Volatile private var playlistTitleAt = 0L

    private val badTitles = setOf("android", "ios", "web", "netmirror", "uranium tv", "loading", "video", "undefined", "null")

    private fun cleanTitle(raw: String?): String {
        val t = raw?.trim().orEmpty()
        if (t.length < 2) return ""
        if (t.all { it.isDigit() }) return ""
        val low = t.lowercase()
        if (low in badTitles || low.contains("android mobile")) return ""
        return t
    }

    private fun captureTitleFromRequest(url: Uri?) {
        if (url == null) return
        val path = url.path?.lowercase() ?: return
        if (!path.endsWith("/playlist.php")) return
        val title = cleanTitle(url.getQueryParameter("t"))
        if (title.isEmpty()) return
        playlistTitle = title
        playlistTitleAt = SystemClock.uptimeMillis()
        // If the session already started (player opened first), fix its title now.
        handler.post { watchSession?.updateTitle(title) }
    }

    // Page fallback (used when the playlist request has no title, e.g. Hotstar, or was not seen yet):
    // the site builds the playlist request from  $(".model-title").text(),  so read that same element
    // (Hotstar keeps the name in the alt text of the title picture inside it). JW Player's own title
    // is the second choice. Never document.title (that is "Home - Android Mobile").
    private val watchTitleJs = """
        (function(){
            var t = '';
            try {
                var els = document.querySelectorAll('.model-title');
                for (var i = 0; i < els.length; i++) {
                    var x = (els[i].textContent || '').trim();
                    if (!x) {
                        // Hotstar: the title is a picture, the name is in its alt text
                        var im = els[i].querySelector('img');
                        if (im) x = (im.getAttribute('alt') || '').trim();
                    }
                    if (x) { t = x; break; }
                }
            } catch (e) {}
            if (!t) {
                try {
                    if (window.jwplayer) {
                        var it = jwplayer().getPlaylistItem();
                        if (it && it.title) t = it.title;
                    }
                } catch (e) {}
            }
            return t;
        })();
    """.trimIndent()

    private fun decodeJsString(raw: String?): String? = try {
        org.json.JSONTokener(raw ?: "null").nextValue() as? String
    } catch (e: Exception) {
        null
    }

    // If the title was not known when the session started, look again a few times (page may still be filling in).
    private fun scheduleTitleRetry(token: Int, attempt: Int) {
        if (attempt > 3) return
        handler.postDelayed({
            if (token != watchToken || watchSession == null) return@postDelayed
            mainWebView.evaluateJavascript(watchTitleJs) { raw ->
                if (token != watchToken) return@evaluateJavascript
                val t = cleanTitle(decodeJsString(raw))
                if (t.isNotEmpty()) watchSession?.updateTitle(t) else scheduleTitleRetry(token, attempt + 1)
            }
        }, 1500L)
    }

    private fun beginWatchTracking() {
        if (watchSession != null || watchPending) return   // already tracking this video
        watchPending = true
        val token = ++watchToken
        mainWebView.evaluateJavascript(watchTitleJs) { raw ->
            if (token != watchToken) return@evaluateJavascript
            watchPending = false
            val decoded: String? = decodeJsString(raw)
            val fresh = playlistTitle?.takeIf { SystemClock.uptimeMillis() - playlistTitleAt < 45_000 }
            val jwTitle = cleanTitle(decoded)
            val title = fresh ?: jwTitle
            val via = when {
                fresh != null -> "playlist"
                jwTitle.isNotEmpty() -> "page"
                else -> "pending"
            }
            watchSession = ActivityTracker.startWatch(
                this@AlphaMoviesActivity,
                title,
                "Alpha TV (Watch Movies & Series)",
                "${mainWebView.url.orEmpty()} | title via $via"
            )
            if (title.isEmpty()) scheduleTitleRetry(token, 1)
        }
    }

    private fun endWatchTracking(keepTitle: Boolean = false) {
        watchToken++
        watchPending = false
        ActivityTracker.endWatch(watchSession)
        watchSession = null
        if (!keepTitle) playlistTitle = null
    }

    override fun onStart() {
        super.onStart()
        if (playerOpen) handler.post { beginWatchTracking() }
    }

    override fun onStop() {
        super.onStop()
        endWatchTracking(keepTitle = true)
    }

    private inner class VideoEventsBridge {
        @JavascriptInterface
        fun onPlayerOpen() {
            playerOpen = true
            handler.post { updatePlayerMode() }
            handler.post { beginWatchTracking() }
        }

        // The site's own player code also calls these when it runs inside an app.
        @JavascriptInterface
        fun onVideoPlay() {
        }

        @JavascriptInterface
        fun onVideoPause() {
        }

        @JavascriptInterface
        fun onVideoEnd() {
            handler.post {
                mainWebView.evaluateJavascript(
                    "(function(){var p=document.getElementById('player');return !p||p.classList.contains('hide');})()"
                ) { result -> if (result == "true") forceExitPlayerMode() }
            }
        }

        @JavascriptInterface
        fun onPlayerClose() {
            playerOpen = false
            lastPlayerCloseAt = SystemClock.uptimeMillis()
            handler.post { updatePlayerMode() }
            handler.post { endWatchTracking() }
        }
    }

    // ====================== LIFECYCLE ======================
    override fun onPause() {
        super.onPause()
        mainWebView.onPause()
        CookieManager.getInstance().flush()
        if (!isVerifying) saveCurrentCookies()
    }

    override fun onResume() {
        super.onResume()
        mainWebView.onResume()
    }

    override fun onDestroy() {
        endWatchTracking()
        promoWebView?.destroy()
        promoWebView = null
        stopPolling()
        handler.removeCallbacksAndMessages(null)
        closeAdPanel(reload = false)
        destroyPhantomWebView()
        interactiveView.stopAnimation()
        (mainWebView.parent as? ViewGroup)?.removeView(mainWebView)
        mainWebView.stopLoading()
        mainWebView.removeJavascriptInterface("AndroidVideoEvents")
        mainWebView.destroy()
        super.onDestroy()
    }
}

// ====================== COUNTDOWN RING ======================
internal class CountdownRingView(context: Context, private val totalMs: Long) : View(context) {
    var remainingProvider: (() -> Long)? = null

    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f * d
        color = Color.argb(36, 63, 208, 255)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 12f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        textSize = 30f * d
        color = Color.WHITE
    }
    private val unit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 9f * d
        color = Color.parseColor("#7F9BAA")
        letterSpacing = 0.15f
    }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val rem = (remainingProvider?.invoke() ?: totalMs).coerceIn(0L, totalMs)
        val frac = rem.toFloat() / totalMs.toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width, height) / 2f - 9f * d
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        val c = when {
            rem <= 5000L -> Color.rgb(255, 77, 77)
            rem <= 12000L -> Color.rgb(255, 138, 61)
            else -> Color.rgb(63, 208, 255)
        }
        canvas.drawOval(rect, track)
        if (frac > 0f) {
            glow.color = Color.argb(60, Color.red(c), Color.green(c), Color.blue(c))
            arc.color = c
            canvas.drawArc(rect, -90f, 360f * frac, false, glow)
            canvas.drawArc(rect, -90f, 360f * frac, false, arc)
        }
        val secs = ceil(rem / 1000.0).toInt()
        canvas.drawText(secs.toString(), cx, cy + 6f * d, num)
        canvas.drawText("SEC", cx, cy + 20f * d, unit)
        postInvalidateOnAnimation()
    }
}
