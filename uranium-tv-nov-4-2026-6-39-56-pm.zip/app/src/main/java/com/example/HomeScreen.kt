package com.example

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.*
import com.example.ui.theme.bouncyClick
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UraniumMotion
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.foundation.Canvas
import kotlin.math.*

data class WatchInvite(
    val id: String,
    val fromUsername: String,
    val roomCode: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToWatchMoviesSeries: () -> Unit,
    onNavigateToWatchWithFriends: () -> Unit,
    onNavigateToMyCollections: (() -> Unit)? = null,
    onNavigateToProfile: () -> Unit,
    onNavigateToRoom: ((String) -> Unit)? = null,
    onNavigateToFriends: (() -> Unit)? = null,
    onNavigateToWatch: ((String, Boolean) -> Unit)? = null,
    onNavigateToRoomHistory: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var joinRoomCode by remember { mutableStateOf("") }
    var isCreating by remember { mutableStateOf(false) }
    var isJoining by remember { mutableStateOf(false) }
    var invites by remember { mutableStateOf<List<WatchInvite>>(emptyList()) }
    var continueWatching by remember { mutableStateOf<List<ContinueWatchingEntry>>(emptyList()) }
    var onlineFriends by remember { mutableStateOf<List<FriendProfile>>(emptyList()) }
    val auth = remember { FirebaseAuth.getInstance() }
    val uid = auth.currentUser?.uid ?: ""
    val cachedAvatar = remember(uid) { UserProfileStorage.getCachedAvatar(context, uid) }
    var myAvatarId by remember(uid) { mutableStateOf(cachedAvatar) }

    val db = remember { FirebaseDatabase.getInstance("https://uranium-tv-core-default-rtdb.firebaseio.com").reference }

    val broadcastManager = remember(uid) { BroadcastManager(context, uid) }

    LaunchedEffect(uid) {
        if (uid.isNotEmpty()) {
            kotlinx.coroutines.delay(600)
            broadcastManager.startListening()
        }
    }

    DisposableEffect(broadcastManager) {
        onDispose {
            broadcastManager.stopListening()
        }
    }

    LaunchedEffect(invites.size) {
        broadcastManager.hasBlockingUi = invites.isNotEmpty()
        broadcastManager.evaluateQueue()
    }

    // So the profile button in the top bar shows this user's own avatar.
    DisposableEffect(uid) {
        val avatarRef = db.child("users").child(uid).child("avatarId")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val raw = snapshot.getValue(String::class.java)
                val clean = if (raw.isNullOrBlank() || raw.startsWith("avatar_")) "iron_man" else raw.trim()
                myAvatarId = clean
                UserProfileStorage.saveAvatarLocally(context, uid, clean)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        avatarRef.addValueEventListener(listener)
        onDispose { avatarRef.removeEventListener(listener) }
    }

    // Listen for incoming "watch together" invites from friends
    DisposableEffect(uid) {
        val invitesRef = db.child("users").child(uid).child("watchInvites")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                invites = snapshot.children.mapNotNull { child ->
                    val id = child.key ?: return@mapNotNull null
                    val fromUsername = child.child("fromUsername").getValue(String::class.java) ?: "Someone"
                    val roomCode = child.child("roomCode").getValue(String::class.java) ?: return@mapNotNull null
                    WatchInvite(id, fromUsername, roomCode)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        invitesRef.addValueEventListener(listener)
        onDispose { invitesRef.removeEventListener(listener) }
    }

    // Continue Watching: per-room resume points for this user, most recent first.
    // Automatically filters out and purges rooms where video was created > 2 hours ago
    // or user left for > 2 hours continuously.
    DisposableEffect(uid) {
        val cwRef = db.child("users").child(uid).child("continueWatching")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val now = System.currentTimeMillis()
                val active = mutableListOf<ContinueWatchingEntry>()
                val expiredCodes = mutableListOf<String>()

                snapshot.children.forEach { child ->
                    val code = child.key ?: return@forEach
                    val entry = child.toContinueWatchingEntry(code) ?: return@forEach
                    if (entry.isExpired(now)) {
                        expiredCodes.add(code)
                    } else {
                        active.add(entry)
                    }
                }

                // Clean up expired history from database
                expiredCodes.forEach { code ->
                    cwRef.child(code).removeValue()
                }

                continueWatching = active
                    .sortedByDescending { it.updatedAt }
                    .take(10)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        cwRef.addValueEventListener(listener)
        onDispose { cwRef.removeEventListener(listener) }
    }

    // Periodic check every minute to auto-remove entries once they reach 2 hours
    LaunchedEffect(uid, continueWatching) {
        if (continueWatching.isNotEmpty()) {
            while (true) {
                kotlinx.coroutines.delay(60_000L)
                val now = System.currentTimeMillis()
                val (expired, active) = continueWatching.partition { it.isExpired(now) }
                if (expired.isNotEmpty()) {
                    continueWatching = active
                    val cwRef = db.child("users").child(uid).child("continueWatching")
                    expired.forEach { cwRef.child(it.roomCode).removeValue() }
                }
            }
        }
    }

    // Friends + presence, for the online-avatars row.
    DisposableEffect(uid) {
        val friendsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val friendIds = snapshot.children.mapNotNull { it.key }
                if (friendIds.isEmpty()) {
                    onlineFriends = emptyList()
                    return
                }
                val resolved = mutableListOf<FriendProfile>()
                var remaining = friendIds.size
                friendIds.forEach { fid ->
                    fetchFriendProfile(db, fid) { profile ->
                        resolved.add(profile)
                        remaining--
                        if (remaining == 0) {
                            onlineFriends = resolved
                                .filter { it.presenceStatus != "offline" }
                                .sortedBy { it.username }
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        db.child("users").child(uid).child("friends").addValueEventListener(friendsListener)
        onDispose { db.child("users").child(uid).child("friends").removeEventListener(friendsListener) }
    }

    Scaffold { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                ReactorHomeHero(
                    myAvatarId = myAvatarId,
                    onNavigateToProfile = onNavigateToProfile,
                    onNavigateToWatchMoviesSeries = onNavigateToWatchMoviesSeries,
                    onNavigateToWatchWithFriends = onNavigateToWatchWithFriends
                )
            } // Close the scrollable Column

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AnimatedVisibility(
                    visible = onlineFriends.isNotEmpty(),
                    enter = fadeIn(UraniumMotion.fade()),
                    exit = fadeOut(UraniumMotion.fade())
                ) {
                    OnlineFriendsRow(friends = onlineFriends, onClick = { onNavigateToFriends?.invoke() })
                }

                AnimatedVisibility(
                    visible = continueWatching.isNotEmpty(),
                    enter = fadeIn(UraniumMotion.fade()),
                    exit = fadeOut(UraniumMotion.fade())
                ) {
                    ContinueWatchingRow(
                        entries = continueWatching,
                        onResume = { entry -> onNavigateToWatch?.invoke(entry.roomCode, entry.isYouTube) },
                        onDismiss = { entry ->
                            continueWatching = continueWatching.filter { it.roomCode != entry.roomCode }
                            removeContinueWatching(db.child("users"), uid, entry.roomCode)
                        }
                    )
                }

                if (invites.isNotEmpty()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                        invites.forEach { invite ->
                            key(invite.id) {
                                AnimatedVisibility(
                                    visible = true,
                                    enter = scaleIn(
                                        initialScale = 0.6f,
                                        animationSpec = spring(
                                            dampingRatio = Spring.DampingRatioMediumBouncy,
                                            stiffness = Spring.StiffnessLow
                                        )
                                    ) + fadeIn(animationSpec = tween(180)),
                                    exit = fadeOut(UraniumMotion.fade())
                                ) {
                                    Surface(
                                        color = com.example.ui.theme.AbyssSurfaceElevated,
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.5.dp, com.example.ui.theme.CrimsonCore),
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(CircleShape)
                                                    .background(com.example.ui.theme.CrimsonCore.copy(alpha = 0.18f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("🎬", fontSize = 18.sp)
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = invite.fromUsername,
                                                    color = com.example.ui.theme.MistText,
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 15.sp
                                                )
                                                Text(
                                                    text = "invited you to watch · Room ${invite.roomCode}",
                                                    color = com.example.ui.theme.MistTextMuted,
                                                    fontSize = 13.sp
                                                )
                                            }
                                            TextButton(onClick = {
                                                db.child("users").child(uid).child("watchInvites")
                                                    .child(invite.id).removeValue()
                                                onNavigateToRoom?.invoke(invite.roomCode)
                                            }) {
                                                Text(
                                                    "Join",
                                                    color = com.example.ui.theme.CrimsonCore,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            IconButton(onClick = {
                                                db.child("users").child(uid).child("watchInvites")
                                                    .child(invite.id).removeValue()
                                            }) {
                                                Icon(
                                                    Icons.Default.Close,
                                                    contentDescription = "Dismiss",
                                                    tint = com.example.ui.theme.MistTextMuted
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            val current = broadcastManager.currentBroadcast
            if (current != null) {
                BroadcastPopup(
                    broadcast = current,
                    myReaction = broadcastManager.myReactionFor(current.id),
                    onReact = { broadcastManager.setReaction(current, it) },
                    onClose = { broadcastManager.markSeen(current); broadcastManager.advance() }
                )
                LaunchedEffect(current.id) { broadcastManager.registerImpression(current) }
            }
        }
    }
}

/**
 * The reactor-skinned hero: a single background image (frame, logo, dial, decorative
 * readouts) with real interactive elements positioned on top of it by fraction of the
 * hero's own width/height. Fractions were measured directly against the background
 * artwork's pixel dimensions, so this holds its layout regardless of screen size -
 * the hero box itself is locked to the artwork's aspect ratio via .aspectRatio(),
 * meaning nothing stretches or distorts, it just scales up/down as one unit.
 */
@Composable
private fun ReactorHomeHero(
    myAvatarId: String,
    onNavigateToProfile: () -> Unit,
    onNavigateToWatchMoviesSeries: () -> Unit,
    onNavigateToWatchWithFriends: () -> Unit,
) {
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
                .aspectRatio(835f / 1884f)
                .clipToBounds()
        ) {
            val w = maxWidth
            val h = maxHeight

            Image(
                painter = painterResource(R.drawable.home_reactor_v2),
                contentDescription = "Uranium TV Reactor Interface",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )

            // Sweeping cyber laser scanner beam across the reactor deck
            FuturisticScannerOverlay()

            // Continuous breathing animation for primary action buttons and glow
            val infiniteTransition = rememberInfiniteTransition(label = "heroBreathing")
            
            // Ambient Plasma Glow
            val glowAlpha by infiniteTransition.animateFloat(
                initialValue = 0.0f,
                targetValue = 0.5f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2500, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "glowAlpha"
            )
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFFF3300).copy(alpha = glowAlpha), Color.Transparent),
                        center = Offset(size.width * 0.43f, size.height * 0.35f),
                        radius = size.width * 0.6f
                    )
                )
            }

            // Live Spinning Reactor Core
            AnimatedReactorCore(
                modifier = Modifier
                    .offset(x = w * 0.335f, y = h * 0.204f)
                    .size(w * 0.33f, w * 0.33f)
            )

            // 1. Live 2D Telemetry Line Graph aligned directly over the two upper peaks in artwork
            TelemetryLineGraph(
                modifier = Modifier
                    .offset(x = w * 0.1437f, y = h * 0.2845f)
                    .size(w * 0.2695f, h * 0.0552f)
            )

            // 2. Live Frequency Spectrum Bar Graph aligned directly over left bars
            FrequencySpectrumBars(
                modifier = Modifier
                    .offset(x = w * 0.1916f, y = h * 0.3991f)
                    .size(w * 0.2024f, h * 0.0281f)
            )

            // 3. Live Audio Waveform aligned directly on top of background waveform on the right
            AudioWaveformVisualizer(
                modifier = Modifier
                    .offset(x = w * 0.6491f, y = h * 0.3848f)
                    .size(w * 0.2216f, h * 0.0451f)
            )

            // Profile avatar inside the metal box with rotating and blinking circular ring
            val avatarContainerSize = w * 0.138f
            RotatingBlinkingAvatar(
                avatarId = myAvatarId,
                size = avatarContainerSize,
                onClick = onNavigateToProfile,
                modifier = Modifier.offset(
                    x = w * 0.7832f - (avatarContainerSize / 2),
                    y = h * 0.1128f - (avatarContainerSize / 2)
                )
            )

            // Dynamic zoom-in, scale-up and scale-down animation for the two action buttons
            val buttonZoomScale by infiniteTransition.animateFloat(
                initialValue = 0.97f,
                targetValue = 1.08f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "buttonZoomScale"
            )
            val buttonPulseAlpha by infiniteTransition.animateFloat(
                initialValue = 0.82f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "buttonPulseAlpha"
            )

            // Note: [MY COLLECTIONS] is a normal decorative element in the background artwork (not a button, not clickable).

            // 1. WATCH MOVIES & SERIES BUTTON (Visible animated button with zoom-in / scale-up / scale-down)
            Image(
                painter = painterResource(R.drawable.btn_watch_movies_series),
                contentDescription = "Watch Movies & Series",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .offset(x = w * 0.2096f, y = h * 0.5892f)
                    .size(w * 0.5808f, h * 0.0823f)
                    .graphicsLayer {
                        scaleX = buttonZoomScale
                        scaleY = buttonZoomScale
                        alpha = buttonPulseAlpha
                    }
                    .clip(RoundedCornerShape(16.dp))
                    .bouncyClick(onClick = onNavigateToWatchMoviesSeries)
            )

            // 2. WATCH WITH FRIENDS BUTTON (Visible animated button with zoom-in / scale-up / scale-down)
            Image(
                painter = painterResource(R.drawable.btn_watch_with_friends),
                contentDescription = "Watch with Friends",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .offset(x = w * 0.2275f, y = h * 0.7245f)
                    .size(w * 0.5449f, h * 0.0823f)
                    .graphicsLayer {
                        scaleX = buttonZoomScale
                        scaleY = buttonZoomScale
                        alpha = buttonPulseAlpha
                    }
                    .clip(RoundedCornerShape(16.dp))
                    .bouncyClick(onClick = onNavigateToWatchWithFriends)
            )
        }
    }
}

@Composable
private fun OnlineFriendsRow(friends: List<FriendProfile>, onClick: () -> Unit) {
    Column(modifier = Modifier.padding(top = 4.dp)) {
        Row(
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(NeonToxicGreen, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                "FRIENDS ONLINE",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(friends, key = { it.uid }) { friend ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(52.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .bouncyClick { onClick() }
                            .border(1.2.dp, NeonCyberCyan.copy(alpha = 0.6f), CircleShape)
                            .padding(1.5.dp)
                    ) {
                        AvatarCircle(avatar = avatarById(friend.avatarId), size = 38.dp)
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(11.dp)
                                .background(
                                    color = if (friend.presenceStatus == "watching")
                                        NeonCyberCyan else NeonToxicGreen,
                                    shape = CircleShape
                                )
                                .border(1.5.dp, Color(0xFF0D1019), CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        friend.username,
                        color = Color.White,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingRow(
    entries: List<ContinueWatchingEntry>,
    onResume: (ContinueWatchingEntry) -> Unit,
    onDismiss: ((ContinueWatchingEntry) -> Unit)? = null
) {
    Column(modifier = Modifier.padding(top = 4.dp)) {
        Row(
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(NeonHazardAmber, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                "CONTINUE WATCHING",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(entries, key = { it.roomCode }) { entry ->
                Surface(
                    modifier = Modifier
                        .width(136.dp)
                        .height(46.dp)
                        .bouncyClick { onResume(entry) },
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xEE0B0E18),
                    border = BorderStroke(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            listOf(
                                NeonCrimson.copy(alpha = 0.8f),
                                NeonCyberCyan.copy(alpha = 0.55f)
                            )
                        )
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Compact glowing play button circle
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(Color(0x33FF1744), CircleShape)
                                .border(1.dp, NeonCrimson, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Resume",
                                tint = NeonCrimson,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(7.dp))

                        // Compact Room code & source
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "ROOM: ${entry.roomCode}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = if (entry.isYouTube) "YOUTUBE" else "WEB VIDEO",
                                fontSize = 8.5.sp,
                                color = NeonCyberCyan,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                maxLines = 1
                            )
                        }

                        if (onDismiss != null) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .bouncyClick { onDismiss(entry) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Remove",
                                    tint = Color(0xFF6B7280),
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AnimatedReactorCore(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactorSpin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val outerRadius = size.minDimension / 2f
            
            // Solid dark core mask perfectly sized to hide the static lines 
            // without bleeding outside the bounds of the PNG image
            drawCircle(
                color = Color(0xFF100202), // Very dark red/black matching the background
                radius = outerRadius * 0.96f,
                center = center
            )
        }
        
        Image(
            painter = painterResource(R.drawable.nuclear_radiation),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    rotationZ = rotation
                }
        )
    }
}

// 1. Live 2D Telemetry Coordinate Line Graph (Aligned directly over the two upper mathematical peaks in artwork)
@Composable
private fun TelemetryLineGraph(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "telemetryGraph")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing)),
        label = "time"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val curveColor = Color(0xFFFF2A2A)
        val glowColor = Color(0x66FF2200)

        // Subtle gentle breathing/oscillation that strictly preserves the background peak positions
        val p1Phase = sin(time * 1.6f) * 0.02f
        val p2Phase = cos(time * 1.3f) * 0.02f
        val peak1Center = 0.298f + p1Phase
        val peak2Center = 0.555f + p2Phase

        val numPoints = 60
        val points = mutableListOf<Offset>()

        for (i in 0..numPoints) {
            val u = i.toFloat() / numPoints
            val x = u * w
            
            // Double resonance peak curve precisely aligned to the background artwork
            // Peak 1 reaches ~0.94 at u=0.298 (Y ~ 0.06h)
            val peak1 = exp(-((u - peak1Center) * (u - peak1Center)) / 0.010f) * (0.91f + p1Phase * 0.4f)
            // Peak 2 reaches ~0.64 at u=0.555 (Y ~ 0.36h)
            val peak2 = exp(-((u - peak2Center) * (u - peak2Center)) / 0.015f) * (0.61f + p2Phase * 0.4f)
            // Baseline slope from u=0 (left) down to u=1 (right)
            val baseSlope = (1f - u) * 0.18f + 0.03f
            // Subtle micro-ripple
            val ripple = sin(u * 16f - time * 2.2f) * 0.018f

            val normalizedVal = (peak1 + peak2 + baseSlope + ripple).coerceIn(0.02f, 0.98f)
            val y = h - normalizedVal * h
            points.add(Offset(x, y))
        }

        // Glowing translucent plasma gradient fill under the curve
        val fillPath = Path().apply {
            moveTo(points.first().x, h)
            points.forEach { lineTo(it.x, it.y) }
            lineTo(points.last().x, h)
            close()
        }
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x44FF2200), Color(0x08FF1100), Color.Transparent),
                startY = 0f,
                endY = h
            )
        )

        // Animated glowing curve line
        val strokePath = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (k in 1 until points.size) {
                lineTo(points[k].x, points[k].y)
            }
        }
        drawPath(
            path = strokePath,
            color = curveColor,
            style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Glowing particle dots along the curve matching artwork
        val dotIndices = listOf(6, 12, 18, 24, 30, 36, 42, 48, 54)
        dotIndices.forEach { idx ->
            if (idx < points.size) {
                val pt = points[idx]
                val dotAlpha = 0.6f + 0.35f * sin(time * 3f + idx * 0.5f)
                drawCircle(Color(0xFFFF5533).copy(alpha = dotAlpha), radius = 2.0.dp.toPx(), center = pt)
                drawCircle(Color(0xFFFFEE77).copy(alpha = dotAlpha), radius = 1.0.dp.toPx(), center = pt)
            }
        }

        // Prominent pulsing vertex indicators right on the two peaks
        val peak1Idx = (peak1Center * numPoints).roundToInt().coerceIn(0, points.size - 1)
        val peak2Idx = (peak2Center * numPoints).roundToInt().coerceIn(0, points.size - 1)

        listOf(peak1Idx, peak2Idx).forEach { idx ->
            val pt = points[idx]
            val pulse = 0.5f + 0.4f * sin(time * 2.5f + idx)
            drawCircle(glowColor.copy(alpha = pulse), radius = 5.dp.toPx(), center = pt)
            drawCircle(Color(0xFFFFDD44), radius = 2.2.dp.toPx(), center = pt)
            drawCircle(Color.White, radius = 1.0.dp.toPx(), center = pt)
        }
    }
}

// 2. Live Frequency Spectrum Equalizer Bar Graph (Left of "STAY FUSION")
@Composable
private fun FrequencySpectrumBars(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "freqSpectrum")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "time"
    )

    Canvas(modifier = modifier) {
        val totalW = size.width
        val totalH = size.height
        val numBars = 24
        val barSpacing = 1.2.dp.toPx()
        val barWidth = (totalW - (numBars - 1) * barSpacing) / numBars

        // Baseline at the bottom
        drawLine(
            color = Color(0x66FF3300),
            start = Offset(0f, totalH - 0.5f),
            end = Offset(totalW, totalH - 0.5f),
            strokeWidth = 1.dp.toPx()
        )

        for (i in 0 until numBars) {
            val u = i.toFloat() / (numBars - 1)
            // Profile matching the three clusters in the background bar graph:
            // Cluster 1 (u~0.24, peak ~ 0.65)
            // Cluster 2 (u~0.46, tall peak ~ 0.94)
            // Cluster 3 (u~0.72, peak ~ 0.58)
            val c1 = 0.65f * exp(-((u - 0.24f) * (u - 0.24f)) / 0.012f)
            val c2 = 0.94f * exp(-((u - 0.46f) * (u - 0.46f)) / 0.008f)
            val c3 = 0.58f * exp(-((u - 0.72f) * (u - 0.72f)) / 0.015f)
            val baseProfile = (c1 + c2 + c3 + 0.12f).coerceIn(0.10f, 0.96f)

            // Dynamic harmonic modulation around the profile
            val harmonic1 = sin(time * 2.6f + i * 0.45f) * 0.18f
            val harmonic2 = cos(time * 1.8f - i * 0.32f) * 0.08f
            val heightFrac = (baseProfile * (1f + harmonic1 + harmonic2)).coerceIn(0.08f, 0.98f)
            val barH = totalH * heightFrac
            val x = i * (barWidth + barSpacing)
            val y = totalH - barH

            // Vertical gradient bar: red base to hot amber peak
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFF9900), Color(0xFFFF1E40)),
                    startY = y,
                    endY = totalH
                ),
                topLeft = Offset(x, y),
                size = Size(barWidth, barH)
            )

            // Crisp neon top cap dot
            drawRect(
                color = Color(0xFFFFEE55),
                topLeft = Offset(x, y),
                size = Size(barWidth, 1.4.dp.toPx())
            )
        }
    }
}

// 3. Live Audio Waveform Visualizer (Right of "STAY FUSION")
@Composable
private fun AudioWaveformVisualizer(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "audioWaveform")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "time"
    )

    Canvas(modifier = modifier) {
        val totalW = size.width
        val totalH = size.height
        val midY = totalH / 2f
        val numBars = 32
        val spacing = 1.0.dp.toPx()
        val barW = (totalW - (numBars - 1) * spacing) / numBars

        // Central horizontal reference axis line matching artwork
        drawLine(
            color = Color(0x66FF3333),
            start = Offset(0f, midY),
            end = Offset(totalW, midY),
            strokeWidth = 0.8.dp.toPx()
        )

        for (k in 0 until numBars) {
            val u = k.toFloat() / (numBars - 1)
            // Two spindle envelopes matching background artwork:
            // Spindle 1 (left, taller): center u = 0.35, sigma = 0.14
            // Spindle 2 (right, medium): center u = 0.74, sigma = 0.10
            val s1 = exp(-((u - 0.35f) * (u - 0.35f)) / 0.020f) * 0.94f
            val s2 = exp(-((u - 0.74f) * (u - 0.74f)) / 0.012f) * 0.65f
            val staticEnvelope = maxOf(s1, s2).coerceIn(0.04f, 0.96f)

            // Gentle audio oscillation along the shape of the existing waveform
            val wave1 = sin(u * 14f - time * 3.0f) * 0.18f
            val wave2 = cos(u * 24f + time * 1.8f) * 0.10f
            val amplitude = staticEnvelope * (1f + wave1 + wave2) * (midY * 0.92f)
            val clampedAmp = amplitude.coerceIn(1.2.dp.toPx(), midY * 0.96f)

            val x = k * (barW + spacing) + barW / 2f
            drawLine(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFFCC33), Color(0xFFFF2A2A), Color(0xFFFFCC33)),
                    startY = midY - clampedAmp,
                    endY = midY + clampedAmp
                ),
                start = Offset(x, midY - clampedAmp),
                end = Offset(x, midY + clampedAmp),
                strokeWidth = barW * 0.85f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
internal fun RotatingBlinkingAvatar(
    avatarId: String,
    size: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "avatarRingAnim")

    // Smooth continuous 360-degree rotation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringRotation"
    )

    // Pulsing/blinking glow effect
    val blinkAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ringBlinkAlpha"
    )

    // Counter-rotation for micro HUD elements
    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counterRotation"
    )

    Box(
        modifier = modifier
            .size(size)
            .bouncyClick(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // Rotating tactical HUD circular rings with blinking pulse
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 2.dp.toPx()
            val ringRadius = (this.size.minDimension / 2f) - (strokeWidth + 2.dp.toPx())

            // Outer soft ambient glow ring
            drawCircle(
                color = NeonCrimson.copy(alpha = blinkAlpha * 0.35f),
                radius = ringRadius + 2.5.dp.toPx(),
                style = Stroke(width = 3.dp.toPx())
            )

            // Primary segmented high-tech rotating ring (glowing & blinking)
            rotate(rotation) {
                // Arc segment 1 (Crimson to Amber gradient)
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(NeonCrimson, NeonHazardAmber, NeonCrimson)
                    ),
                    startAngle = 10f,
                    sweepAngle = 100f,
                    useCenter = false,
                    topLeft = Offset(center.x - ringRadius, center.y - ringRadius),
                    size = Size(ringRadius * 2, ringRadius * 2),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                    alpha = blinkAlpha
                )

                // Arc segment 2 (Cyber Cyan to Crimson gradient)
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(NeonCyberCyan, NeonCrimson, NeonCyberCyan)
                    ),
                    startAngle = 190f,
                    sweepAngle = 100f,
                    useCenter = false,
                    topLeft = Offset(center.x - ringRadius, center.y - ringRadius),
                    size = Size(ringRadius * 2, ringRadius * 2),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                    alpha = blinkAlpha
                )

                // Tactical radar dots on ring perimeter
                val tickRadius = ringRadius - 3.dp.toPx()
                for (angle in listOf(45f, 135f, 225f, 315f)) {
                    val rad = Math.toRadians(angle.toDouble())
                    val dotCenter = Offset(
                        (center.x + tickRadius * Math.cos(rad)).toFloat(),
                        (center.y + tickRadius * Math.sin(rad)).toFloat()
                    )
                    drawCircle(
                        color = NeonCyberCyan.copy(alpha = blinkAlpha),
                        radius = 1.6.dp.toPx(),
                        center = dotCenter
                    )
                }
            }

            // Counter-rotating inner micro-accent arcs
            rotate(counterRotation) {
                val innerRadius = ringRadius - 4.dp.toPx()
                drawArc(
                    color = NeonHazardAmber.copy(alpha = (1.2f - blinkAlpha).coerceIn(0.2f, 0.9f)),
                    startAngle = 60f,
                    sweepAngle = 40f,
                    useCenter = false,
                    topLeft = Offset(center.x - innerRadius, center.y - innerRadius),
                    size = Size(innerRadius * 2, innerRadius * 2),
                    style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                )
                drawArc(
                    color = NeonHazardAmber.copy(alpha = (1.2f - blinkAlpha).coerceIn(0.2f, 0.9f)),
                    startAngle = 240f,
                    sweepAngle = 40f,
                    useCenter = false,
                    topLeft = Offset(center.x - innerRadius, center.y - innerRadius),
                    size = Size(innerRadius * 2, innerRadius * 2),
                    style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // The Profile Avatar neatly centered inside the metal socket & rotating ring
        AvatarCircle(
            avatar = avatarById(avatarId),
            size = size * 0.72f
        )
    }
}