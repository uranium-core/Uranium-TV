package com.example

import android.app.Application
import android.content.Context
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener

/**
 * Activity tracking for the Quantum Admin app.
 *
 *  - userPresence/{uid}  : state ("online"/"offline"), lastOnline, lastChanged, nowWatching, username
 *  - watchActivity/{uid}/{eventId} : title, source, detail, startedAt, endedAt, status, username
 *
 * Nothing is recorded unless the signed-in user accepted the notice shown by
 * [TrackingNoticeDialog]. All timestamps are Firebase SERVER timestamps (ms since epoch).
 */
object ActivityTracker {
    private const val DB_URL = "https://uranium-tv-core-default-rtdb.firebaseio.com"
    private const val PREFS = "uranium_activity_tracking"
    const val PRESENCE_NODE = "userPresence"
    const val WATCH_NODE = "watchActivity"

    private var appContext: Context? = null
    private var initialised = false
    @Volatile private var inForeground = false
    private var attachedUid = ""
    private var connRef: DatabaseReference? = null
    private var connListener: ValueEventListener? = null

    private fun db() = FirebaseDatabase.getInstance(DB_URL)

    // ------------------------------------------------------------------ setup
    fun init(app: Application) {
        if (initialised) return
        initialised = true
        appContext = app.applicationContext
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                inForeground = true
                applyPresence()
            }

            override fun onStop(owner: LifecycleOwner) {
                inForeground = false
                applyPresence()
            }
        })
        FirebaseAuth.getInstance().addAuthStateListener { applyPresence() }
    }

    // ---------------------------------------------------------------- consent
    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun consentDecided(ctx: Context, uid: String) = prefs(ctx).contains("consent_$uid")
    fun hasConsent(ctx: Context, uid: String) = prefs(ctx).getBoolean("consent_$uid", false)

    fun setConsent(ctx: Context, uid: String, accepted: Boolean) {
        prefs(ctx).edit().putBoolean("consent_$uid", accepted).apply()
        applyPresence()
    }

    // --------------------------------------------------------------- presence
    private fun username(uid: String): String =
        appContext?.let { UserProfileStorage.getCachedUsername(it, uid) } ?: ""

    private fun onlineMap(uid: String): Map<String, Any?> = mapOf(
        "state" to "online",
        "lastOnline" to ServerValue.TIMESTAMP,
        "lastChanged" to ServerValue.TIMESTAMP,
        "username" to username(uid)
    )

    private fun offlineMap(uid: String): Map<String, Any?> = mapOf(
        "state" to "offline",
        "lastOnline" to ServerValue.TIMESTAMP,
        "lastChanged" to ServerValue.TIMESTAMP,
        "nowWatching" to null,
        "username" to username(uid)
    )

    @Synchronized
    private fun applyPresence() {
        val ctx = appContext ?: return
        val uid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
        val allowed = uid.isNotEmpty() && hasConsent(ctx, uid)
        if (attachedUid.isNotEmpty() && (attachedUid != uid || !allowed)) detach()
        if (allowed) {
            if (attachedUid.isEmpty()) attach(uid) else writeState(uid, inForeground)
        }
    }

    private fun attach(uid: String) {
        val ref = db().getReference(".info/connected")
        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.getValue(Boolean::class.java) == true) writeState(uid, inForeground)
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(l)
        connRef = ref
        connListener = l
        attachedUid = uid
    }

    private fun detach() {
        connListener?.let { connRef?.removeEventListener(it) }
        connRef = null
        connListener = null
        attachedUid = ""
    }

    private fun writeState(uid: String, foreground: Boolean) {
        val ref = db().getReference(PRESENCE_NODE).child(uid)
        if (foreground) {
            // Arm the server-side "if I drop, mark me offline" first, then say online.
            ref.onDisconnect().updateChildren(offlineMap(uid)).addOnCompleteListener {
                if (inForeground) ref.updateChildren(onlineMap(uid))
            }
        } else {
            ref.onDisconnect().cancel()
            ref.updateChildren(offlineMap(uid))
        }
    }

    /** Call right before FirebaseAuth.signOut(): cycling the connection makes the server run the offline handlers. */
    fun onBeforeSignOut() {
        try {
            val d = db()
            d.goOffline()
            d.goOnline()
        } catch (_: Exception) {
        }
    }

    // ----------------------------------------------------------- watch history
    class WatchSession internal constructor(
        private val ref: DatabaseReference,
        private val presence: DatabaseReference
    ) {
        fun updateTitle(title: String) {
            if (title.isBlank()) return
            ref.child("title").setValue(title)
            presence.child("nowWatching").setValue(title)
        }

        internal fun end() {
            ref.onDisconnect().cancel()
            ref.updateChildren(mapOf<String, Any?>("endedAt" to ServerValue.TIMESTAMP, "status" to "ended"))
            presence.child("nowWatching").removeValue()
        }
    }

    /** Returns null (and records nothing) when there is no signed-in user or no consent. */
    fun startWatch(context: Context, title: String, source: String, detail: String?): WatchSession? {
        val uid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
        if (uid.isEmpty() || !hasConsent(context, uid)) return null
        val ref = db().getReference(WATCH_NODE).child(uid).push()
        val presence = db().getReference(PRESENCE_NODE).child(uid)
        ref.onDisconnect().updateChildren(mapOf<String, Any?>("endedAt" to ServerValue.TIMESTAMP, "status" to "ended"))
        val shownTitle = title.ifBlank { "Unknown" }
        ref.setValue(
            mapOf<String, Any?>(
                "title" to shownTitle,
                "source" to source,
                "detail" to (detail ?: ""),
                "username" to username(uid),
                "startedAt" to ServerValue.TIMESTAMP,
                "status" to "watching"
            )
        )
        presence.child("nowWatching").setValue(shownTitle)
        return WatchSession(ref, presence)
    }

    fun endWatch(session: WatchSession?) {
        session?.end()
    }
}

private class WatchSessionHolder {
    var session: ActivityTracker.WatchSession? = null
}

/**
 * Drop this anywhere inside a screen that plays a video. It records a watch session while the
 * screen is visible (starts on ON_START, ends on ON_STOP / when the screen leaves).
 */
@Composable
fun TrackWatchSession(title: String, source: String, detail: String) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val latestTitle by rememberUpdatedState(title)
    val holder = remember { WatchSessionHolder() }

    DisposableEffect(owner, source, detail) {
        fun begin() {
            if (holder.session == null) {
                holder.session = ActivityTracker.startWatch(context, latestTitle, source, detail)
            }
        }

        fun finish() {
            ActivityTracker.endWatch(holder.session)
            holder.session = null
        }

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> begin()
                Lifecycle.Event.ON_STOP -> finish()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            finish()
        }
    }

    LaunchedEffect(title) {
        holder.session?.updateTitle(title)
    }
}

/** One-time notice. Tracking only runs after the user taps Accept. */
@Composable
fun TrackingNoticeDialog() {
    val context = LocalContext.current
    val uid = remember { FirebaseAuth.getInstance().currentUser?.uid.orEmpty() }
    var show by remember { mutableStateOf(uid.isNotEmpty() && !ActivityTracker.consentDecided(context, uid)) }
    if (!show) return
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Activity & privacy") },
        text = {
            Text(
                "Uranium TV records what you watch (title, start and end time, and where you watched it) " +
                    "and whether you are online or offline, so the app admin can see activity and improve the service." +
                    "\n\nYou can decline and keep using the app without this being recorded."
            )
        },
        confirmButton = {
            TextButton(onClick = {
                ActivityTracker.setConsent(context, uid, true)
                show = false
            }) { Text("Accept") }
        },
        dismissButton = {
            TextButton(onClick = {
                ActivityTracker.setConsent(context, uid, false)
                show = false
            }) { Text("No thanks") }
        }
    )
}
