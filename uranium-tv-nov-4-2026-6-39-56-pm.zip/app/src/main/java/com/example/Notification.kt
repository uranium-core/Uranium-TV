package com.example

import android.Manifest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.Constraints
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

/**
 * Two kinds of system notifications for Uranium TV:
 *  1. BROADCAST - an admin broadcast arrives while the app is closed.
 *  2. PROMO     - the user has not opened the app for ~1 day.
 *
 * No server / Blaze plan needed: both run on-device through WorkManager.
 */
object NotificationCenter {
    private const val DB_URL = "https://uranium-tv-core-default-rtdb.firebaseio.com"
    private const val PREFS = "uranium_notifications"

    const val CHANNEL_BROADCAST = "uranium_broadcast"
    const val CHANNEL_PROMO = "uranium_promo"

    private const val WORK_BROADCAST = "uranium_broadcast_poll"
    private const val WORK_PROMO = "uranium_promo_inactive"

    @Volatile var inForeground = false
        private set

    private var initialised = false

    fun db() = FirebaseDatabase.getInstance(DB_URL).reference
    fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ setup
    fun init(app: Application) {
        if (initialised) return
        initialised = true
        createChannels(app)

        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                inForeground = true
                // User is back -> cancel the pending "come back" promo and reset the ladder.
                WorkManager.getInstance(app).cancelUniqueWork(WORK_PROMO)
                prefs(app).edit().putInt("promo_attempt", 0).apply()
            }

            override fun onStop(owner: LifecycleOwner) {
                inForeground = false
                // User left -> promo fires after ~24h of not coming back.
                if (FirebaseAuth.getInstance().currentUser != null) schedulePromo(app, attempt = 0)
            }
        })

        FirebaseAuth.getInstance().addAuthStateListener { auth ->
            if (auth.currentUser != null) scheduleBroadcastPolling(app)
            else {
                WorkManager.getInstance(app).cancelUniqueWork(WORK_BROADCAST)
                WorkManager.getInstance(app).cancelUniqueWork(WORK_PROMO)
            }
        }
    }

    private fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_BROADCAST, "Messages from Uranium TV", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Announcements and messages sent to you" }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PROMO, "Suggestions", NotificationManager.IMPORTANCE_DEFAULT)
                .apply { description = "Reminders to watch movies and shows" }
        )
    }

    // -------------------------------------------------------------- scheduling
    private fun scheduleBroadcastPolling(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<BroadcastNotifyWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork(WORK_BROADCAST, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** attempt 0 -> 1 day, 1 -> 3 days, 2 -> 7 days, then stop (no spam). */
    fun schedulePromo(ctx: Context, attempt: Int) {
        val delayHours = when (attempt) { 0 -> 24L; 1 -> 72L; 2 -> 168L; else -> return }
        val req = OneTimeWorkRequestBuilder<PromoWorker>()
            .setInitialDelay(delayHours, TimeUnit.HOURS)
            .setInputData(Data.Builder().putInt("attempt", attempt).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(WORK_PROMO, ExistingWorkPolicy.REPLACE, req)
    }

    // ----------------------------------------------------------------- showing
    fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    fun show(ctx: Context, channel: String, id: Int, title: String, body: String) {
        if (!canNotify(ctx)) return
        try {
            val open = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pi = PendingIntent.getActivity(
                ctx, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(ctx, channel)
                .setSmallIcon(R.drawable.ic_stat_uranium)
                .setColor(0xFFFF3300.toInt())
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(
                    if (channel == CHANNEL_BROADCAST) NotificationCompat.PRIORITY_HIGH
                    else NotificationCompat.PRIORITY_DEFAULT
                )
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) {
            Log.w("NotificationCenter", "notify blocked: ${e.message}")
        }
    }
}

/**
 * Runs about every 15 min (Android's minimum). Looks for admin broadcasts meant for
 * this user that were not notified yet and not already seen, and posts a notification.
 */
class BroadcastNotifyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return Result.success()
        if (NotificationCenter.inForeground) return Result.success() // in-app popup handles it
        if (!NotificationCenter.canNotify(applicationContext)) return Result.success()

        return try {
            val db = NotificationCenter.db()
            val prefs = NotificationCenter.prefs(applicationContext)
            val notified = prefs.getStringSet("notified_broadcasts", emptySet())!!.toMutableSet()
            val now = System.currentTimeMillis()

            val all = db.child("broadcasts").get().await()
            var changed = false

            for (child in all.children) {
                val b = Broadcast.fromSnapshot(child) ?: continue
                if (b.id in notified) continue
                if (!isBroadcastLive(b, now)) continue

                val targeted = if (b.audience == "specific") {
                    db.child("broadcastTargets").child(b.id).child(uid).get().await().exists()
                } else true
                if (!targeted) continue

                val receipt = db.child("broadcastReceipts").child(b.id).child(uid).get().await()
                    .let { if (it.exists()) BroadcastReceipt.fromSnapshot(it) else null }
                if (receipt?.seen == true) { notified.add(b.id); changed = true; continue }
                if (!shouldShow(b, receipt, now, alreadyShownThisSession = false, isTargeted = true)) continue

                val title = if (b.emoji.isNotBlank()) "${b.emoji} ${b.title}" else b.title
                NotificationCenter.show(
                    applicationContext,
                    NotificationCenter.CHANNEL_BROADCAST,
                    id = 1000 + (b.id.hashCode() and 0xFFFF),
                    title = title,
                    body = b.body
                )
                notified.add(b.id)
                changed = true
            }

            if (changed) {
                // keep the list from growing forever
                prefs.edit().putStringSet("notified_broadcasts", notified.toList().takeLast(200).toSet()).apply()
            }
            Result.success()
        } catch (e: Exception) {
            Log.w("BroadcastNotifyWorker", "poll failed: ${e.message}")
            Result.retry()
        }
    }
}

/** Fires after the user stayed away ~1 day, then again after 3 and 7 days, then stops. */
class PromoWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        if (FirebaseAuth.getInstance().currentUser == null) return Result.success()
        if (NotificationCenter.inForeground) return Result.success()

        val attempt = inputData.getInt("attempt", 0)
        val (title, body) = PROMOS[(System.currentTimeMillis() / 86_400_000L % PROMOS.size).toInt()]
        NotificationCenter.show(applicationContext, NotificationCenter.CHANNEL_PROMO, 2000, title, body)
        NotificationCenter.schedulePromo(applicationContext, attempt + 1)
        return Result.success()
    }

    companion object {
        private val PROMOS = listOf(
            "🎬 Movie night is waiting" to "Watch all your favourite movies and series on Uranium TV.",
            "🍿 Get entertained" to "New things to watch are ready for you. Open Uranium TV!",
            "🔥 Your favourites are here" to "Movies, series and more, all in one place. Come watch!",
            "👥 Watch with a friend" to "Start a room and watch together, in sync, on Uranium TV."
        )
    }
}
