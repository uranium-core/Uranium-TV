package com.example

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Uranium TV - Chain Reaction (native port of uranium-tv-chain-reaction.html).
 *
 * This view only draws the mini game. It knows nothing about verification.
 * AlphaMoviesActivity drives it with:
 *   prepareIntro()  - overlay just appeared, game hidden and stopped
 *   releaseGame()   - intro finished, game fades in and starts
 *   startAnimation()/stopAnimation() - same names the old InteractivePitView had
 */
class ChainReactionView(context: Context) : View(context) {

    // ============================== PUBLIC API ==============================
    private var released = false
    private var running = false
    private var lastNanos = 0L
    private var needRound = true

    fun prepareIntro() {
        released = false
        running = false
        lastNanos = 0L
        animate().cancel()
        alpha = 0f
        visibility = View.INVISIBLE
        sfx.humStop()
        aiming = false
        resumeOnShow = false
    }

    fun releaseGame() {
        released = true
        resetGame()
        visibility = View.VISIBLE
        alpha = 0f
        animate().alpha(1f).setDuration(350L).start()
        begin()
    }

    fun startAnimation() {
        if (released) begin()
    }

    fun stopAnimation() {
        running = false
        resumeOnShow = false
        released = false
        aiming = false
        sfx.humStop()
        saveBest()
    }

    // Frame cap: ~30 fps is plenty for this mini game and roughly halves (or quarters on
    // 90/120 Hz phones) the CPU/GPU work compared with redrawing on every display refresh.
    private val FRAME_MS = 33L
    private var resumeOnShow = false

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility != View.VISIBLE) {
            if (running) {
                running = false
                resumeOnShow = true
                sfx.humStop()
            }
        } else if (resumeOnShow) {
            resumeOnShow = false
            if (released) begin()
        }
    }

    private fun begin() {
        if (running) return
        running = true
        lastNanos = 0L
        postInvalidateOnAnimation()
    }

    // ============================== CONFIG ==============================
    private val SHOTS = 3
    private val ATOMS_BASE = 22
    private val ATOMS_MAX = 32
    private val NEUT_SPEED = 300f
    private val PRIMARY_LIFE = 1.9f
    private val SUMMARY_DELAY = 1.8f
    private val TAU = (PI * 2.0).toFloat()

    private val FUEL = 0
    private val ABS = 1
    private val RICH = 2

    private val PLAY = 0
    private val SUMMARY = 1

    private val COLS = intArrayOf(0xFFFFFF, 0xFF8A3D, 0x3FD0FF, 0xFFC27A)
    private val ABSORBERS = arrayOf("U-238", "B-10", "Cd-113")

    private class Pal(val glow: Int, val orb: Int, val e: Int, val n0: Int, val n1: Int)

    private val PALS = arrayOf(
        Pal(0x3FD0FF, 0x78D7FF, 0xBEF0FF, 0x3FD0FF, 0xCFF4FF),
        Pal(0x9A95B4, 0x9A95B4, 0xC8C4E1, 0x8B88A8, 0x6C6990),
        Pal(0xFF8A3D, 0xFFB46E, 0xFFDCAA, 0xFFB35A, 0xFF8A3D)
    )

    // ============================== TYPES ==============================
    private class Nuc(val dx: Float, val dy: Float, val alt: Int, val ph: Float)
    private class Orbit(val rot: Float, val ang: Float, val speed: Float)
    private class Atom(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        val r: Float, val kind: Int, val label: String, val phase: Float,
        val nuc: Array<Nuc>, val orbits: Array<Orbit>
    ) {
        var alive = true
        var flash = 0f
        var excite = 0f
        var appear = 0f
    }

    private class Neutron(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        val gen: Int, val life: Float
    ) {
        var age = 0f
        val trail = FloatArray(48)
        var tn = 0
        var dead = false
    }

    private class Particle(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        val max: Float, val s: Float, val rgb: Int, val drag: Float
    ) { var t = 0f }

    private class Ring(
        val x: Float, val y: Float, val r0: Float, val max: Float,
        val dur: Float, val rgb: Int
    ) { var t = 0f }

    private class Pop(
        val x: Float, val y: Float, val txt: String, val max: Float,
        val size: Float, val rgb: Int
    ) { var t = 0f }

    private class Mote(var x: Float, var y: Float, val s: Float, val v: Float, val ph: Float)

    // ============================== STATE ==============================
    private var W = 0f
    private var H = 0f
    private var dens = 1f
    private var u = 1f
    private var fl = 0f
    private var fr = 0f
    private var ft = 0f
    private var fb = 0f
    private var lx = 0f
    private var ly = 0f
    private var bg: Bitmap? = null

    private val atoms = ArrayList<Atom>()
    private val neutrons = ArrayList<Neutron>()
    private val queue = ArrayList<Neutron>()
    private val particles = ArrayList<Particle>()
    private val rings = ArrayList<Ring>()
    private val pops = ArrayList<Pop>()
    private val motes = ArrayList<Mote>()

    private var state = PLAY
    private var round = 0
    private var ammo = 0
    private var score = 0
    private var best = 0
    private var roundFuel = 0
    private var roundSplits = 0
    private var roundChain = 0
    private var roundPts = 0
    private var idle = 0f
    private var settle = 0f
    private var summaryT = 0f

    private var aiming = false
    private var aimAng = (-PI / 2).toFloat()
    private var drawAng = (-PI / 2).toFloat()
    private var aimX = 0f
    private var aimY = 0f
    private var pid = -1
    private var charge = 0f
    private var fireCd = 0f
    private var recoil = 0f
    private var shake = 0f
    private var flashA = 0f
    private var spinT = 0f
    private var T = 0f
    private var bounceCd = 0f

    private var bannerOn = false
    private var bannerA = 0f
    private var bannerTitle = ""
    private var bannerPts = ""
    private var bannerSmall = ""
    private var bannerRgb = 0xFFFFFF
    private var hintGone = false
    private var hintA = 1f
    private var muteDown = false

    private val prefs: SharedPreferences =
        context.getSharedPreferences("uranium_chain_reaction", Context.MODE_PRIVATE)
    private var muted = prefs.getBoolean("muted", false)
    private var lastBuzz = 0L

    // ============================== PAINTS ==============================
    private val addMode = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val addFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; xfermode = addMode }
    private val addStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; xfermode = addMode }
    private val dashP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shieldP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val beamP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; xfermode = addMode }
    private val textFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    }
    private val textStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    }
    private val bodyText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun radialPaint(additive: Boolean, colors: IntArray, stops: FloatArray): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, 1f, colors, stops, Shader.TileMode.CLAMP)
        if (additive) p.xfermode = addMode
        return p
    }

    private fun a255(rgb: Int, a: Int): Int = (a shl 24) or (rgb and 0xFFFFFF)

    private val haloPaints = Array(3) { k ->
        val g = PALS[k].glow
        radialPaint(true, intArrayOf(a255(g, 255), a255(g, 255), a255(g, 0)), floatArrayOf(0f, 0.111f, 1f))
    }
    private val neutGlow1 = radialPaint(
        true,
        intArrayOf(a255(0xFFFFFF, 242), a255(0xBEF0FF, 140), a255(0x3FD0FF, 0)),
        floatArrayOf(0f, 0.3f, 1f)
    )
    private val neutGlow2 = radialPaint(
        true,
        intArrayOf(a255(0xFFFFFF, 242), a255(0x7FE1FF, 140), a255(0x3FD0FF, 0)),
        floatArrayOf(0f, 0.3f, 1f)
    )
    private val coreGlow = radialPaint(
        true,
        intArrayOf(a255(0xFFFFFF, 255), a255(0xA0EBFF, 217), a255(0x3FD0FF, 0)),
        floatArrayOf(0f, 0.25f, 1f)
    )
    private val chamberP = radialPaint(
        false,
        intArrayOf(0xFF0D2A38.toInt(), 0xFF040C12.toInt()),
        floatArrayOf(0f, 1f)
    )

    private val tmpRect = RectF()
    private val tmpPath = Path()
    private val dstRect = RectF()

    private val sfx = Sfx()

    // ============================== HELPERS ==============================
    private fun rand(a: Float, b: Float): Float = a + Random.nextFloat() * (b - a)
    private fun clampF(v: Float, a: Float, b: Float): Float = max(a, min(b, v))
    private fun deg(rad: Float): Float = (rad * 180.0 / PI).toFloat()
    private fun eob(t: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val m = t - 1f
        return 1f + c3 * m * m * m + c1 * m * m
    }

    private fun alphaOf(a: Float): Int = (clampF(a, 0f, 1f) * 255f).toInt()
    private fun col(rgb: Int, a: Float): Int = a255(rgb, alphaOf(a))

    private fun buzz() {
        val now = SystemClock.uptimeMillis()
        if (now - lastBuzz < 90) return
        lastBuzz = now
        try {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        } catch (_: Exception) {
        }
    }

    private fun saveBest() {
        prefs.edit().putInt("best", best).apply()
    }

    private fun setMuted(m: Boolean) {
        muted = m
        prefs.edit().putBoolean("muted", m).apply()
        if (m) sfx.humStop()
    }

    // ============================== LAYOUT ==============================
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        dens = resources.displayMetrics.density
        W = w / dens
        H = h / dens
        u = clampF(min(W / 400f, H / 640f), 0.7f, 1.5f)
        lx = W / 2f
        ly = H - 70f - 45f * u
        fl = 14f
        fr = W - 14f
        ft = 62f
        fb = ly - 74f * u

        dashP.pathEffect = DashPathEffect(floatArrayOf(3f * u, 4f * u), 0f)
        shieldP.shader = LinearGradient(
            0f, -34f * u, 0f, 34f * u,
            0xFF34607A.toInt(), 0xFF0E2330.toInt(), Shader.TileMode.CLAMP
        )
        beamP.shader = LinearGradient(
            0f, 0f, 60f * u, 0f,
            0xFF7FE1FF.toInt(), 0x007FE1FF, Shader.TileMode.CLAMP
        )
        textStroke.strokeWidth = 3f * u
        buildBackground(w, h)

        motes.clear()
        for (i in 0 until 30) {
            motes.add(Mote(rand(0f, W), rand(ft, H), rand(0.8f, 2.2f), rand(5f, 16f), rand(0f, TAU)))
        }
        for (a in atoms) {
            a.x = a.x.coerceIn(fl + 30f * u, fr - 30f * u)
            a.y = a.y.coerceIn(ft + 30f * u, fb)
        }
        if (needRound && released) {
            needRound = false
            newRound()
        }
    }

    private fun buildBackground(pw: Int, ph: Int) {
        bg?.recycle()
        val bmp = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
        val g = Canvas(bmp)
        g.scale(dens, dens)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        p.shader = LinearGradient(0f, 0f, 0f, H, 0xFF04090D.toInt(), 0xFF071720.toInt(), Shader.TileMode.CLAMP)
        g.drawRect(0f, 0f, W, H, p)

        val poolR = max(W, 300f) * 0.85f
        p.shader = RadialGradient(
            lx, ly, poolR,
            intArrayOf(0x473FD0FF, 0x123FD0FF, 0x003FD0FF),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        g.drawRect(0f, 0f, W, H, p)
        p.shader = null

        // fuel lattice
        p.style = Paint.Style.FILL
        p.color = 0x12A0DCFF
        val step = 36f * u
        var y = ft
        while (y <= fb + 40f * u) {
            var x = fl + 6f
            while (x <= fr) {
                g.drawCircle(x, y, 1.1f, p)
                x += step
            }
            y += step
        }

        // reactor wall
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = 0x293FD0FF
        p.pathEffect = DashPathEffect(floatArrayOf(3f, 7f), 0f)
        val wall = Path()
        wall.moveTo(fl - 4f, ly)
        wall.lineTo(fl - 4f, ft - 6f)
        wall.lineTo(fr + 4f, ft - 6f)
        wall.lineTo(fr + 4f, ly)
        g.drawPath(wall, p)
        p.pathEffect = null

        // floor
        val fy = ly + 12f * u
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, fy, 0f, H, 0xFF0B1D27.toInt(), 0xFF050B10.toInt(), Shader.TileMode.CLAMP)
        g.drawRect(0f, fy, W, H, p)
        p.shader = null
        p.color = 0x29FF8A3D
        var sx = -10f
        val stripe = Path()
        while (sx < W) {
            stripe.reset()
            stripe.moveTo(sx, fy)
            stripe.lineTo(sx + 11f * u, fy)
            stripe.lineTo(sx + 5f * u, fy + 6f * u)
            stripe.lineTo(sx - 6f * u, fy + 6f * u)
            stripe.close()
            g.drawPath(stripe, p)
            sx += 22f * u
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = 0x473FD0FF
        g.drawLine(0f, fy, W, fy, p)
        bg = bmp
    }

    // ============================== GAME FLOW ==============================
    private fun resetGame() {
        atoms.clear(); neutrons.clear(); queue.clear()
        particles.clear(); rings.clear(); pops.clear()
        round = 0
        score = 0
        charge = 0f
        hintGone = false
        hintA = 1f
        bannerOn = false
        bannerA = 0f
        best = prefs.getInt("best", 0)
        if (W > 0f) {
            needRound = false
            newRound()
        } else {
            needRound = true
        }
    }

    private fun addScore(v: Int) {
        score = v
        if (score > best) best = score
    }

    private fun newRound() {
        round++
        ammo = SHOTS
        neutrons.clear()
        roundSplits = 0; roundChain = 0; roundPts = 0
        idle = 0f; settle = 0f
        state = PLAY
        bannerOn = false
        spawnAtoms()
    }

    private fun makeAtom(x: Float, y: Float, kind: Int): Atom {
        val r = (if (kind == RICH) rand(15f, 17f) else rand(13f, 15.5f)) * u
        val dir = rand(0f, TAU)
        val sp = rand(10f, 24f) * u
        val nn = if (kind == RICH) 14 else if (kind == FUEL) 10 else 11
        val nuc = Array(nn) { i ->
            val a = rand(0f, TAU)
            val d = sqrt(Random.nextFloat()) * r * 0.6f
            Nuc(cos(a) * d, sin(a) * d, i % 2, rand(0f, TAU))
        }
        val cnt = if (kind == RICH) 4 else if (kind == FUEL) 3 else 2
        val orbits = Array(cnt) { i ->
            Orbit(
                i * PI.toFloat() / cnt, rand(0f, TAU),
                rand(1.6f, 2.8f) * (if (Random.nextFloat() < 0.5f) -1f else 1f)
            )
        }
        val label = when (kind) {
            FUEL -> "U-235"
            RICH -> "Pu-239"
            else -> ABSORBERS[Random.nextInt(ABSORBERS.size)]
        }
        val a = Atom(x, y, cos(dir) * sp, sin(dir) * sp, r, kind, label, rand(0f, TAU), nuc, orbits)
        a.appear = -rand(0f, 0.5f)
        return a
    }

    private fun spawnAtoms() {
        atoms.clear()
        val n = min(ATOMS_BASE + ((round - 1) / 2) * 2, ATOMS_MAX)
        val absorbers = min(3 + round, 9)
        val rich = if (round >= 3) 2 else 1
        val kinds = ArrayList<Int>()
        for (i in 0 until n) kinds.add(if (i < absorbers) ABS else if (i < absorbers + rich) RICH else FUEL)
        kinds.shuffle()
        val area = max(1f, (fr - fl - 60f * u) * (fb - ft - 44f * u))
        var minD = clampF(0.74f * sqrt(area / n), 34f * u, 90f * u)
        for (k in kinds) {
            var x: Float
            var y: Float
            var ok: Boolean
            var tries = 0
            do {
                x = rand(fl + 30f * u, fr - 30f * u)
                y = rand(ft + 30f * u, fb - 8f * u)
                ok = true
                for (i in 0 until atoms.size) {
                    val o = atoms[i]
                    if (hypot(o.x - x, o.y - y) < minD) { ok = false; break }
                }
                tries++
                if (tries % 60 == 0) minD *= 0.9f
            } while (!ok && tries < 400)
            atoms.add(makeAtom(x, y, k))
        }
        var f = 0
        for (a in atoms) if (a.kind != ABS) f++
        roundFuel = f
    }

    private fun endRound() {
        state = SUMMARY
        summaryT = 0f
        val total = roundFuel
        val ratio = if (total > 0) roundSplits.toFloat() / total else 0f
        val title: String
        val level: Int
        if (ratio >= 0.8f) { title = "Supercritical"; bannerRgb = 0xFF8A3D; level = 2 }
        else if (ratio >= 0.4f) { title = "Critical"; bannerRgb = 0x3FD0FF; level = 1 }
        else { title = "Subcritical"; bannerRgb = 0x9A95B4; level = 0 }
        var bonus = 0
        if (ratio >= 0.8f && ammo > 0) bonus += ammo * 25
        val perfect = total > 0 && roundSplits >= total
        if (perfect) bonus += 50
        if (bonus > 0) addScore(score + bonus)
        bannerTitle = title
        bannerPts = "+" + (roundPts + bonus)
        var small = "$roundSplits of $total atoms split, chain of $roundChain"
        if (ratio < 0.4f) small = "$roundSplits of $total atoms split. The reaction fizzled."
        if (perfect) small += ". Perfect reaction +50"
        if (ratio >= 0.8f && ammo > 0) {
            small += ". Saved $ammo " + (if (ammo == 1) "neutron" else "neutrons") + " +" + (ammo * 25)
        }
        bannerSmall = small
        bannerOn = true
        sfx.round(level)
        saveBest()
    }

    // ============================== INPUT ==============================
    private fun muteRect(r: RectF) {
        r.set(W - 54f, H - 52f, W - 10f, H - 8f)
    }

    private fun setAim(px: Float, py: Float) {
        aimX = px / dens
        aimY = py / dens
        val a = atan2(aimY - ly, aimX - lx)
        aimAng = clampF(a, -PI.toFloat() + 0.15f, -0.15f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!running) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = e.x / dens
                val y = e.y / dens
                muteRect(tmpRect)
                if (tmpRect.contains(x, y)) {
                    muteDown = true
                    return true
                }
                if (state != PLAY || ammo <= 0) return true
                aiming = true
                pid = e.getPointerId(0)
                setAim(e.x, e.y)
                sfx.humStart()
            }
            MotionEvent.ACTION_MOVE -> {
                if (aiming) {
                    val i = e.findPointerIndex(pid)
                    if (i >= 0) setAim(e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP -> {
                if (muteDown) {
                    muteDown = false
                    muteRect(tmpRect)
                    if (tmpRect.contains(e.x / dens, e.y / dens)) setMuted(!muted)
                    return true
                }
                if (aiming) {
                    aiming = false
                    setAim(e.x, e.y)
                    if (hypot(aimX - lx, aimY - ly) > 34f * u) fire() else sfx.humStop()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                aiming = false
                muteDown = false
                sfx.humStop()
            }
        }
        return true
    }

    private fun fire() {
        if (state != PLAY || ammo <= 0 || fireCd > 0f) return
        val c = cos(aimAng)
        val s = sin(aimAng)
        val life = PRIMARY_LIFE * (0.85f + 0.3f * charge)
        neutrons.add(
            Neutron(
                lx + c * 34f * u, ly + s * 34f * u,
                c * NEUT_SPEED * u, s * NEUT_SPEED * u, 1, life
            )
        )
        rings.add(Ring(lx + c * 34f * u, ly + s * 34f * u, 4f * u, (30f + 20f * charge) * u, 0.35f, 0x3FD0FF))
        for (i in 0 until 10) {
            val an = aimAng + rand(-0.5f, 0.5f)
            val sp = rand(60f, 200f) * u
            particles.add(
                Particle(lx + c * 30f * u, ly + s * 30f * u, cos(an) * sp, sin(an) * sp,
                    rand(0.2f, 0.45f), rand(1.2f, 2.4f) * u, 0xBEF0FF, 3f)
            )
        }
        sfx.fire(charge)
        buzz()
        charge = 0f
        sfx.humStop()
        ammo--
        fireCd = 0.22f
        recoil = 1f
        idle = 0f
        shake = min(shake + 2f * u, 14f * u)
        hintGone = true
    }

    // ============================== PHYSICS ==============================
    private fun fission(a: Atom, gen: Int) {
        a.alive = false
        val rich = a.kind == RICH
        roundSplits++
        roundChain = max(roundChain, gen)
        val pts = (if (rich) 30 else 10) * gen
        roundPts += pts
        addScore(score + pts)

        val cnt = if (particles.size > 500) 8 else 24
        for (i in 0 until cnt) {
            val an = rand(0f, TAU)
            val sp = rand(60f, 260f) * u
            particles.add(
                Particle(a.x, a.y, cos(an) * sp, sin(an) * sp, rand(0.35f, 0.8f), rand(1.5f, 3.2f) * u,
                    if (rich) 0xFFC27A else COLS[i % 4], 2.2f)
            )
        }
        val da = rand(0f, TAU)
        for (k in 0 until 2) {
            val an = da + k * PI.toFloat()
            val sp = rand(70f, 110f) * u
            particles.add(Particle(a.x, a.y, cos(an) * sp, sin(an) * sp, 0.95f, 6.5f * u, 0xFF8A3D, 1.3f))
        }
        rings.add(Ring(a.x, a.y, a.r, (if (rich) 120f else 92f) * u, 0.55f, 0xFF8A3D))
        rings.add(Ring(a.x, a.y, a.r, 58f * u, 0.38f, 0x3FD0FF))
        pops.add(Pop(a.x, a.y - a.r * 1.4f, "+$pts", 1f, (16f + min(gen, 8) * 2.2f) * u,
            if (rich) 0xFFC27A else 0xEAFBFF))

        val n = if (rich) 4 else (if (Random.nextFloat() < 0.45f) 2 else 3)
        val base = rand(0f, TAU)
        val life = max(0.95f, 1.35f - round * 0.04f)
        for (i in 0 until n) {
            val an = base + (i.toFloat() / n) * TAU + rand(-0.35f, 0.35f)
            val sp = NEUT_SPEED * u * rand(0.9f, 1.1f)
            queue.add(
                Neutron(
                    a.x + cos(an) * (a.r + 6f * u), a.y + sin(an) * (a.r + 6f * u),
                    cos(an) * sp, sin(an) * sp, gen + 1, life
                )
            )
        }
        shake = min(shake + (3f + gen * 0.9f) * u, 14f * u)
        flashA = min(flashA + 0.12f, 0.35f)
        sfx.split(gen)
        buzz()
    }

    private fun absorb(a: Atom) {
        a.flash = 1f
        for (i in 0 until 12) {
            val an = rand(0f, TAU)
            val sp = rand(20f, 90f) * u
            particles.add(Particle(a.x, a.y, cos(an) * sp, sin(an) * sp, rand(0.3f, 0.6f), rand(1.2f, 2.4f) * u, 0x9A95B4, 3f))
        }
        rings.add(Ring(a.x, a.y, a.r * 0.8f, 40f * u, 0.35f, 0x9A95B4))
        sfx.absorb()
    }

    private fun bounceSfx() {
        if (bounceCd <= 0f) {
            sfx.bounce()
            bounceCd = 0.06f
        }
    }

    private fun updateAtoms(dt: Float) {
        for (i in 0 until atoms.size) {
            val a = atoms[i]
            if (!a.alive) continue
            a.appear = min(1f, a.appear + dt * 2.2f)
            a.flash = max(0f, a.flash - dt * 3f)
            a.excite = max(0f, a.excite - dt * 2.4f)
            a.x += a.vx * dt
            a.y += a.vy * dt
            val m = a.r * 1.5f
            if (a.x < fl + m) { a.x = fl + m; a.vx = abs(a.vx) }
            else if (a.x > fr - m) { a.x = fr - m; a.vx = -abs(a.vx) }
            if (a.y < ft + m) { a.y = ft + m; a.vy = abs(a.vy) }
            else if (a.y > fb) { a.y = fb; a.vy = -abs(a.vy) }
        }
        for (i in 0 until atoms.size) {
            val a = atoms[i]
            if (!a.alive) continue
            for (j in i + 1 until atoms.size) {
                val b = atoms[j]
                if (!b.alive) continue
                val dx = b.x - a.x
                val dy = b.y - a.y
                val d = hypot(dx, dy)
                val mn = (a.r + b.r) * 1.8f
                if (d < mn && d > 0.01f) {
                    val p = (mn - d) * 0.5f / d
                    a.x -= dx * p; a.y -= dy * p
                    b.x += dx * p; b.y += dy * p
                    val t1 = a.vx
                    val t2 = a.vy
                    a.vx = b.vx; a.vy = b.vy
                    b.vx = t1; b.vy = t2
                }
            }
        }
    }

    private fun updateNeutrons(dt: Float) {
        queue.clear()
        val rm = 4f * u
        for (i in 0 until neutrons.size) {
            val n = neutrons[i]
            n.age += dt
            if (n.tn >= 48) {
                System.arraycopy(n.trail, 2, n.trail, 0, 46)
                n.tn = 46
            }
            n.trail[n.tn] = n.x
            n.trail[n.tn + 1] = n.y
            n.tn += 2
            n.x += n.vx * dt
            n.y += n.vy * dt
            if (n.y < ft - 6f + rm && n.vy < 0f) { n.y = ft - 6f + rm; n.vy = -n.vy; bounceSfx() }
            if (n.y < ly) {
                if (n.x < fl - 4f + rm && n.vx < 0f) { n.x = fl - 4f + rm; n.vx = -n.vx; bounceSfx() }
                else if (n.x > fr + 4f - rm && n.vx > 0f) { n.x = fr + 4f - rm; n.vx = -n.vx; bounceSfx() }
            }
            if (n.age >= n.life || n.y > ly + 8f * u) {
                n.dead = true
                for (k in 0 until 4) {
                    val an = rand(0f, TAU)
                    val sp = rand(10f, 40f) * u
                    particles.add(Particle(n.x, n.y, cos(an) * sp, sin(an) * sp, 0.3f, 1.4f * u, 0x7FE1FF, 3f))
                }
                continue
            }
            for (j in 0 until atoms.size) {
                val a = atoms[j]
                if (!a.alive || a.appear < 0.5f) continue
                val d = hypot(a.x - n.x, a.y - n.y)
                if (d < a.r * 1.25f + 4f * u) {
                    n.dead = true
                    if (a.kind == ABS) absorb(a) else fission(a, n.gen)
                    break
                }
                if (d < a.r * 3.2f) a.excite = min(1f, a.excite + dt * 6f)
            }
        }
        neutrons.removeAll { it.dead }
        neutrons.addAll(queue)
        queue.clear()
    }

    private fun update(dt: Float) {
        T += dt
        if (fireCd > 0f) fireCd -= dt
        if (bounceCd > 0f) bounceCd -= dt
        recoil = max(0f, recoil - dt * 6f)
        shake = max(0f, shake - dt * 30f * u)
        flashA = max(0f, flashA - dt * 1.6f)

        if (aiming && ammo > 0) {
            charge = min(1f, charge + dt * 1.8f)
            sfx.humSet(charge)
            if (Random.nextFloat() < dt * 60f) {
                val an = rand(0f, TAU)
                val r = 30f * u
                particles.add(Particle(lx + cos(an) * r, ly + sin(an) * r, -cos(an) * r / 0.25f, -sin(an) * r / 0.25f,
                    0.25f, 1.6f * u, 0x7FE1FF, 0f))
            }
        } else {
            charge = max(0f, charge - dt * 3f)
        }
        spinT += dt * (0.6f + charge * 6f)
        drawAng += (aimAng - drawAng) * min(1f, dt * 18f)

        updateAtoms(dt)
        updateNeutrons(dt)

        for (i in 0 until particles.size) {
            val p = particles[i]
            p.t += dt
            val k = max(0f, 1f - p.drag * dt)
            p.vx *= k; p.vy *= k
            p.x += p.vx * dt; p.y += p.vy * dt
        }
        particles.removeAll { it.t >= it.max }
        for (i in 0 until rings.size) rings[i].t += dt
        rings.removeAll { it.t >= it.dur }
        for (i in 0 until pops.size) pops[i].t += dt
        pops.removeAll { it.t >= it.max }
        for (i in 0 until motes.size) {
            val m = motes[i]
            m.y -= m.v * dt
            if (m.y < ft - 10f) { m.y = H; m.x = rand(0f, W) }
        }

        if (state == PLAY && Random.nextFloat() < dt * (2f + neutrons.size * 10f)) sfx.geiger()

        if (state == PLAY) {
            var fuelAlive = false
            for (a in atoms) if (a.alive && a.kind != ABS) { fuelAlive = true; break }
            if (neutrons.isEmpty() && !aiming && (ammo == 0 || !fuelAlive)) {
                settle += dt
                if (settle > 0.7f) endRound()
            } else settle = 0f
            if (neutrons.isEmpty() && ammo > 0 && !aiming) {
                idle += dt
                if (idle > 6f) hintGone = false
            } else idle = 0f
        } else {
            summaryT += dt
            if (summaryT > SUMMARY_DELAY) newRound()
        }

        // soft fades
        val bt = if (bannerOn && state == SUMMARY) 1f else 0f
        bannerA += (bt - bannerA) * min(1f, dt * 10f)
        val ht = if (hintGone) 0f else 1f
        hintA += (ht - hintA) * min(1f, dt * 5f)
    }

    // ============================== DRAWING ==============================
    private fun drawAtom(c: Canvas, a: Atom) {
        val s = eob(clampF(a.appear, 0f, 1f))
        if (s <= 0.01f) return
        val r = a.r
        val pal = PALS[a.kind]
        val ex = a.excite
        c.save()
        c.translate(a.x, a.y)
        c.scale(s, s)

        // halo
        val haloA = (if (a.kind == ABS) 0.22f else 0.34f) + 0.3f * ex
        val hp = haloPaints[a.kind]
        hp.alpha = alphaOf(haloA)
        c.save()
        c.scale(r * 2.7f, r * 2.7f)
        c.drawCircle(0f, 0f, 1f, hp)
        c.restore()

        // electron orbits
        addStroke.strokeWidth = 1f
        for (o in a.orbits) {
            c.save()
            c.rotate(deg(o.rot + T * 0.15f * (if (o.speed > 0f) 1f else -1f)))
            addStroke.color = col(pal.orb, 0.26f + 0.3f * ex)
            tmpRect.set(-r * 1.75f, -r * 0.62f, r * 1.75f, r * 0.62f)
            c.drawOval(tmpRect, addStroke)
            val ang = o.ang + T * o.speed * (1f + ex * 1.6f)
            val px = cos(ang) * r * 1.75f
            val py = sin(ang) * r * 0.62f
            addFill.color = col(pal.e, 0.28f)
            c.drawCircle(px, py, 3.6f * u, addFill)
            addFill.color = col(0xFFFFFF, 0.95f)
            c.drawCircle(px, py, 1.6f * u, addFill)
            c.restore()
        }

        // special rings
        if (a.kind == ABS) {
            c.save()
            c.rotate(deg(T * 0.5f))
            dashP.strokeWidth = 1.4f
            dashP.color = col(0x9A95B4, 0.6f)
            c.drawCircle(0f, 0f, r * 1.12f, dashP)
            c.restore()
        } else if (a.kind == RICH) {
            val pr = r * (1.15f + 0.1f * sin(T * 4f + a.phase))
            strokeP.strokeWidth = 1.6f
            strokeP.color = col(0xFFAA5A, 0.7f)
            c.drawCircle(0f, 0f, pr, strokeP)
        }

        // nucleus
        val nr = r * 0.3f
        for (p in a.nuc) {
            val wob = sin(T * 3f + p.ph) * 0.6f * u
            val cx = p.dx + wob
            val cy = p.dy + cos(T * 2.6f + p.ph) * 0.5f * u
            fillP.color = 0xFF000000.toInt() or (if (p.alt == 0) pal.n0 else pal.n1)
            c.drawCircle(cx, cy, nr, fillP)
            fillP.color = col(0xFFFFFF, 0.45f)
            c.drawCircle(cx - nr * 0.3f, cy - nr * 0.3f, nr * 0.35f, fillP)
        }
        if (a.flash > 0f) {
            fillP.color = col(0xFFFFFF, a.flash * 0.6f)
            c.drawCircle(0f, 0f, r * 1.25f, fillP)
        }

        // isotope label
        val ts = 11f * u
        textStroke.textSize = ts
        textFill.textSize = ts
        textStroke.color = col(0x03080C, 0.85f)
        textFill.color = 0xFF000000.toInt() or (if (a.kind == ABS) 0xC9C5E0 else if (a.kind == RICH) 0xFFC58A else 0xBFF0FF)
        val dy = -(textFill.ascent() + textFill.descent()) / 2f
        c.drawText(a.label, 0f, r * 1.95f + dy, textStroke)
        c.drawText(a.label, 0f, r * 1.95f + dy, textFill)
        c.restore()
    }

    private fun drawNeutron(c: Canvas, n: Neutron) {
        val fade = clampF((n.life - n.age) / 0.25f, 0f, 1f)
        val rgb = if (n.gen == 1) 0xBEF0FF else 0x7FE1FF
        val cnt = n.tn / 2
        for (i in 0 until cnt) {
            val k = (i + 1).toFloat() / cnt
            addFill.color = col(rgb, k * 0.35f * fade)
            c.drawCircle(n.trail[i * 2], n.trail[i * 2 + 1], (1f + 3.4f * k) * u, addFill)
        }
        val r = (if (n.gen == 1) 6f else 4.6f) * u
        val gp = if (n.gen == 1) neutGlow1 else neutGlow2
        gp.alpha = alphaOf(fade)
        c.save()
        c.translate(n.x, n.y)
        c.scale(r * 3f, r * 3f)
        c.drawCircle(0f, 0f, 1f, gp)
        c.restore()
    }

    private fun drawPreview(c: Canvas) {
        if (!aiming || ammo <= 0) return
        val cc = cos(aimAng)
        val ss = sin(aimAng)
        var x = lx + cc * 30f * u
        var y = ly + ss * 30f * u
        var dx = cc
        var dy = ss
        val total = NEUT_SPEED * u * PRIMARY_LIFE * (0.85f + 0.3f * charge)
        val step = 5f * u
        val rm = 4f * u
        var dist = 0f
        var k = 0
        var hit: Atom? = null
        while (dist < total) {
            x += dx * step; y += dy * step; dist += step; k++
            if (y < ft - 6f + rm && dy < 0f) { y = ft - 6f + rm; dy = -dy }
            if (x < fl - 4f + rm && dx < 0f) { x = fl - 4f + rm; dx = -dx }
            else if (x > fr + 4f - rm && dx > 0f) { x = fr + 4f - rm; dx = -dx }
            if (y > ly) break
            for (i in 0 until atoms.size) {
                val a = atoms[i]
                if (a.alive && a.appear > 0.5f && hypot(a.x - x, a.y - y) < a.r * 1.25f + 4f * u) { hit = a; break }
            }
            if (hit != null) break
            if (k % 3 == 0) {
                fillP.color = col(0x7FE1FF, (1f - dist / total) * 0.8f)
                c.drawCircle(x, y, 1.5f * u, fillP)
            }
        }
        val h = hit
        if (h != null) {
            strokeP.strokeWidth = 1.6f
            strokeP.color = col(PALS[h.kind].glow, 0.55f + 0.3f * sin(T * 10f))
            c.drawCircle(h.x, h.y, h.r * 2.1f, strokeP)
        }
    }

    private fun drawEmitter(c: Canvas) {
        val ch = charge
        val loaded = ammo > 0
        c.save()
        c.translate(lx, ly + recoil * 3f * u)

        // socket
        fillP.color = 0xFF06111A.toInt()
        c.drawCircle(0f, 0f, 45f * u, fillP)
        strokeP.strokeWidth = 1.5f
        strokeP.color = col(0x3FD0FF, 0.2f)
        c.drawCircle(0f, 0f, 45f * u, strokeP)

        // ammo arcs
        val seg = TAU / SHOTS
        strokeP.strokeCap = Paint.Cap.ROUND
        tmpRect.set(-40f * u, -40f * u, 40f * u, 40f * u)
        for (i in 0 until SHOTS) {
            val a0 = PI.toFloat() / 2f + i * seg + 0.22f
            val sweep = seg - 0.44f
            val lit = i < ammo
            strokeP.strokeWidth = 3.2f * u
            strokeP.color = if (lit) col(0x3FD0FF, 0.95f) else col(0x3FD0FF, 0.14f)
            c.drawArc(tmpRect, deg(a0), deg(sweep), false, strokeP)
            if (lit) {
                strokeP.strokeWidth = 7f * u
                strokeP.color = col(0x3FD0FF, 0.25f)
                c.drawArc(tmpRect, deg(a0), deg(sweep), false, strokeP)
            }
        }
        strokeP.strokeCap = Paint.Cap.BUTT

        // shield ring
        val gap = 0.42f
        shieldP.strokeWidth = 8f * u
        tmpRect.set(-30.5f * u, -30.5f * u, 30.5f * u, 30.5f * u)
        c.drawArc(tmpRect, deg(drawAng + gap), deg(TAU - 2f * gap), false, shieldP)
        strokeP.strokeWidth = 1f
        strokeP.color = col(0xBEF0FF, 0.18f)
        tmpRect.set(-34.5f * u, -34.5f * u, 34.5f * u, 34.5f * u)
        c.drawArc(tmpRect, deg(drawAng + gap), deg(TAU - 2f * gap), false, strokeP)

        // coils
        for (i in 0 until 8) {
            val a = spinT + i * TAU / 8f
            c.save()
            c.rotate(deg(a))
            c.translate(23f * u, 0f)
            fillP.color = 0xFF1D4A60.toInt()
            c.drawRect(-2.6f * u, -4.5f * u, 2.6f * u, 4.5f * u, fillP)
            strokeP.strokeWidth = 1f
            strokeP.color = col(0x3FD0FF, 0.25f + 0.7f * ch)
            c.drawRect(-2.6f * u, -4.5f * u, 2.6f * u, 4.5f * u, strokeP)
            c.restore()
        }

        // lens plates and beam
        c.save()
        c.rotate(deg(drawAng))
        strokeP.strokeWidth = 3f * u
        strokeP.color = 0xFF4B8AA6.toInt()
        strokeP.strokeCap = Paint.Cap.ROUND
        c.drawLine(31f * u, -11f * u, 45f * u, -(16f - 6f * ch) * u, strokeP)
        c.drawLine(31f * u, 11f * u, 45f * u, (16f - 6f * ch) * u, strokeP)
        strokeP.strokeCap = Paint.Cap.BUTT
        if (ch > 0.05f && loaded) {
            beamP.alpha = alphaOf(0.35f * ch)
            tmpPath.reset()
            tmpPath.moveTo(10f * u, -4f * u)
            tmpPath.lineTo(60f * u, -(14f - 8f * ch) * u)
            tmpPath.lineTo(60f * u, (14f - 8f * ch) * u)
            tmpPath.lineTo(10f * u, 4f * u)
            tmpPath.close()
            c.drawPath(tmpPath, beamP)
        }
        c.restore()

        // chamber
        c.save()
        c.scale(19f * u, 19f * u)
        c.drawCircle(0f, 0f, 1f, chamberP)
        c.restore()

        // confinement rings
        strokeP.strokeWidth = 1f
        for (i in 0 until 3) {
            c.save()
            c.rotate(deg(spinT * (if (i % 2 == 1) -1f else 1f) * 0.7f + i * PI.toFloat() / 3f))
            strokeP.color = col(0x3FD0FF, 0.22f + 0.5f * ch)
            tmpRect.set(-15f * u, -6f * u, 15f * u, 6f * u)
            c.drawOval(tmpRect, strokeP)
            c.restore()
        }

        // neutron in the core
        if (loaded) {
            val rc = (4.5f + ch * 6f) * u * (1f + 0.08f * sin(T * 14f))
            coreGlow.alpha = 255
            c.save()
            c.scale(rc * 3.4f, rc * 3.4f)
            c.drawCircle(0f, 0f, 1f, coreGlow)
            c.restore()
        } else {
            addFill.color = col(0x3FD0FF, 0.22f)
            c.drawCircle(0f, 0f, 3.5f * u, addFill)
        }
        c.restore()
    }

    private fun drawHud(c: Canvas) {
        bodyText.textSize = 12f
        bodyText.color = 0xFF7F9BAA.toInt()
        bodyText.textAlign = Paint.Align.LEFT
        c.drawText("Score", 18f, 18f, bodyText)
        bodyText.textAlign = Paint.Align.CENTER
        c.drawText("Round", W / 2f, 18f, bodyText)
        bodyText.textAlign = Paint.Align.RIGHT
        c.drawText("Best", W - 18f, 18f, bodyText)

        textFill.textSize = 26f
        textFill.color = 0xFFEAFBFF.toInt()
        textFill.textAlign = Paint.Align.LEFT
        c.drawText(score.toString(), 18f, 46f, textFill)
        textFill.textAlign = Paint.Align.CENTER
        c.drawText(round.toString(), W / 2f, 46f, textFill)
        textFill.textAlign = Paint.Align.RIGHT
        c.drawText(best.toString(), W - 18f, 46f, textFill)
        textFill.textAlign = Paint.Align.CENTER
    }

    private fun drawBanner(c: Canvas) {
        if (bannerA <= 0.01f) return
        val bs = clampF(u * 1.15f, 0.8f, 1.2f)
        val cy = ft + (fb - ft) * 0.18f + (1f - bannerA) * 8f
        val a = bannerA
        textFill.textAlign = Paint.Align.CENTER
        textFill.textSize = 34f * bs
        textFill.color = col(bannerRgb, a)
        c.drawText(bannerTitle, W / 2f, cy + 30f * bs, textFill)
        textFill.textSize = 70f * bs
        textFill.color = col(0xFFFFFF, a)
        c.drawText(bannerPts, W / 2f, cy + 30f * bs + 66f * bs, textFill)

        bodyText.textSize = 15f
        bodyText.textAlign = Paint.Align.CENTER
        bodyText.color = col(0xA9C3CF, a)
        val maxW = W - 56f
        val words = bannerSmall.split(" ")
        var line = ""
        var yy = cy + 30f * bs + 66f * bs + 26f
        for (w in words) {
            val test = if (line.isEmpty()) w else "$line $w"
            if (bodyText.measureText(test) > maxW && line.isNotEmpty()) {
                c.drawText(line, W / 2f, yy, bodyText)
                yy += 20f
                line = w
            } else line = test
        }
        if (line.isNotEmpty()) c.drawText(line, W / 2f, yy, bodyText)
    }

    private fun drawHint(c: Canvas) {
        if (hintA <= 0.01f) return
        bodyText.textSize = 12.5f
        bodyText.textAlign = Paint.Align.LEFT
        val lh = 17.5f
        val y1 = H - 10f - lh * 2f - 4f
        // line 1
        bodyText.color = col(0x7F9BAA, hintA)
        val l1 = "Hold to charge and aim, release to fire."
        c.drawText(l1, W / 2f - bodyText.measureText(l1) / 2f, y1, bodyText)
        // line 2: two colours
        val s1 = "U-235 splits. "
        val s2 = "U-238, B-10, Cd-113 absorb."
        val w1 = bodyText.measureText(s1)
        val w2 = bodyText.measureText(s2)
        val x2 = W / 2f - (w1 + w2) / 2f
        bodyText.color = col(0x3FD0FF, hintA)
        c.drawText(s1, x2, y1 + lh, bodyText)
        bodyText.color = col(0x9A95B4, hintA)
        c.drawText(s2, x2 + w1, y1 + lh, bodyText)
        // line 3
        bodyText.color = col(0xFF8A3D, hintA)
        val l3 = "Pu-239 splits into four."
        c.drawText(l3, W / 2f - bodyText.measureText(l3) / 2f, y1 + lh * 2f, bodyText)
    }

    private fun drawMute(c: Canvas) {
        muteRect(tmpRect)
        val cx = tmpRect.centerX()
        val cy = tmpRect.centerY()
        fillP.color = col(0xFFFFFF, 0.04f)
        c.drawCircle(cx, cy, 22f, fillP)
        strokeP.strokeWidth = 1f
        strokeP.color = col(0xFFFFFF, 0.12f)
        c.drawCircle(cx, cy, 22f, strokeP)
        strokeP.strokeWidth = 1.8f
        strokeP.color = 0xFF9FC3D3.toInt()
        strokeP.strokeCap = Paint.Cap.ROUND
        strokeP.strokeJoin = Paint.Join.ROUND
        tmpPath.reset()
        tmpPath.moveTo(cx - 8f, cy - 2.5f)
        tmpPath.lineTo(cx - 4.5f, cy - 2.5f)
        tmpPath.lineTo(cx, cy - 6.5f)
        tmpPath.lineTo(cx, cy + 6.5f)
        tmpPath.lineTo(cx - 4.5f, cy + 2.5f)
        tmpPath.lineTo(cx - 8f, cy + 2.5f)
        tmpPath.close()
        c.drawPath(tmpPath, strokeP)
        if (muted) {
            c.drawLine(cx + 4f, cy - 3f, cx + 9f, cy + 3f, strokeP)
            c.drawLine(cx + 9f, cy - 3f, cx + 4f, cy + 3f, strokeP)
        } else {
            tmpRect.set(cx - 4f, cy - 5f, cx + 5f, cy + 5f)
            c.drawArc(tmpRect, -50f, 100f, false, strokeP)
            tmpRect.set(cx - 4f, cy - 9f, cx + 9f, cy + 9f)
            c.drawArc(tmpRect, -50f, 100f, false, strokeP)
        }
        strokeP.strokeCap = Paint.Cap.BUTT
    }

    private fun render(c: Canvas) {
        c.save()
        c.scale(dens, dens)

        val b = bg
        if (b != null) {
            dstRect.set(0f, 0f, W, H)
            c.drawBitmap(b, null, dstRect, null)
        }

        c.save()
        if (shake > 0.1f) c.translate(rand(-shake, shake) * 0.5f, rand(-shake, shake) * 0.5f)

        for (i in 0 until motes.size) {
            val m = motes[i]
            addFill.color = col(0x5AC8FF, 0.1f + 0.1f * sin(T * 1.5f + m.ph))
            c.drawCircle(m.x, m.y, m.s * u, addFill)
        }

        for (i in 0 until atoms.size) if (atoms[i].alive) drawAtom(c, atoms[i])
        drawPreview(c)
        for (i in 0 until neutrons.size) drawNeutron(c, neutrons[i])

        for (i in 0 until particles.size) {
            val p = particles[i]
            val al = 1f - p.t / p.max
            addFill.color = col(p.rgb, al)
            c.drawCircle(p.x, p.y, max(0.3f, p.s * (0.5f + 0.5f * al)), addFill)
        }
        for (i in 0 until rings.size) {
            val r = rings[i]
            val k = r.t / r.dur
            val e = 1f - (1f - k).pow(3)
            addStroke.color = col(r.rgb, (1f - k) * 0.85f)
            addStroke.strokeWidth = max(0.5f, 3f * u * (1f - k))
            c.drawCircle(r.x, r.y, r.r0 + (r.max - r.r0) * e, addStroke)
        }
        for (i in 0 until pops.size) {
            val p = pops[i]
            val k = p.t / p.max
            textFill.textSize = p.size
            textFill.color = col(p.rgb, 1f - k * k)
            val dy = -(textFill.ascent() + textFill.descent()) / 2f
            c.drawText(p.txt, p.x, p.y - k * 26f * u + dy, textFill)
        }

        drawEmitter(c)
        c.restore()

        if (flashA > 0.01f) {
            addFill.color = col(0xA0E1FF, flashA * 0.4f)
            c.drawRect(0f, 0f, W, H, addFill)
        }

        drawHud(c)
        drawBanner(c)
        drawHint(c)
        drawMute(c)
        c.restore()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (W <= 0f) return
        if (running) {
            val now = System.nanoTime()
            var dt = if (lastNanos == 0L) 0f else (now - lastNanos) / 1_000_000_000f
            if (dt > 0.05f) dt = 0.05f
            lastNanos = now
            update(dt)
        }
        render(canvas)
        if (running) postInvalidateDelayed(FRAME_MS)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        running = false
        sfx.release()
    }

    // ============================== SOUND ==============================
    // All sounds are synthesized in code (no asset files), written once to the
    // app cache as tiny WAV files and played through SoundPool.
    private inner class Sfx {
        private val sr = 22050
        private var pool: SoundPool? = null
        private val fireIds = IntArray(2)
        private val splitIds = IntArray(11)
        private val roundIds = IntArray(3)
        private var absorbId = 0
        private var bounceId = 0
        private var geigerId = 0
        private var humId = 0
        private var humStream = 0

        init {
            val appCtx = context.applicationContext
            Thread {
                try {
                    val p = SoundPool.Builder()
                        .setMaxStreams(10)
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .build()
                    val dir = File(appCtx.cacheDir, "chain_sfx_v1")
                    dir.mkdirs()
                    fun ld(name: String, buf: FloatArray): Int {
                        val f = File(dir, "$name.wav")
                        if (!f.exists()) writeWav(f, buf)
                        return p.load(f.absolutePath, 1)
                    }
                    for (i in 0 until 2) fireIds[i] = ld("fire$i", synthFire(i.toFloat()))
                    for (i in 0 until 11) splitIds[i] = ld("split$i", synthSplit(i + 1))
                    for (i in 0 until 3) roundIds[i] = ld("round$i", synthRound(i))
                    absorbId = ld("absorb", synthAbsorb())
                    bounceId = ld("bounce", synthTick(0.05f, 2600f, 0.05f))
                    geigerId = ld("geiger", synthTick(0.05f, 4500f, 0.01f))
                    humId = ld("hum", synthHum())
                    pool = p
                } catch (_: Throwable) {
                }
            }.start()
        }

        private fun play(id: Int, vol: Float) {
            if (muted || id <= 0) return
            try {
                pool?.play(id, vol, vol, 1, 0, 1f)
            } catch (_: Throwable) {
            }
        }

        fun fire(c: Float) = play(fireIds[if (c > 0.5f) 1 else 0], 0.9f)
        fun split(gen: Int) = play(splitIds[min(gen, 11) - 1], 0.9f)
        fun absorb() = play(absorbId, 0.8f)
        fun bounce() = play(bounceId, 0.5f)
        fun geiger() = play(geigerId, 0.4f)
        fun round(level: Int) = play(roundIds[level.coerceIn(0, 2)], 0.8f)

        fun humStart() {
            if (muted || humId <= 0 || humStream != 0) return
            try {
                humStream = pool?.play(humId, 0.25f, 0.25f, 1, -1, 1f) ?: 0
            } catch (_: Throwable) {
                humStream = 0
            }
        }

        fun humSet(c: Float) {
            if (humStream == 0) return
            try {
                pool?.setRate(humStream, (1f + c).coerceIn(0.5f, 2f))
            } catch (_: Throwable) {
            }
        }

        fun humStop() {
            if (humStream == 0) return
            try {
                pool?.stop(humStream)
            } catch (_: Throwable) {
            }
            humStream = 0
        }

        fun release() {
            humStop()
            try {
                pool?.release()
            } catch (_: Throwable) {
            }
            pool = null
        }

        // ---------- synthesis ----------
        private fun addTone(buf: FloatArray, startSec: Float, freq: Float, dur: Float, type: Int, vol: Float, to: Float) {
            val s0 = (startSec * sr).toInt()
            val n = (dur * sr).toInt()
            var phase = 0.0
            for (i in 0 until n) {
                val idx = s0 + i
                if (idx >= buf.size) break
                val t = i.toFloat() / sr
                val f = if (to > 0f) freq * (to / freq).pow(t / dur) else freq
                phase += f.toDouble() / sr
                val ph = (phase - floor(phase)).toFloat()
                val w = when (type) {
                    0 -> sin(ph * TAU)
                    1 -> if (ph < 0.25f) 4f * ph else if (ph < 0.75f) 2f - 4f * ph else 4f * ph - 4f
                    2 -> if (ph < 0.5f) 1f else -1f
                    else -> 2f * ph - 1f
                }
                val env = if (t < 0.008f) vol * (0.0001f / vol).pow(1f - t / 0.008f)
                else vol * (0.0001f / vol).pow((t - 0.008f) / max(0.001f, dur - 0.008f))
                buf[idx] += w * env
            }
        }

        private fun addTick(buf: FloatArray, startSec: Float, vol: Float, freq: Float, dur: Float) {
            val s0 = (startSec * sr).toInt()
            val n = (dur * sr).toInt()
            val w0 = 2.0 * PI * freq / sr
            val alpha = sin(w0) / (2.0 * 0.9)
            val a0 = 1.0 + alpha
            val b0 = alpha / a0
            val b2 = -alpha / a0
            val a1 = -2.0 * cos(w0) / a0
            val a2 = (1.0 - alpha) / a0
            var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0
            val rnd = Random(freq.toInt() + 7)
            for (i in 0 until n) {
                val idx = s0 + i
                if (idx >= buf.size) break
                val x = rnd.nextDouble() * 2.0 - 1.0
                val y = b0 * x + b2 * x2 - a1 * y1 - a2 * y2
                x2 = x1; x1 = x; y2 = y1; y1 = y
                val t = i.toFloat() / sr
                val env = vol * (0.0001f / vol).pow(t / dur)
                buf[idx] += (y * 2.2).toFloat() * env
            }
        }

        private fun synthFire(c: Float): FloatArray {
            val b = FloatArray((0.3f * sr).toInt())
            addTone(b, 0f, 520f + c * 200f, 0.16f, 0, 0.15f, 150f)
            addTick(b, 0f, 0.22f, 3200f, 0.035f)
            addTone(b, 0f, 90f, 0.25f, 0, 0.2f + c * 0.1f, 40f)
            return b
        }

        private fun synthSplit(gen: Int): FloatArray {
            val scale = intArrayOf(0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24)
            val f = 261.6f * 2f.pow(scale[min(gen - 1, scale.size - 1)] / 12f)
            val b = FloatArray((0.45f * sr).toInt())
            addTone(b, 0f, 150f, 0.28f, 0, 0.3f, 45f)
            addTick(b, 0f, 0.3f, 1800f, 0.12f)
            addTone(b, 0f, f, 0.4f, 1, 0.11f, 0f)
            return b
        }

        private fun synthAbsorb(): FloatArray {
            val b = FloatArray((0.2f * sr).toInt())
            addTick(b, 0f, 0.22f, 900f, 0.05f)
            addTone(b, 0f, 130f, 0.12f, 2, 0.035f, 70f)
            return b
        }

        private fun synthTick(dur: Float, freq: Float, vol: Float): FloatArray {
            val b = FloatArray(((dur + 0.03f) * sr).toInt())
            addTick(b, 0f, vol * 4f, freq, dur)
            return b
        }

        private fun synthRound(level: Int): FloatArray {
            val notes = when (level) {
                2 -> floatArrayOf(392f, 523f, 659f, 784f)
                1 -> floatArrayOf(392f, 523f)
                else -> floatArrayOf(262f)
            }
            val b = FloatArray(((notes.size * 0.09f + 0.4f) * sr).toInt())
            for (i in notes.indices) addTone(b, i * 0.09f, notes[i], 0.3f, 1, 0.1f, 0f)
            return b
        }

        private fun synthHum(): FloatArray {
            val n = (0.5f * sr).toInt()
            val b = FloatArray(n)
            val f = 110f
            var lp = 0f
            for (i in 0 until n) {
                val ph = ((i.toFloat() * f / sr) % 1f)
                val x = 2f * ph - 1f
                lp += 0.2f * (x - lp)
                b[i] = lp * 0.5f
            }
            return b
        }

        private fun writeWav(f: File, buf: FloatArray) {
            val n = buf.size
            val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
            bb.put("RIFF".toByteArray())
            bb.putInt(36 + n * 2)
            bb.put("WAVE".toByteArray())
            bb.put("fmt ".toByteArray())
            bb.putInt(16)
            bb.putShort(1)
            bb.putShort(1)
            bb.putInt(sr)
            bb.putInt(sr * 2)
            bb.putShort(2)
            bb.putShort(16)
            bb.put("data".toByteArray())
            bb.putInt(n * 2)
            for (i in 0 until n) {
                val v = (buf[i] * 0.7f).coerceIn(-1f, 1f)
                bb.putShort((v * 32767f).toInt().toShort())
            }
            FileOutputStream(f).use { it.write(bb.array()) }
        }
    }
}
