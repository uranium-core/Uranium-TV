# UraniumTV Home Interface Redesign & Navigation Restructure

Redesign the UraniumTV landing experience with the new high-fidelity cyber-reactor artwork, providing dedicated navigation paths for standalone viewing ("Watch Movies & Series") and synchronized social viewing ("Watch with Friends"), while preserving all core room creation, joining, and friends capabilities.

### User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during Phase 1:
> - **Top Bar Navigation**: Standard Material 3 top bar with a back arrow and screen title on both the blank "Watch Movies & Series" screen and the new "Watch with Friends" room lobby.
> - **Room History Relocation**: The profile avatar remains accessible on the new Home Screen; the Room History button is moved into the "Watch with Friends" room lobby.
> - **[MY COLLECTIONS] Action**: Active interactive touch target on the reactor frame that opens a placeholder "My Collections" screen.
> - **Watch with Friends Page Style**: Strict minimalist dark background with no background artwork (user will provide custom background art later), focusing purely on the functional room actions.

---

### 1. Overview & Core Concept

- **What It Does**: Replaces the previous 3-button room actions on the Home Screen with the new high-tech Uranium reactor visual frame featuring two primary action portals:
  1. **WATCH MOVIES & SERIES**: A new placeholder destination kept blank for future streaming catalogue integration.
  2. **WATCH WITH FRIENDS**: A dedicated room-collaboration lobby containing the room creation, room code entry, room joining, and friends management options with a clean background.
  3. **[MY COLLECTIONS]**: A secondary action portal opening a placeholder collections destination.
- **Target Audience**: Users of UraniumTV who want quick separation between solo browsing/streaming and co-watching synced sessions with friends.
- **Key Value**: Streamlines the first-launch user experience, declutters the landing view, and prepares the app for standalone movie/series discovery while preserving 100% of the room synchronization backend.

---

### 2. User Experience & Visual Design

#### Screen Flow Walkthrough
1. **Home Screen (`HomeScreen.kt`)**:
   - High-fidelity dark cybernetic reactor frame (`835x1884` aspect ratio, centered and responsive across phones, foldables, and tablets).
   - Top-right Profile Avatar button with cyan reactor pulse for opening user settings.
   - Core status readouts and rotating atomic animation overlay.
   - Interactive `[MY COLLECTIONS]` button positioned above the main action triggers.
   - **`WATCH MOVIES & SERIES`** primary glowing red reactor button.
   - **`WATCH WITH FRIENDS`** primary glowing red reactor button.
2. **Watch Movies & Series Screen (`WatchMoviesSeriesScreen.kt`)**:
   - Clean dark cinematic background (`#07090E`).
   - M3 `TopAppBar` with back arrow and title "Watch Movies & Series".
   - Minimal blank canvas prepared for future catalogue, genres, and media players.
3. **Watch with Friends Hub (`WatchWithFriendsScreen.kt`)**:
   - Clean dark background (`#07090E`, no background image, ready for future user artwork).
   - Top bar with back arrow, "Watch with Friends" title, and Room History shortcut icon in the action bar.
   - Core functional controls:
     - **Create Room** button: Instant 6-character room generation and Firebase RTDB setup.
     - **Room Code Input**: 6-character uppercase text field with letter spacing and clear action.
     - **Join Room** button: Active validation and immediate room launch.
     - **Friends** button: Direct navigation to the Friends list and presence view.
     - Active room invites & continue watching feed.
4. **My Collections Screen (`MyCollectionsScreen.kt`)**:
   - Clean dark cinematic placeholder with top bar back navigation.

#### Visual Identity & Theme
- **Background**: Deep void black (`#07090E` / `VoidBlack`) with subtle border glows.
- **Reactor Accents**: Ruby & Crimson core (`#FF1744` / `#FF5252`) matching the hardware panel art.
- **Typography**: Display font for titles and futuristic section heads, high-legibility sans-serif for inputs and buttons.
- **Touch Targets**: Minimum 48dp on all interactive buttons with Material bouncy ripple feedback.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dedicated Hub Screen vs Modal for "Watch with Friends"**
  - *Chosen Approach*: Full dedicated screen destination (`"watch_with_friends"`) in the Compose `NavHost`.
  - *Why*: Allows full responsiveness across all screen sizes (Android 10+ phones, foldables, tablets) without popup height constraints, and gives ample space for the room code input, buttons, and pending invitations.
  - *Alternative Considered*: Bottom sheet or dialog. Rejected because user requested a dedicated page and plans to add full background artwork later.
- **Decision 2: Room History Relocation**
  - *Chosen Approach*: Moved Room History icon to the TopAppBar actions of the "Watch with Friends" screen.
  - *Why*: Directly aligns with user decision and keeps the main landing view clean while keeping past rooms easily accessible right where rooms are created and joined.
- **Decision 3: Preserving Existing Room Logic & Backend Unchanged**
  - *Chosen Approach*: Reuse existing Firebase RTDB room generation, username sync, and navigation arguments verbatim.
  - *Why*: Guarantees zero regression in room sync, video controls, YouTube playback, or friends invites.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌─────────────────────────────────────────────────────────────┐
│                    HomeScreen (Landing)                     │
│  - New Reactor Background Artwork (Picsart_..._71ff714f)    │
│  - Top Profile Avatar button                                │
│  - [MY COLLECTIONS] touch target                            │
│  - [WATCH MOVIES & SERIES] button                           │
│  - [WATCH WITH FRIENDS] button                              │
└──────────────┬───────────────────────────────┬──────────────┘
               │                               │
               ▼                               ▼
┌──────────────────────────────┐ ┌────────────────────────────┐
│   WatchMoviesSeriesScreen    │ │   WatchWithFriendsScreen   │
│  - TopAppBar (Back, Title)   │ │  - TopAppBar (Back, Title, │
│  - Clean blank canvas        │ │    Room History icon)      │
│                              │ │  - Clean dark background   │
│                              │ │  - Create Room button      │
│                              │ │  - Room Code TextField     │
│                              │ │  - Join Room button        │
│                              │ │  - Friends button          │
│                              │ └──────────────┬─────────────┘
│                              │                │
└──────────────────────────────┘                ▼
                                 ┌────────────────────────────┐
                                 │ RoomScreen / FriendsScreen │
                                 │ (Existing unchanged logic) │
                                 └────────────────────────────┘
```

#### New Files & Modified Components
- **`app/src/main/res/drawable/home_reactor_v2.jpg`**: Copy uploaded image `Picsart_26-10-29_22-39-46-550_71ff714f.jpg` into app resources.
- **`app/src/main/java/com/example/WatchWithFriendsScreen.kt`**: New screen containing the room lobby actions (Create Room, Code Input, Join Room, Friends, History shortcut) on a clean dark background.
- **`app/src/main/java/com/example/WatchMoviesSeriesScreen.kt`**: New blank placeholder screen with standard TopAppBar.
- **`app/src/main/java/com/example/MyCollectionsScreen.kt`**: New blank placeholder screen with standard TopAppBar.
- **`app/src/main/java/com/example/HomeScreen.kt`**: Updated to render `home_reactor_v2.jpg` with interactive overlay zones for Collections, Watch Movies & Series, and Watch with Friends.
- **`app/src/main/java/com/example/MainActivity.kt`**: Add navigation destinations for `"watch_movies_series"`, `"watch_with_friends"`, and `"my_collections"`.
