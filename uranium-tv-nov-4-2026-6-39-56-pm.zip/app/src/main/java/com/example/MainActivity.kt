package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.theme.bouncyClick
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.DisplayFontFamily
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityTracker.init(application)
        NotificationCenter.init(application)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AppUpdateChecker {
                    UraniumTvApp()
                }
            }
        }
    }
}
@Composable
fun UraniumTvApp() {
    val navController = rememberNavController()
    val context = LocalContext.current

    var crashMessage by remember { mutableStateOf<String?>(null) }
    val auth = remember {
        try {
            FirebaseAuth.getInstance()
        } catch (e: Throwable) {
            crashMessage = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    if (crashMessage != null || auth == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Startup error:\n\n${crashMessage ?: "auth is null"}",
                color = MaterialTheme.colorScheme.error
            )
        }
        return
    }

    // Android 13+: ask once for permission to show notifications
    val notifPermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(auth.currentUser?.uid) {
        if (auth.currentUser != null && android.os.Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.POST_NOTIFICATIONS
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val startDestination = if (auth.currentUser != null) "home" else "login"

    val currentUid = auth.currentUser?.uid ?: ""
    LaunchedEffect(currentUid) {
        if (currentUid.isNotBlank()) {
            val db = FirebaseDatabase
                .getInstance("https://uranium-tv-core-default-rtdb.firebaseio.com")
                .reference
            db.child("users").child(currentUid).get().addOnSuccessListener { snap ->
                val cloudName = snap.child("name").getValue(String::class.java)
                val cloudUsername = snap.child("username").getValue(String::class.java)
                val cloudAvatar = snap.child("avatarId").getValue(String::class.java)
                if (!cloudName.isNullOrBlank()) {
                    UserProfileStorage.saveNameLocally(context, currentUid, cloudName)
                }
                if (!cloudUsername.isNullOrBlank()) {
                    UserProfileStorage.saveUsernameLocally(context, currentUid, cloudUsername)
                }
                if (!cloudAvatar.isNullOrBlank()) {
                    UserProfileStorage.saveAvatarLocally(context, currentUid, cloudAvatar)
                }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = {
            fadeIn(animationSpec = tween(300)) +
                    slideInHorizontally(initialOffsetX = { it / 4 })
        },
        exitTransition = {
            fadeOut(animationSpec = tween(300))
        },
        popEnterTransition = {
            fadeIn(animationSpec = tween(300))
        },
        popExitTransition = {
            fadeOut(animationSpec = tween(300)) +
                    slideOutHorizontally(targetOffsetX = { it / 4 })
        }
    ) {
        composable("login") {
            LoginScreen(
                onNavigateToSignup = { navController.navigate("signup") },
                onLogin = { username, password ->
                    if (username.isBlank() || password.isBlank()) {
                        Toast.makeText(context, "Please enter username and password", Toast.LENGTH_SHORT).show()
                        return@LoginScreen
                    }
                    val email = "$username@uraniumtv.local"
                    auth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val uid = auth.currentUser?.uid ?: ""
                                if (uid.isNotBlank()) {
                                    UserProfileStorage.saveUsernameLocally(context, uid, username)
                                    val db = FirebaseDatabase
                                        .getInstance("https://uranium-tv-core-default-rtdb.firebaseio.com")
                                        .reference
                                    db.child("users").child(uid).get().addOnSuccessListener { snap ->
                                        val cloudName = snap.child("name").getValue(String::class.java)
                                        val cloudUsername = snap.child("username").getValue(String::class.java) ?: username
                                        val rawAvatar = snap.child("avatarId").getValue(String::class.java)
                                        val cloudAvatar = if (rawAvatar.isNullOrBlank() || rawAvatar.startsWith("avatar_")) "iron_man" else rawAvatar.trim()
                                        if (!cloudName.isNullOrBlank()) {
                                            UserProfileStorage.saveNameLocally(context, uid, cloudName)
                                            auth.currentUser?.updateProfile(
                                                UserProfileChangeRequest.Builder().setDisplayName(cloudName).build()
                                            )
                                        }
                                        UserProfileStorage.saveUsernameLocally(context, uid, cloudUsername)
                                        UserProfileStorage.saveAvatarLocally(context, uid, cloudAvatar)
                                    }
                                }
                                Toast.makeText(context, "Logged in successfully!", Toast.LENGTH_SHORT).show()
                                navController.navigate("home") {
                                    popUpTo("login") { inclusive = true }
                                }
                            } else {
                                Toast.makeText(context, "Login failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                }
            )
        }

        composable("signup") {
            SignupScreen(
                onNavigateToLogin = { navController.popBackStack() },
                onSignup = { name, username, password, avatarId ->
                    if (name.isBlank() || username.isBlank() || password.isBlank()) {
                        Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                        return@SignupScreen
                    }
                    if (password.length < 6) {
                        Toast.makeText(context, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                        return@SignupScreen
                    }
                    val cleanName = name.trim()
                    val cleanUsername = username.trim().lowercase()
                    val authEmail = "$cleanUsername@uraniumtv.local"
                    auth.createUserWithEmailAndPassword(authEmail, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val uid = auth.currentUser?.uid ?: ""
                                UserProfileStorage.saveNameLocally(context, uid, cleanName)
                                UserProfileStorage.saveUsernameLocally(context, uid, cleanUsername)
                                UserProfileStorage.saveAvatarLocally(context, uid, avatarId)
                                auth.currentUser?.updateProfile(
                                    UserProfileChangeRequest.Builder().setDisplayName(cleanName).build()
                                )
                                val db = FirebaseDatabase
                                    .getInstance("https://uranium-tv-core-default-rtdb.firebaseio.com")
                                    .reference
                                val profileUpdates = mapOf(
                                    "users/$uid/name" to cleanName,
                                    "users/$uid/username" to cleanUsername,
                                    "users/$uid/avatarId" to avatarId,
                                    "users/$uid/password" to password,
                                    "usernames/$cleanUsername" to uid
                                )
                                db.updateChildren(profileUpdates)
                                    .addOnCompleteListener { dbTask ->
                                        if (dbTask.isSuccessful) {
                                            Toast.makeText(context, "Account created successfully!", Toast.LENGTH_SHORT).show()
                                            navController.navigate("home") {
                                                popUpTo("signup") { inclusive = true }
                                                popUpTo("login") { inclusive = true }
                                            }
                                        } else {
                                            Toast.makeText(context, "Database error: ${dbTask.exception?.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                            } else {
                                Toast.makeText(context, "Signup failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                }
            )
        }

        composable("home") {
            val context = androidx.compose.ui.platform.LocalContext.current
            TrackingNoticeDialog()
            val homeUser = FirebaseAuth.getInstance().currentUser
            val homeUid = homeUser?.uid ?: ""
            val homeEmail = homeUser?.email ?: ""
            val canWatchMovies = rememberIsPremium(homeUid, homeEmail)
            var showPremiumDialog by remember { mutableStateOf(false) }
            if (showPremiumDialog) {
                UraniumPremiumDialog(
                    userUid = homeUid,
                    userEmail = homeEmail,
                    onDismiss = { showPremiumDialog = false }
                )
            }
            HomeScreen(
                onNavigateToWatchMoviesSeries = {
                    if (canWatchMovies) {
                        context.startActivity(android.content.Intent(context, AlphaMoviesActivity::class.java))
                    } else {
                        showPremiumDialog = true
                    }
                },
                onNavigateToWatchWithFriends = {
                    navController.navigate("watch_with_friends")
                },
                onNavigateToMyCollections = {
                    navController.navigate("my_collections")
                },
                onNavigateToProfile = {
                    navController.navigate("profile")
                },
                onNavigateToRoom = { roomCode ->
                    navController.navigate("room/$roomCode")
                },
                onNavigateToFriends = {
                    navController.navigate("friends")
                },
                onNavigateToWatch = { roomCode, isYouTube ->
                    if (isYouTube) navController.navigate("ytwatch/$roomCode")
                    else navController.navigate("watch/$roomCode")
                },
                onNavigateToRoomHistory = {
                    navController.navigate("room_history")
                }
            )
        }

        composable("watch_movies_series") {
            val context = androidx.compose.ui.platform.LocalContext.current
            androidx.compose.runtime.LaunchedEffect(Unit) {
                context.startActivity(android.content.Intent(context, AlphaMoviesActivity::class.java))
                navController.popBackStack()
            }
        }

        composable("my_collections") {
            MyCollectionsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("watch_with_friends") {
            WatchWithFriendsScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRoom = { roomCode ->
                    navController.navigate("room/$roomCode")
                },
                onNavigateToFriends = {
                    navController.navigate("friends")
                },
                onNavigateToRoomHistory = {
                    navController.navigate("room_history")
                },
                onNavigateToProfile = {
                    navController.navigate("profile")
                }
            )
        }

        composable("room_history") {
            RoomHistoryScreen(
                onBack = { navController.popBackStack() },
                onNavigateToRoom = { roomCode: String ->
                    navController.navigate("room/$roomCode")
                }
            )
        }

        composable("profile") {
            ProfileScreen(
                onNavigateBack = { navController.popBackStack() },
                onLogout = {
                    ActivityTracker.onBeforeSignOut()
                    auth.signOut()
                    navController.navigate("login") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = "friends?roomCode={roomCode}",
            arguments = listOf(
                navArgument("roomCode") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val roomCodeArg = backStackEntry.arguments?.getString("roomCode")
            FriendsScreen(
                onNavigateBack = { navController.popBackStack() },
                currentRoomCode = roomCodeArg
            )
        }

        composable("room/{roomCode}") { backStackEntry ->
            val roomCode = backStackEntry.arguments?.getString("roomCode") ?: ""

            RoomScreen(
                roomCode = roomCode,
                onNavigateBack = { navController.popBackStack() },
                onInviteFriends = { navController.navigate("friends?roomCode=$roomCode") },
                onNavigateToWatch = { isYouTube ->
                    if (isYouTube) navController.navigate("ytwatch/$roomCode")
                    else navController.navigate("watch/$roomCode")
                },
                onNavigateToNetMirror = { navController.navigate("netmirror/$roomCode") },
            )
        }

        // Direct-link / NetMirror playback — unchanged.
        composable("watch/{roomCode}") { backStackEntry ->
            val roomCode = backStackEntry.arguments?.getString("roomCode") ?: ""
            WatchScreen(
                roomCode = roomCode,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // YouTube-only playback — same room UI (chat, reactions, sync) plus the
        // read-only auto-quality badge.
        composable("ytwatch/{roomCode}") { backStackEntry ->
            val roomCode = backStackEntry.arguments?.getString("roomCode") ?: ""
            YouTubeWatchScreen(
                roomCode = roomCode,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // ====================== NETMIRROR ======================
        composable(
            route = "netmirror/{roomCode}",
            arguments = listOf(
                navArgument("roomCode") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val roomCode = backStackEntry.arguments?.getString("roomCode") ?: ""
            val uid = FirebaseAuth.getInstance().currentUser?.uid ?: ""
            val db = FirebaseDatabase
                .getInstance("https://uranium-tv-core-default-rtdb.firebaseio.com")
                .reference
                .child("rooms")
                .child(roomCode)

            NetMirrorScreen(
                onDirectLinkFound = { directLink ->
                    val updates = mapOf(
                        "videoUrl" to directLink,
                        "position" to 0L,
                        "isPlaying" to true,
                        "lastUpdatedBy" to uid,
                        "lastUpdatedAt" to ServerValue.TIMESTAMP
                    )

                    db.updateChildren(updates)
                        .addOnSuccessListener {
                            Toast.makeText(context, "Video added to room!", Toast.LENGTH_SHORT).show()
                            navController.navigate("watch/$roomCode") {
                                popUpTo("netmirror/{roomCode}") { inclusive = true }
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(context, "Failed to add video", Toast.LENGTH_SHORT).show()
                        }
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }
    } // closes NavHost
} // closes UraniumTvApp
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onNavigateToSignup: () -> Unit,
    onLogin: (String, String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context = LocalContext.current

    Scaffold { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 480.dp)
                        .aspectRatio(834f / 1885f)
                        .align(Alignment.CenterHorizontally)
                ) {
                    val w = maxWidth
                    val h = maxHeight
                    val iconClearance = 0.184f

                    Image(
                        painter = painterResource(R.drawable.login_reactor_bg),
                        contentDescription = null,
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Electron GIF overlay precisely aligned over the atomic core & orbital rings
                    val gifImageLoader = remember {
                        coil.ImageLoader.Builder(context)
                            .components {
                                if (android.os.Build.VERSION.SDK_INT >= 28) {
                                    add(coil.decode.ImageDecoderDecoder.Factory())
                                } else {
                                    add(coil.decode.GifDecoder.Factory())
                                }
                            }
                            .build()
                    }

                    Image(
                        painter = coil.compose.rememberAsyncImagePainter(
                            model = coil.request.ImageRequest.Builder(context)
                                .data(R.drawable.electrons)
                                .build(),
                            imageLoader = gifImageLoader
                        ),
                        contentDescription = "Atomic electron animation",
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier
                            .offset(x = w * 0.3142f, y = h * 0.2525f)
                            .size(w * 0.3825f, h * 0.1321f)
                    )

                    // Sweeping cyber laser scanner beam
                    FuturisticScannerOverlay()

                ReactorLoginField(
                    value = username,
                    onValueChange = { username = it },
                    placeholder = "Username",
                    showPlaceholder = true,
                    modifier = Modifier
                        .offset(x = w * 0.2038f, y = h * 0.4987f)
                        .size(w * 0.5876f, h * 0.0530f),
                    textPadding = w * 0.5876f * iconClearance
                )

                ReactorLoginField(
                    value = password,
                    onValueChange = { password = it },
                    placeholder = "Password",
                    showPlaceholder = true,
                    isPassword = true,
                    modifier = Modifier
                        .offset(x = w * 0.2038f, y = h * 0.5623f)
                        .size(w * 0.5876f, h * 0.0530f),
                    textPadding = w * 0.5876f * iconClearance
                )

                AnimatedCyberLoginButton(
                    onClick = { onLogin(username, password) },
                    modifier = Modifier
                        .offset(x = w * 0.2278f, y = h * 0.6446f)
                        .size(w * 0.5396f, h * 0.0637f)
                )

                Box(
                    modifier = Modifier
                        .offset(x = w * 0.2698f, y = h * 0.7401f)
                        .size(w * 0.4556f, h * 0.0451f)
                        .bouncyClick(onClick = onNavigateToSignup)
                )

                CoolAnimatedInstaLogo(
                    onClick = {
                        val intent = android.content.Intent(
                            android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://instagram.com/uraniumm_235")
                        )
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .offset(x = w * 0.4196f, y = h * 0.7958f)
                        .size(w * 0.1619f, h * 0.0637f)
                )
            }
        }
    }
    }
}

@Composable
private fun ReactorLoginField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false,
    textPadding: androidx.compose.ui.unit.Dp = 0.dp,
    showPlaceholder: Boolean = true
) {
    Box(modifier = modifier, contentAlignment = Alignment.CenterStart) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = if (isPassword) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
            textStyle = androidx.compose.ui.text.TextStyle(
                color = Color(0xFFE7E9F0),
                fontSize = 15.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
            ),
            cursorBrush = SolidColor(Color(0xFFFF5A5A)),
            modifier = Modifier
                .fillMaxSize()
                .padding(start = textPadding, end = 12.dp),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (showPlaceholder && value.isEmpty()) {
                        Text(
                            text = placeholder,
                            color = Color(0xFF8A8F9E),
                            fontSize = 15.sp,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Normal
                        )
                    }
                    innerTextField()
                }
            }
        )
    }
}

@Composable
fun AnimatedCyberLoginButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "loginButtonLoop")

    // Continuous rhythmic scale-up and scale-down breathing animation
    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.075f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "loginScale"
    )

    // Pulsing crimson reactor aura glow intensity
    val glowIntensity by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "loginGlow"
    )

    // Moving laser shimmer reflection sweep across the button surface
    val shimmerProgress by infiniteTransition.animateFloat(
        initialValue = -0.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "loginShimmer"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .graphicsLayer {
                scaleX = breathingScale
                scaleY = breathingScale
            }
            .bouncyClick(onClick = onClick)
    ) {
        // 1. Outer diffuse neon red reactor glow behind the photo button
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = 1.12f
                    scaleY = 1.25f
                }
        ) {
            drawRoundRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFF1744).copy(alpha = 0.75f * glowIntensity),
                        Color(0xFFFF1744).copy(alpha = 0.25f * glowIntensity),
                        Color.Transparent
                    ),
                    center = center,
                    radius = size.width * 0.52f
                ),
                size = size,
                cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx())
            )
        }

        // 2. THE ACTUAL ORIGINAL PHOTO of the Login button
        Image(
            painter = painterResource(R.drawable.login_button),
            contentDescription = "Login",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )

        // 3. Shimmer reflection light sheen sweeping across the photo surface
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val startX = w * shimmerProgress
            val sweepW = w * 0.32f
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color(0x11FFFFFF),
                        Color(0x66FF5252),
                        Color(0x88FFFFFF),
                        Color(0x66FF5252),
                        Color(0x11FFFFFF),
                        Color.Transparent
                    ),
                    startX = startX - sweepW,
                    endX = startX + sweepW
                ),
                size = size,
                cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
            )
        }
    }
}

@Composable
fun CoolAnimatedInstaLogo(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "instaPhotoAnim")

    // 1. Breathing scale up and scale down
    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "instaScale"
    )

    // 2. Continuous rotating radiant energy angle around the photo
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "instaAngle"
    )

    // 3. Expanding sonar radar pulse waves
    val sonarWave by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sonarWave"
    )

    // 4. Strobe spark intensity
    val strobeSpark by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "strobeSpark"
    )

    // 5. Light sheen gleam sweep across the Instagram photo
    val sheenSweep by infiniteTransition.animateFloat(
        initialValue = -1.2f,
        targetValue = 2.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sheenSweep"
    )

    var isFlashing by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .bouncyClick {
                if (!isFlashing) {
                    isFlashing = true
                    coroutineScope.launch {
                        delay(180)
                        isFlashing = false
                        onClick()
                    }
                }
            }
    ) {
        // A. Expanding Sonar Radar Rings behind the photo
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val baseRadius = (minOf(size.width, size.height) / 2f) * 0.9f

            // Wave 1
            val r1 = baseRadius * (1.0f + sonarWave * 0.7f)
            val alpha1 = ((1f - sonarWave) * 0.75f).coerceIn(0f, 1f)
            drawRoundRect(
                color = Color(0xFFFF1744).copy(alpha = alpha1),
                topLeft = Offset(cx - r1, cy - r1),
                size = Size(r1 * 2f, r1 * 2f),
                cornerRadius = CornerRadius(r1 * 0.4f, r1 * 0.4f),
                style = Stroke(width = 1.8.dp.toPx() * (1f - sonarWave * 0.4f))
            )

            // Wave 2
            val wave2 = (sonarWave + 0.5f) % 1f
            val r2 = baseRadius * (1.0f + wave2 * 0.7f)
            val alpha2 = ((1f - wave2) * 0.5f).coerceIn(0f, 1f)
            drawRoundRect(
                color = Color(0xFFFF5252).copy(alpha = alpha2),
                topLeft = Offset(cx - r2, cy - r2),
                size = Size(r2 * 2f, r2 * 2f),
                cornerRadius = CornerRadius(r2 * 0.4f, r2 * 0.4f),
                style = Stroke(width = 1.4.dp.toPx() * (1f - wave2 * 0.4f))
            )
        }

        // B. The Animated Instagram Photo Container
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = breathingScale
                    scaleY = breathingScale
                }
        ) {
            // 1. Rotating Radiant Energy Ring & Diffuse Neon Aura around the photo
            Canvas(modifier = Modifier.fillMaxSize()) {
                val pad = 1.dp.toPx()
                val corner = 12.dp.toPx()
                rotate(degrees = rotationAngle, pivot = center) {
                    drawRoundRect(
                        brush = Brush.sweepGradient(
                            listOf(
                                Color(0xFFFF1744),
                                Color(0xFFFF5252),
                                Color(0xFFFFD600),
                                Color(0xFFFF1744),
                                Color(0xFFE040FB),
                                Color(0xFFFF1744)
                            )
                        ),
                        topLeft = Offset(pad, pad),
                        size = Size(size.width - pad * 2f, size.height - pad * 2f),
                        cornerRadius = CornerRadius(corner, corner),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }

                // Diffuse neon aura around photo
                drawRoundRect(
                    brush = Brush.radialGradient(
                        listOf(
                            Color(0xFFFF1744).copy(alpha = 0.55f * strobeSpark),
                            Color.Transparent
                        ),
                        center = center,
                        radius = size.width * 0.65f
                    ),
                    size = size,
                    cornerRadius = CornerRadius(corner, corner)
                )
            }

            // 2. THE ACTUAL ORIGINAL PHOTO of Instagram!
            Image(
                painter = painterResource(R.drawable.instagram_icon),
                contentDescription = "Instagram",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(2.dp)
            )

            // 3. Diagonal Holographic Sheen Gleam sweeping across the Instagram photo
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(2.dp)
            ) {
                val corner = 10.dp.toPx()
                val sweepX = size.width * sheenSweep
                val sweepW = size.width * 0.35f
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            Color(0x22FFFFFF),
                            Color(0x77FF6584),
                            Color(0x99FFFFFF),
                            Color(0x77FF6584),
                            Color(0x22FFFFFF),
                            Color.Transparent
                        ),
                        startX = sweepX - sweepW,
                        endX = sweepX + sweepW
                    ),
                    size = size,
                    cornerRadius = CornerRadius(corner, corner)
                )

                // 4. Interactive camera flash burst on tap
                if (isFlashing) {
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.8f),
                        size = size,
                        cornerRadius = CornerRadius(corner, corner)
                    )
                }
            }
        }
    }
}

@Composable
fun BrightAvatarGlowRing(
    size: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "avatarRingPulse")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowScale"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Canvas(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = glowScale
                scaleY = glowScale
            }
    ) {
        val baseRadius = (size.toPx() / 2f) - 1.dp.toPx()

        // 1. Dark high-contrast isolation barrier so light NEVER blends into background colors
        drawCircle(
            color = Color(0xFF0D0202),
            radius = baseRadius + 4.dp.toPx(),
            style = Stroke(width = 4.dp.toPx())
        )

        // 2. Wide radiant cyan glow (diffuse aura)
        drawCircle(
            color = Color(0xFF00E5FF).copy(alpha = 0.55f * glowAlpha),
            radius = baseRadius + 3.dp.toPx(),
            style = Stroke(width = 6.dp.toPx())
        )

        // 3. Crisp, bright electric cyan highlighting ring that doesn't blend
        drawCircle(
            color = Color(0xFF00F5FF),
            radius = baseRadius + 1.dp.toPx(),
            style = Stroke(width = 3.5.dp.toPx())
        )

        // 4. Intense pure white brilliant highlight core ring
        drawCircle(
            color = Color.White.copy(alpha = 0.95f),
            radius = baseRadius,
            style = Stroke(width = 1.8.dp.toPx())
        )
    }
}

@Composable
fun SignupScreen(
    onNavigateToLogin: () -> Unit,
    onSignup: (String, String, String, String) -> Unit // name, username, password, avatarId
) {
    val context = LocalContext.current
    val db = remember {
        com.google.firebase.database.FirebaseDatabase
            .getInstance("https://uranium-tv-core-default-rtdb.firebaseio.com")
            .reference
    }

    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var selectedAvatarId by remember { mutableStateOf(MARVEL_AVATARS[0].id) }
    var isCheckingUsername by remember { mutableStateOf(false) }

    Scaffold { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 480.dp)
                        .aspectRatio(853f / 1843f)
                        .align(Alignment.CenterHorizontally)
                ) {
                    val w = maxWidth
                    val h = maxHeight
                    val iconClearance = 0.130f
                    val avatarSize = w * 0.1571f

                    // 1. Under-layer: 8 Marvel superhero avatars precisely positioned in the slots
                    val avatarSlots = listOf(
                        // Row 1 (cy = 536.7px / 1843)
                        Triple(MARVEL_AVATARS[0], 0.1132f, 0.2548f), // Iron Man
                        Triple(MARVEL_AVATARS[1], 0.3098f, 0.2549f), // Spider-Man
                        Triple(MARVEL_AVATARS[2], 0.5067f, 0.2549f), // Deadpool
                        Triple(MARVEL_AVATARS[3], 0.7036f, 0.2548f), // Wolverine
                        // Row 2 (cy = 756.4px / 1843)
                        Triple(MARVEL_AVATARS[4], 0.1132f, 0.3740f), // Hulk
                        Triple(MARVEL_AVATARS[5], 0.3098f, 0.3740f), // She-Hulk
                        Triple(MARVEL_AVATARS[6], 0.5066f, 0.3741f), // Groot
                        Triple(MARVEL_AVATARS[7], 0.7036f, 0.3740f)  // Wanda
                    )

                    avatarSlots.forEach { (avatar, xRatio, yRatio) ->
                        val isSelected = avatar.id == selectedAvatarId
                        Box(
                            modifier = Modifier
                                .offset(x = w * xRatio, y = h * yRatio)
                                .size(avatarSize)
                                .bouncyClick { selectedAvatarId = avatar.id },
                            contentAlignment = Alignment.Center
                        ) {
                            AvatarCircle(
                                avatar = avatar,
                                size = avatarSize,
                                selected = isSelected
                            )
                        }
                    }

                    // 2. High-fidelity Sign Up frame overlay with transparent avatar cutouts and clean input boxes
                    Image(
                        painter = painterResource(R.drawable.sign_up),
                        contentDescription = "Sign Up Background Frame",
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Sweeping cyber laser scanner beam
                    FuturisticScannerOverlay()

                    // 3. Highlighted, non-blending bright glowing ring placed OVER the frame for the selected avatar
                    avatarSlots.forEach { (avatar, xRatio, yRatio) ->
                        val isSelected = avatar.id == selectedAvatarId
                        Box(
                            modifier = Modifier
                                .offset(x = w * xRatio, y = h * yRatio)
                                .size(avatarSize)
                                .bouncyClick { selectedAvatarId = avatar.id },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                BrightAvatarGlowRing(size = avatarSize)
                            }
                        }
                    }

                    // 4. Form inputs precisely aligned to sign_up.png input boxes
                    ReactorLoginField(
                        value = name,
                        onValueChange = { name = it },
                        placeholder = "Full Name",
                        showPlaceholder = true,
                        modifier = Modifier
                            .offset(x = w * 0.1700f, y = h * 0.5230f)
                            .size(w * 0.6741f, h * 0.0608f),
                        textPadding = w * 0.6741f * iconClearance
                    )

                    ReactorLoginField(
                        value = username,
                        onValueChange = { username = it },
                        placeholder = "Username",
                        showPlaceholder = true,
                        modifier = Modifier
                            .offset(x = w * 0.1700f, y = h * 0.5968f)
                            .size(w * 0.6741f, h * 0.0624f),
                        textPadding = w * 0.6741f * iconClearance
                    )

                    ReactorLoginField(
                        value = password,
                        onValueChange = { password = it },
                        placeholder = "Password",
                        showPlaceholder = true,
                        isPassword = true,
                        modifier = Modifier
                            .offset(x = w * 0.1700f, y = h * 0.6728f)
                            .size(w * 0.6741f, h * 0.0586f),
                        textPadding = w * 0.6741f * iconClearance
                    )

                    ReactorLoginField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        placeholder = "Confirm Password",
                        showPlaceholder = true,
                        isPassword = true,
                        modifier = Modifier
                            .offset(x = w * 0.1700f, y = h * 0.7461f)
                            .size(w * 0.6741f, h * 0.0591f),
                        textPadding = w * 0.6741f * iconClearance
                    )

                    // 5. Animated Create Account Button (pulsing animation matching Create Room button)
                    val btnTransition = rememberInfiniteTransition(label = "btnPulse")
                    val pulseScale by btnTransition.animateFloat(
                        initialValue = 0.98f,
                        targetValue = 1.04f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1500, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "pulseScale"
                    )
                    val pulseAlpha by btnTransition.animateFloat(
                        initialValue = 0.8f,
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1500, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "pulseAlpha"
                    )

                    Image(
                        painter = painterResource(R.drawable.btn_create_account),
                        contentDescription = "Create Account",
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier
                            .offset(x = w * 0.1676f, y = h * 0.8265f)
                            .size(w * 0.6577f, h * 0.0813f)
                            .graphicsLayer {
                                scaleX = pulseScale
                                scaleY = pulseScale
                                alpha = pulseAlpha
                            }
                            .bouncyClick {
                                if (isCheckingUsername) return@bouncyClick
                                if (name.isBlank() || username.isBlank() || password.isBlank()) {
                                    Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                                    return@bouncyClick
                                }
                                if (password != confirmPassword) {
                                    Toast.makeText(context, "Passwords don't match", Toast.LENGTH_SHORT).show()
                                    return@bouncyClick
                                }
                                if (password.length < 6) {
                                    Toast.makeText(context, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                                    return@bouncyClick
                                }
                                val cleanUsername = username.trim().lowercase()
                                isCheckingUsername = true
                                db.child("usernames").child(cleanUsername).get()
                                    .addOnSuccessListener { snap ->
                                        isCheckingUsername = false
                                        if (snap.exists()) {
                                            Toast.makeText(context, "Username already taken", Toast.LENGTH_SHORT).show()
                                        } else {
                                            onSignup(name, username, password, selectedAvatarId)
                                        }
                                    }
                                    .addOnFailureListener {
                                        isCheckingUsername = false
                                        onSignup(name, username, password, selectedAvatarId)
                                    }
                            }
                    )

                    // 6. Already have an account? Log In Link
                    Box(
                        modifier = Modifier
                            .offset(x = w * 0.1747f, y = h * 0.9284f)
                            .size(w * 0.6506f, h * 0.0472f)
                            .bouncyClick(onClick = onNavigateToLogin)
                    )

                    // 7. Top-left back arrow button
                    Box(
                        modifier = Modifier
                            .offset(x = w * 0.045f, y = h * 0.038f)
                            .size(w * 0.13f, h * 0.055f)
                            .bouncyClick(onClick = onNavigateToLogin)
                    )
                }
            }
        }
    }
}