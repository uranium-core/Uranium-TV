@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class
)

package com.example

import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import com.example.ui.theme.bouncyClick
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.rememberScrollState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.VoidBlack
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// Parameter profile for an individual equalizer bar to ensure independent, organic live-data animation
private data class BarDynamics(
    val base: Float,
    val speed1: Float,
    val speed2: Float,
    val phase1: Float,
    val phase2: Float,
    val amp1: Float,
    val amp2: Float
)

// Precomputed 18 independent bar profiles for the Red Card yellow equalizer graph
private val EQUALIZER_PROFILES = listOf(
    BarDynamics(base = 0.35f, speed1 = 1.3f, speed2 = 2.1f, phase1 = 0.4f, phase2 = 1.2f, amp1 = 0.18f, amp2 = 0.10f),
    BarDynamics(base = 0.52f, speed1 = 3.6f, speed2 = 5.2f, phase1 = 1.1f, phase2 = 2.8f, amp1 = 0.28f, amp2 = 0.14f),
    BarDynamics(base = 0.68f, speed1 = 2.4f, speed2 = 4.1f, phase1 = 2.3f, phase2 = 0.5f, amp1 = 0.22f, amp2 = 0.12f),
    BarDynamics(base = 0.44f, speed1 = 5.1f, speed2 = 7.4f, phase1 = 0.8f, phase2 = 3.1f, amp1 = 0.30f, amp2 = 0.16f),
    BarDynamics(base = 0.75f, speed1 = 1.8f, speed2 = 2.9f, phase1 = 1.9f, phase2 = 4.2f, amp1 = 0.16f, amp2 = 0.08f),
    BarDynamics(base = 0.58f, speed1 = 4.4f, speed2 = 6.2f, phase1 = 3.2f, phase2 = 1.6f, amp1 = 0.26f, amp2 = 0.15f),
    BarDynamics(base = 0.40f, speed1 = 1.5f, speed2 = 2.5f, phase1 = 2.1f, phase2 = 5.0f, amp1 = 0.15f, amp2 = 0.09f),
    BarDynamics(base = 0.62f, speed1 = 3.9f, speed2 = 5.8f, phase1 = 0.2f, phase2 = 2.2f, amp1 = 0.25f, amp2 = 0.13f),
    BarDynamics(base = 0.72f, speed1 = 2.1f, speed2 = 3.4f, phase1 = 1.5f, phase2 = 0.9f, amp1 = 0.20f, amp2 = 0.10f),
    BarDynamics(base = 0.48f, speed1 = 4.8f, speed2 = 6.9f, phase1 = 2.7f, phase2 = 3.8f, amp1 = 0.28f, amp2 = 0.16f),
    BarDynamics(base = 0.80f, speed1 = 1.2f, speed2 = 2.0f, phase1 = 0.9f, phase2 = 1.8f, amp1 = 0.14f, amp2 = 0.06f),
    BarDynamics(base = 0.55f, speed1 = 3.3f, speed2 = 4.9f, phase1 = 3.5f, phase2 = 0.4f, amp1 = 0.24f, amp2 = 0.12f),
    BarDynamics(base = 0.38f, speed1 = 5.4f, speed2 = 7.8f, phase1 = 1.4f, phase2 = 2.6f, amp1 = 0.26f, amp2 = 0.14f),
    BarDynamics(base = 0.45f, speed1 = 2.0f, speed2 = 3.1f, phase1 = 2.8f, phase2 = 4.5f, amp1 = 0.18f, amp2 = 0.10f),
    BarDynamics(base = 0.32f, speed1 = 1.6f, speed2 = 2.7f, phase1 = 0.5f, phase2 = 1.3f, amp1 = 0.15f, amp2 = 0.08f),
    BarDynamics(base = 0.30f, speed1 = 3.8f, speed2 = 5.5f, phase1 = 3.1f, phase2 = 0.7f, amp1 = 0.18f, amp2 = 0.11f),
    BarDynamics(base = 0.28f, speed1 = 2.2f, speed2 = 3.7f, phase1 = 1.7f, phase2 = 2.9f, amp1 = 0.14f, amp2 = 0.08f),
    BarDynamics(base = 0.24f, speed1 = 1.4f, speed2 = 2.3f, phase1 = 0.6f, phase2 = 3.4f, amp1 = 0.12f, amp2 = 0.07f)
)

/**
 * WatchWithFriendsScreen
 * Exact visual match to Reference Image 3 (Master Design Reference),
 * with extracted original button graphics animated with subtle scale breathing (1.0 -> 1.035 -> 1.0),
 * and live-data mathematical simulations inside the information cards (Reference Image 2).
 */
@Composable
fun WatchWithFriendsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToRoom: (String) -> Unit,
    onNavigateToFriends: () -> Unit,
    onNavigateToRoomHistory: () -> Unit,
    onNavigateToProfile: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val auth = remember { FirebaseAuth.getInstance() }
    val uid = auth.currentUser?.uid ?: ""
    val db = remember { FirebaseDatabase.getInstance("https://uranium-tv-core-default-rtdb.firebaseio.com").reference }

    val cachedAvatar = remember(uid) { UserProfileStorage.getCachedAvatar(context, uid) }
    var myAvatarId by remember(uid) { mutableStateOf(cachedAvatar) }

    var joinRoomCode by remember { mutableStateOf("") }
    var isCreating by remember { mutableStateOf(false) }
    var isJoining by remember { mutableStateOf(false) }

    // Sync avatar from Firebase Realtime Database
    DisposableEffect(uid) {
        if (uid.isEmpty()) return@DisposableEffect onDispose {}
        val avatarRef = db.child("users").child(uid).child("avatarId")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val raw = snapshot.getValue(String::class.java)
                val clean = if (raw.isNullOrBlank() || raw.startsWith("avatar_")) "iron_man" else raw.trim()
                myAvatarId = clean
                UserProfileStorage.saveAvatarLocally(context, uid, clean)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        avatarRef.addValueEventListener(listener)
        onDispose { avatarRef.removeEventListener(listener) }
    }

    fun handleCreateRoom() {
        if (isCreating) return
        isCreating = true
        val allowedChars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val roomCode = (1..6).map { allowedChars.random() }.joinToString("")

        val roomData = mapOf(
            "videoUrl" to "",
            "isPlaying" to false,
            "position" to 0L,
            "lastUpdatedBy" to uid,
            "lastUpdatedAt" to ServerValue.TIMESTAMP,
            "hostUid" to uid,
            "controlsUnlocked" to false,
            "vibe" to com.example.ui.theme.RoomVibe.Default.name
        )

        db.child("rooms").child(roomCode).setValue(roomData)
            .addOnSuccessListener {
                isCreating = false
                onNavigateToRoom(roomCode)
            }
            .addOnFailureListener { exception ->
                isCreating = false
                Toast.makeText(context, "Failed: ${exception.message}", Toast.LENGTH_LONG).show()
            }
    }

    fun handleJoinRoom() {
        val cleanCode = joinRoomCode.trim().uppercase()
        if (cleanCode.length != 6) {
            Toast.makeText(context, "Please enter a 6-digit room code", Toast.LENGTH_SHORT).show()
            return
        }
        if (isJoining) return
        isJoining = true
        focusManager.clearFocus()
        db.child("rooms").child(cleanCode).get()
            .addOnSuccessListener { snapshot ->
                isJoining = false
                if (snapshot.exists()) {
                    onNavigateToRoom(cleanCode)
                } else {
                    Toast.makeText(context, "Room not found", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                isJoining = false
                Toast.makeText(context, "Error connecting to room", Toast.LENGTH_SHORT).show()
            }
    }

    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val isImeVisible = WindowInsets.isImeVisible

    // Gently scroll code input above keyboard when soft keyboard appears without pushing CREATE ROOM offscreen
    LaunchedEffect(isImeVisible) {
        if (isImeVisible) {
            delay(100)
            val gentleScroll = (scrollState.maxValue * 0.36f).toInt()
            scrollState.animateScrollTo(gentleScroll)
        } else {
            scrollState.animateScrollTo(0)
        }
    }

    // Infinite transitions for active real-time animations matching HomeScreen and reference
    val infiniteTransition = rememberInfiniteTransition(label = "watchFriendsAnimations")

    // Dynamic zoom-in, scale-up and scale-down animation matching HomeScreen options
    val buttonZoomScale by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "buttonZoomScale"
    )
    val buttonPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "buttonPulseAlpha"
    )

    // Normalized, steady animation clocks for organic graph movements
    val graphPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "graphPhase"
    )

    val waveScroll by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveScroll"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(VoidBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Master canvas maintaining the exact 834 x 1885 portrait aspect ratio
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 520.dp)
                    .aspectRatio(834f / 1885f)
            ) {
                val w = maxWidth
                val h = maxHeight

                // 1. MASTER BACKGROUND (REFERENCE IMAGE 3) - Kept 100% pristine and unmodified
                Image(
                    painter = painterResource(R.drawable.watch_friends_reactor_bg),
                    contentDescription = "Uranium TV Master Background",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )

                // 2. BACK BUTTON (Minimal, non-intrusive HUD icon at top left)
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .offset(x = w * 0.035f, y = h * 0.040f)
                        .size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 3. TOP AVATAR ICON on top of the radiation hazard symbol at top right
                val avatarContainerSize = w * 0.138f
                RotatingBlinkingAvatar(
                    avatarId = myAvatarId,
                    size = avatarContainerSize,
                    onClick = { onNavigateToProfile?.invoke() },
                    modifier = Modifier.offset(
                        x = w * 0.7832f - (avatarContainerSize / 2),
                        y = h * 0.1128f - (avatarContainerSize / 2)
                    )
                )

                // =========================================================================
                // RED INFORMATION CARD (LEFT) - LIVE DATA ANIMATIONS (REFERENCE IMAGE 2)
                // Strictly bounded inside the card's inner glass (width 128px, x: 250..378)
                // =========================================================================

                // A. Yellow Vertical Bar Graph (18 individual bars with active math animation)
                // Positioned safely below "ROOM: PX-5861" divider line with generous vertical clearance
                Box(
                    modifier = Modifier
                        .offset(x = w * 0.29976f, y = h * 0.27800f)
                        .size(w * 0.15348f, h * 0.03183f)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val numBars = EQUALIZER_PROFILES.size
                        val totalW = size.width
                        val maxH = size.height
                        val barSpacing = 1.2.dp.toPx()
                        val barWidth = (totalW - (numBars - 1) * barSpacing) / numBars
                        val yellowColor = Color(0xFFFFB800)

                        for (i in 0 until numBars) {
                            val prof = EQUALIZER_PROFILES[i]
                            // Normalized, steady harmonic equalizer motion at organic telemetry speeds
                            val h1 = sin(graphPhase * (prof.speed1 * 0.35f) + prof.phase1) * prof.amp1
                            val h2 = cos(graphPhase * (prof.speed2 * 0.25f) + prof.phase2) * prof.amp2
                            // Capped at 0.82f to ensure bars never touch or overlap the room header line
                            val heightFrac = (prof.base + h1 + h2).coerceIn(0.12f, 0.82f)

                            val barHeight = maxH * heightFrac
                            val xPos = i * (barWidth + barSpacing)
                            val yTop = maxH - barHeight

                            // Crisp solid golden-yellow bar matching Reference Image 2
                            drawRect(
                                color = yellowColor,
                                topLeft = Offset(xPos, yTop),
                                size = Size(barWidth, barHeight)
                            )
                        }
                    }
                }

                // B & C. Yellow & Cyan Horizontal Progress Bars (below "DATA: 521100")
                Box(
                    modifier = Modifier
                        .offset(x = w * 0.29976f, y = h * 0.33209f)
                        .size(w * 0.15348f, h * 0.02865f)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // B. Yellow Horizontal Progress Bar (Smooth normalized live buffer animation)
                        val yellowProgress = (0.58f + 0.20f * sin(graphPhase * 0.8f)).coerceIn(0.18f, 0.94f)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ONLINE",
                                color = Color(0xFFFFB800),
                                fontSize = 6.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(30.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Canvas(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.5.dp)
                            ) {
                                val wBar = size.width
                                val hBar = size.height
                                drawRect(
                                    color = Color(0xFF241D10),
                                    topLeft = Offset.Zero,
                                    size = Size(wBar, hBar)
                                )
                                drawRect(
                                    color = Color(0xFFFFB800),
                                    topLeft = Offset.Zero,
                                    size = Size(wBar * yellowProgress, hBar)
                                )
                            }
                        }

                        // C. Cyan Horizontal Progress Bar (Smooth normalized live buffer animation)
                        val cyanProgress = (0.48f + 0.22f * cos(graphPhase * 1.0f + 1.8f)).coerceIn(0.12f, 0.90f)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ONLINE",
                                color = Color(0xFF00E5FF),
                                fontSize = 6.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(30.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Canvas(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.5.dp)
                            ) {
                                val wBar = size.width
                                val hBar = size.height
                                drawRect(
                                    color = Color(0xFF0A1F2A),
                                    topLeft = Offset.Zero,
                                    size = Size(wBar, hBar)
                                )
                                drawRect(
                                    color = Color(0xFF00E5FF),
                                    topLeft = Offset.Zero,
                                    size = Size(wBar * cyanProgress, hBar)
                                )
                            }
                        }

                        // Bottom online status indicator line
                        Text(
                            text = "ONLINE",
                            color = Color(0xFF8A92A6),
                            fontSize = 6.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // =========================================================================
                // ORANGE INFORMATION CARD (RIGHT) - LIVE WAVEFORM ANIMATIONS
                // Strictly bounded inside the card's inner glass (width 124px, x: 464..588)
                // =========================================================================

                // A. Yellow Waveform (Multiple symmetrical vertical peaks around central baseline)
                // Positioned safely below "ROOM: PA-6-42" divider line with generous vertical clearance
                Box(
                    modifier = Modifier
                        .offset(x = w * 0.55635f, y = h * 0.30133f)
                        .size(w * 0.14868f, h * 0.02759f)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val numPeaks = 30
                        val totalW = size.width
                        val maxH = size.height
                        val midY = maxH / 2f
                        val spacing = 1.0.dp.toPx()
                        val colW = (totalW - (numPeaks - 1) * spacing) / numPeaks
                        val yellowWaveColor = Color(0xFFFFAE00)

                        for (k in 0 until numPeaks) {
                            val u = k.toFloat() / (numPeaks - 1)
                            val envelope = sin(u * Math.PI.toFloat()).coerceAtLeast(0f)

                            // Normalized voice transmission harmonics
                            val w1 = sin(u * 10.0f - graphPhase * 1.2f) * 0.58f
                            val w2 = cos(u * 18.0f + graphPhase * 0.7f) * 0.28f
                            val combined = abs(w1 + w2)

                            // Keep amplitude bounded to prevent any overlap with text or borders
                            val amplitude = (envelope * combined * (midY * 0.78f)).coerceIn(1.2.dp.toPx(), midY * 0.80f)
                            val xPos = k * (colW + spacing)

                            drawLine(
                                color = yellowWaveColor,
                                start = Offset(xPos + colW / 2f, midY - amplitude),
                                end = Offset(xPos + colW / 2f, midY + amplitude),
                                strokeWidth = colW * 0.85f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                // B. Red Waveform: Real-time left-to-right propagation
                // Positioned comfortably above "SYNCED [ACTIVE]"
                Box(
                    modifier = Modifier
                        .offset(x = w * 0.55635f, y = h * 0.33316f)
                        .size(w * 0.14868f, h * 0.02759f)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val totalW = size.width
                        val maxH = size.height
                        val midY = maxH / 2f
                        val steps = 80
                        val path = Path()
                        val redColor = Color(0xFFFF1E40)

                        for (step in 0..steps) {
                            val u = step.toFloat() / steps
                            val x = u * totalW
                            // Normalized continuous propagation offset
                            val xi = u - waveScroll

                            val carrier = (sin(xi * 20.0f * Math.PI.toFloat()) * 0.65f) +
                                          (sin(xi * 36.0f * Math.PI.toFloat()) * 0.25f)
                            val modEnvelope = 0.75f + 0.25f * sin(xi * 4.0f * Math.PI.toFloat() + graphPhase * 0.6f)
                            val spatialDecay = (1.05f - 0.75f * u).coerceIn(0.12f, 1f)
                            val windowEdge = sin(u * Math.PI.toFloat()).coerceAtLeast(0f)

                            val waveVal = carrier * modEnvelope * spatialDecay * windowEdge
                            val y = midY + (waveVal * (midY * 0.80f))

                            if (step == 0) {
                                path.moveTo(x, y)
                            } else {
                                path.lineTo(x, y)
                            }
                        }

                        drawPath(
                            path = path,
                            color = redColor,
                            style = Stroke(
                                width = 1.6.dp.toPx(),
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                }

                // =========================================================================
                // THREE EXISTING BUTTONS (REFERENCE IMAGE 3) - LIVE SCALE-UP / SCALE-DOWN
                // Exactly matching the lively action button animation on HomeScreen
                // =========================================================================

                // 1. CREATE ROOM BUTTON
                Image(
                    painter = painterResource(R.drawable.btn_create_room),
                    contentDescription = "CREATE ROOM",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier
                        .offset(x = w * 0.22182f, y = h * 0.49178f)
                        .size(w * 0.55635f, h * 0.06950f)
                        .graphicsLayer {
                            scaleX = buttonZoomScale
                            scaleY = buttonZoomScale
                            alpha = buttonPulseAlpha
                        }
                        .bouncyClick { handleCreateRoom() }
                )

                // 2. ROOM CODE INPUT TEXT FIELD (Aligned precisely inside the black slot)
                Box(
                    modifier = Modifier
                        .offset(x = w * 0.26619f, y = h * 0.67480f)
                        .size(w * 0.46763f, h * 0.02971f)
                        .bringIntoViewRequester(bringIntoViewRequester),
                    contentAlignment = Alignment.Center
                ) {
                    BasicTextField(
                        value = joinRoomCode,
                        onValueChange = { input ->
                            if (input.length <= 6) {
                                joinRoomCode = input.uppercase().filter { it.isLetterOrDigit() }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = { handleJoinRoom() }
                        ),
                        textStyle = TextStyle(
                            color = Color(0xFFFF3344),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 6.sp,
                            textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(Color(0xFFFF1744)),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { innerTextField ->
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (joinRoomCode.isEmpty()) {
                                    Text(
                                        text = "Enter Code",
                                        color = Color(0x77FF4444),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        fontFamily = FontFamily.Monospace,
                                        letterSpacing = 1.5.sp
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )
                }

                // 3. JOIN ROOM BUTTON
                Image(
                    painter = painterResource(R.drawable.btn_join_room),
                    contentDescription = "JOIN ROOM",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier
                        .offset(x = w * 0.22182f, y = h * 0.73369f)
                        .size(w * 0.55635f, h * 0.06950f)
                        .graphicsLayer {
                            scaleX = buttonZoomScale
                            scaleY = buttonZoomScale
                            alpha = buttonPulseAlpha
                        }
                        .bouncyClick { handleJoinRoom() }
                )

                // 4. FRIENDS BUTTON
                Image(
                    painter = painterResource(R.drawable.btn_friends),
                    contentDescription = "FRIENDS",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier
                        .offset(x = w * 0.34293f, y = h * 0.84085f)
                        .size(w * 0.31655f, h * 0.04562f)
                        .graphicsLayer {
                            scaleX = buttonZoomScale
                            scaleY = buttonZoomScale
                            alpha = buttonPulseAlpha
                        }
                        .bouncyClick { onNavigateToFriends() }
                )
            }

            // Bottom clearance when soft keyboard is displayed so user can scroll down easily
            if (isImeVisible) {
                Spacer(modifier = Modifier.height(180.dp))
            }
        }
    }
}
